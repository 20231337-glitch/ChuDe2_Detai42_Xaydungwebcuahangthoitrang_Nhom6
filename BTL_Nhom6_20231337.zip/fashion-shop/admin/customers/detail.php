<?php
require_once '../../config/database.php';
require_once '../../config/session.php';
require_once '../includes/auth_check.php';

check_admin();

$customer_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Lấy thông tin khách hàng
$sql = "SELECT * FROM users WHERE user_id = ? AND role = 'customer' AND deleted_at IS NULL";
$stmt = $pdo->prepare($sql);
$stmt->execute([$customer_id]);
$customer = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$customer) {
    header('Location: index.php?error=Khách hàng không tồn tại');
    exit;
}

// Lấy thống kê tổng quan
$stats_sql = "SELECT 
    COUNT(*) as total_orders,
    SUM(CASE WHEN order_status = 'completed' THEN final_amount ELSE 0 END) as total_spent,
    AVG(CASE WHEN order_status = 'completed' THEN final_amount ELSE NULL END) as avg_order_value,
    SUM(CASE WHEN order_status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_orders
FROM orders
WHERE user_id = ?";
$stats_stmt = $pdo->prepare($stats_sql);
$stats_stmt->execute([$customer_id]);
$stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);

// Lấy lịch sử đơn hàng
$orders_sql = "SELECT * FROM orders WHERE user_id = ? ORDER BY order_date DESC LIMIT 20";
$orders_stmt = $pdo->prepare($orders_sql);
$orders_stmt->execute([$customer_id]);
$orders = $orders_stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = 'Chi tiết khách hàng: ' . htmlspecialchars($customer['fullname']);
include '../includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><?php echo $page_title; ?></h2>
                <a href="index.php" class="btn btn-secondary">← Quay lại</a>
            </div>

            <!-- Customer Info -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0">Thông tin cá nhân</h5>
                        </div>
                        <div class="card-body">
                            <table class="table table-borderless">
                                <tr>
                                    <th width="40%">Họ tên:</th>
                                    <td><?php echo htmlspecialchars($customer['fullname']); ?></td>
                                </tr>
                                <tr>
                                    <th>Username:</th>
                                    <td><?php echo htmlspecialchars($customer['username']); ?></td>
                                </tr>
                                <tr>
                                    <th>Email:</th>
                                    <td><?php echo htmlspecialchars($customer['email']); ?></td>
                                </tr>
                                <tr>
                                    <th>Số điện thoại:</th>
                                    <td><?php echo htmlspecialchars($customer['phone'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <th>Địa chỉ:</th>
                                    <td><?php echo htmlspecialchars($customer['address'] ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <th>Trạng thái:</th>
                                    <td>
                                        <?php if ($customer['status'] === 'active'): ?>
                                            <span class="badge bg-success">Hoạt động</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Bị khóa</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Ngày đăng ký:</th>
                                    <td><?php echo date('d/m/Y H:i', strtotime($customer['created_at'])); ?></td>
                                </tr>
                                <tr>
                                    <th>Đăng nhập cuối:</th>
                                    <td>
                                        <?php 
                                        echo $customer['last_login'] 
                                            ? date('d/m/Y H:i', strtotime($customer['last_login'])) 
                                            : 'Chưa đăng nhập';
                                        ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-success text-white">
                            <h5 class="mb-0">Thống kê mua hàng</h5>
                        </div>
                        <div class="card-body">
                            <table class="table table-borderless">
                                <tr>
                                    <th width="40%">Tổng đơn hàng:</th>
                                    <td><strong class="text-primary"><?php echo number_format($stats['total_orders']); ?></strong></td>
                                </tr>
                                <tr>
                                    <th>Tổng chi tiêu:</th>
                                    <td><strong class="text-success"><?php echo number_format($stats['total_spent']); ?>đ</strong></td>
                                </tr>
                                <tr>
                                    <th>Giá trị TB/đơn:</th>
                                    <td>
                                        <strong><?php echo $stats['avg_order_value'] ? number_format($stats['avg_order_value']) . 'đ' : '0đ'; ?></strong>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Đơn hủy:</th>
                                    <td><span class="badge bg-danger"><?php echo $stats['cancelled_orders']; ?></span></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Order History -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Lịch sử đơn hàng (<?php echo count($orders); ?> đơn gần nhất)</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Mã đơn</th>
                                    <th>Ngày đặt</th>
                                    <th>Tổng tiền</th>
                                    <th>Trạng thái</th>
                                    <th>Phương thức TT</th>
                                    <th>Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($orders)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">Chưa có đơn hàng nào</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($orders as $order): ?>
                                        <tr>
                                            <td><strong>#<?php echo $order['order_id']; ?></strong></td>
                                            <td><?php echo date('d/m/Y H:i', strtotime($order['order_date'])); ?></td>
                                            <td><strong class="text-success"><?php echo number_format($order['final_amount']); ?>đ</strong></td>
                                            <td>
                                                <?php
                                                $status_badges = [
                                                    'pending' => 'warning',
                                                    'processing' => 'info',
                                                    'confirmed' => 'primary',
                                                    'shipping' => 'info',
                                                    'completed' => 'success',
                                                    'cancelled' => 'danger'
                                                ];
                                                $status_labels = [
                                                    'pending' => 'Chờ xử lý',
                                                    'processing' => 'Đang xử lý',
                                                    'confirmed' => 'Đã xác nhận',
                                                    'shipping' => 'Đang giao',
                                                    'completed' => 'Hoàn thành',
                                                    'cancelled' => 'Đã hủy'
                                                ];
                                                $badge = $status_badges[$order['order_status']] ?? 'secondary';
                                                $label = $status_labels[$order['order_status']] ?? $order['order_status'];
                                                ?>
                                                <span class="badge bg-<?php echo $badge; ?>"><?php echo $label; ?></span>
                                            </td>
                                            <td><?php echo $order['payment_method'] === 'cod' ? 'COD' : 'Chuyển khoản'; ?></td>
                                            <td>
                                                <a href="../orders/detail.php?id=<?php echo $order['order_id']; ?>" 
                                                   class="btn btn-sm btn-info">
                                                    <i class="fas fa-eye"></i> Xem
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
