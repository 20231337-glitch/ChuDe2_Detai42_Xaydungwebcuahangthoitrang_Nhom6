<?php
require_once '../../config/database.php';
require_once '../../config/session.php';
require_once '../includes/auth_check.php';

check_admin();

$page_title = 'Quản lý khách hàng';

// Phân trang
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Tìm kiếm
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';

// Xây dựng query
$where_conditions = ["u.role = 'customer'", "u.deleted_at IS NULL"];
$params = [];

if (!empty($search)) {
    $where_conditions[] = "(u.fullname LIKE ? OR u.email LIKE ? OR u.phone LIKE ? OR u.username LIKE ?)";
    $search_param = "%$search%";
    $params = array_merge($params, [$search_param, $search_param, $search_param, $search_param]);
}

if (!empty($status_filter)) {
    $where_conditions[] = "u.status = ?";
    $params[] = $status_filter;
}

$where_sql = implode(' AND ', $where_conditions);

// Đếm tổng số khách hàng
$count_sql = "SELECT COUNT(DISTINCT u.user_id) as total FROM users u WHERE $where_sql";
$count_stmt = $pdo->prepare($count_sql);
$count_stmt->execute($params);
$total_customers = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
$total_pages = ceil($total_customers / $limit);

// Lấy danh sách khách hàng với thống kê
$sql = "SELECT 
    u.*,
    COUNT(DISTINCT o.order_id) as total_orders,
    COALESCE(SUM(CASE WHEN o.order_status = 'completed' THEN o.final_amount ELSE 0 END), 0) as total_spent,
    MAX(o.order_date) as last_order_date
FROM users u
LEFT JOIN orders o ON u.user_id = o.user_id
WHERE $where_sql
GROUP BY u.user_id
ORDER BY u.created_at DESC
LIMIT ? OFFSET ?";

$stmt = $pdo->prepare($sql);
$stmt->execute(array_merge($params, [$limit, $offset]));
$customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

include '../includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><?php echo $page_title; ?></h2>
            </div>

            <!-- Filters -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-4">
                            <input type="text" class="form-control" name="search" 
                                   placeholder="Tìm theo tên, email, SĐT..." 
                                   value="<?php echo htmlspecialchars($search); ?>">
                        </div>
                        <div class="col-md-3">
                            <select name="status" class="form-control">
                                <option value="">-- Tất cả trạng thái --</option>
                                <option value="active" <?php echo $status_filter === 'active' ? 'selected' : ''; ?>>Hoạt động</option>
                                <option value="blocked" <?php echo $status_filter === 'blocked' ? 'selected' : ''; ?>>Bị khóa</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100">Tìm kiếm</button>
                        </div>
                        <div class="col-md-2">
                            <a href="index.php" class="btn btn-secondary w-100">Reset</a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Statistics Summary -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="card text-white bg-primary">
                        <div class="card-body">
                            <h5>Tổng khách hàng</h5>
                            <h2><?php echo number_format($total_customers); ?></h2>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Customers Table -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Tên khách hàng</th>
                                    <th>Email</th>
                                    <th>Số điện thoại</th>
                                    <th>Tổng đơn</th>
                                    <th>Tổng chi tiêu</th>
                                    <th>Đơn cuối</th>
                                    <th>Trạng thái</th>
                                    <th>Ngày đăng ký</th>
                                    <th>Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($customers)): ?>
                                    <tr>
                                        <td colspan="10" class="text-center">Không tìm thấy khách hàng nào</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($customers as $customer): ?>
                                        <tr>
                                            <td><?php echo $customer['user_id']; ?></td>
                                            <td>
                                                <strong><?php echo htmlspecialchars($customer['fullname']); ?></strong><br>
                                                <small class="text-muted">@<?php echo htmlspecialchars($customer['username']); ?></small>
                                            </td>
                                            <td><?php echo htmlspecialchars($customer['email']); ?></td>
                                            <td><?php echo htmlspecialchars($customer['phone'] ?? 'N/A'); ?></td>
                                            <td>
                                                <span class="badge bg-info"><?php echo $customer['total_orders']; ?> đơn</span>
                                            </td>
                                            <td>
                                                <strong class="text-success"><?php echo number_format($customer['total_spent']); ?>đ</strong>
                                            </td>
                                            <td>
                                                <?php 
                                                if ($customer['last_order_date']) {
                                                    echo date('d/m/Y', strtotime($customer['last_order_date']));
                                                } else {
                                                    echo '<span class="text-muted">Chưa có</span>';
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <?php if ($customer['status'] === 'active'): ?>
                                                    <span class="badge bg-success">Hoạt động</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">Bị khóa</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo date('d/m/Y', strtotime($customer['created_at'])); ?></td>
                                            <td>
                                                <a href="detail.php?id=<?php echo $customer['user_id']; ?>" 
                                                   class="btn btn-sm btn-info" title="Chi tiết">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <?php if ($customer['status'] === 'active'): ?>
                                                    <a href="block.php?id=<?php echo $customer['user_id']; ?>" 
                                                       class="btn btn-sm btn-warning" 
                                                       onclick="return confirm('Bạn có chắc muốn khóa tài khoản này?')"
                                                       title="Khóa">
                                                        <i class="fas fa-lock"></i>
                                                    </a>
                                                <?php else: ?>
                                                    <a href="unblock.php?id=<?php echo $customer['user_id']; ?>" 
                                                       class="btn btn-sm btn-success" 
                                                       onclick="return confirm('Bạn có chắc muốn mở khóa tài khoản này?')"
                                                       title="Mở khóa">
                                                        <i class="fas fa-unlock"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <nav>
                            <ul class="pagination justify-content-center">
                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    </li>
                                <?php endfor; ?>
                            </ul>
                        </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
