<?php
require_once '../../config/database.php';
require_once '../../config/session.php';
require_once '../includes/auth_check.php';

check_admin();

$customer_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($customer_id <= 0) {
    header('Location: index.php?error=ID không hợp lệ');
    exit;
}

try {
    $pdo->beginTransaction();
    
    // Kiểm tra khách hàng tồn tại
    $check_sql = "SELECT * FROM users WHERE user_id = ? AND role = 'customer' AND deleted_at IS NULL";
    $check_stmt = $pdo->prepare($check_sql);
    $check_stmt->execute([$customer_id]);
    $customer = $check_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$customer) {
        throw new Exception('Khách hàng không tồn tại');
    }
    
    if ($customer['status'] === 'active') {
        throw new Exception('Tài khoản đang hoạt động bình thường');
    }
    
    // Cập nhật trạng thái
    $update_sql = "UPDATE users SET status = 'active' WHERE user_id = ?";
    $update_stmt = $pdo->prepare($update_sql);
    $update_stmt->execute([$customer_id]);
    
    // Ghi log
    $log_sql = "INSERT INTO admin_logs (admin_id, action, table_name, record_id, old_value, new_value, created_at)
                VALUES (?, 'UPDATE', 'users', ?, ?, ?, NOW())";
    $log_stmt = $pdo->prepare($log_sql);
    $log_stmt->execute([
        $_SESSION['user_id'],
        $customer_id,
        json_encode(['status' => 'blocked']),
        json_encode(['status' => 'active'])
    ]);
    
    // Tạo thông báo cho khách hàng
    $notif_sql = "INSERT INTO notifications (user_id, type, title, message, created_at)
                   VALUES (?, 'account_unblocked', 'Tài khoản đã được mở khóa', 'Tài khoản của bạn đã được mở khóa. Bạn có thể tiếp tục sử dụng dịch vụ.', NOW())";
    $notif_stmt = $pdo->prepare($notif_sql);
    $notif_stmt->execute([$customer_id]);
    
    $pdo->commit();
    
    header('Location: detail.php?id=' . $customer_id . '&success=Đã mở khóa tài khoản thành công');
    exit;
    
} catch (Exception $e) {
    $pdo->rollBack();
    header('Location: detail.php?id=' . $customer_id . '&error=' . urlencode($e->getMessage()));
    exit;
}
