<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/constants.php';

// Kiểm tra quyền admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

// Lấy tham số lọc
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build query
$sql = "SELECT 
    r.*,
    u.fullname as customer_name,
    u.email,
    u.phone,
    o.order_id,
    o.order_date,
    o.final_amount,
    o.order_status
FROM order_returns r
JOIN users u ON r.user_id = u.user_id
JOIN orders o ON r.order_id = o.order_id
WHERE 1=1";

if ($status_filter != 'all') {
    $sql .= " AND r.status = '$status_filter'";
}

if ($search != '') {
    $sql .= " AND (o.order_id LIKE '%$search%' OR u.fullname LIKE '%$search%')";
}

$sql .= " ORDER BY r.created_at DESC";

$result = mysqli_query($conn, $sql);

// Đếm số lượng theo trạng thái
$count_pending = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM order_returns WHERE status='pending'"));
$count_approved = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM order_returns WHERE status='approved'"));
$count_rejected = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM order_returns WHERE status='rejected'"));
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý Trả hàng - Admin</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f7fa; }
        
        .container { max-width: 1400px; margin: 20px auto; padding: 0 20px; }
        
        .header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .header h1 { color: #2c3e50; margin-bottom: 10px; }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            border-left: 4px solid #3498db;
        }
        
        .stat-card.pending { border-left-color: #f39c12; }
        .stat-card.approved { border-left-color: #27ae60; }
        .stat-card.rejected { border-left-color: #e74c3c; }
        
        .stat-card h3 { font-size: 14px; color: #7f8c8d; margin-bottom: 5px; }
        .stat-card .number { font-size: 32px; font-weight: bold; color: #2c3e50; }
        
        .filters {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }
        
        .filters select, .filters input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        
        .filters button {
            padding: 10px 20px;
            background: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }
        
        .filters button:hover { background: #2980b9; }
        
        .table-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            overflow: hidden;
        }
        
        table { width: 100%; border-collapse: collapse; }
        
        th {
            background: #34495e;
            color: white;
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }
        
        td {
            padding: 15px;
            border-bottom: 1px solid #ecf0f1;
        }
        
        tr:hover { background: #f8f9fa; }
        
        .badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        
        .badge.pending { background: #fff3cd; color: #856404; }
        .badge.approved { background: #d4edda; color: #155724; }
        .badge.rejected { background: #f8d7da; color: #721c24; }
        
        .btn {
            padding: 8px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 13px;
            display: inline-block;
            margin: 2px;
        }
        
        .btn-view { background: #3498db; color: white; }
        .btn-view:hover { background: #2980b9; }
        
        .no-data {
            text-align: center;
            padding: 50px;
            color: #7f8c8d;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📦 Quản lý Yêu cầu Trả hàng</h1>
            <p>Xử lý các yêu cầu trả hàng từ khách hàng</p>
        </div>
        
        <div class="stats">
            <div class="stat-card pending">
                <h3>Chờ xử lý</h3>
                <div class="number"><?php echo $count_pending; ?></div>
            </div>
            <div class="stat-card approved">
                <h3>Đã chấp nhận</h3>
                <div class="number"><?php echo $count_approved; ?></div>
            </div>
            <div class="stat-card rejected">
                <h3>Đã từ chối</h3>
                <div class="number"><?php echo $count_rejected; ?></div>
            </div>
        </div>
        
        <div class="filters">
            <form method="GET" style="display: flex; gap: 15px; flex-wrap: wrap; width: 100%;">
                <select name="status">
                    <option value="all" <?php echo $status_filter == 'all' ? 'selected' : ''; ?>>Tất cả trạng thái</option>
                    <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>Chờ xử lý</option>
                    <option value="approved" <?php echo $status_filter == 'approved' ? 'selected' : ''; ?>>Đã chấp nhận</option>
                    <option value="rejected" <?php echo $status_filter == 'rejected' ? 'selected' : ''; ?>>Đã từ chối</option>
                </select>
                
                <input type="text" name="search" placeholder="Tìm theo mã đơn hoặc tên khách..." 
                       value="<?php echo htmlspecialchars($search); ?>" style="flex: 1; min-width: 250px;">
                
                <button type="submit">🔍 Tìm kiếm</button>
                <a href="index.php" class="btn btn-view">🔄 Làm mới</a>
            </form>
        </div>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Mã YC</th>
                        <th>Mã đơn</th>
                        <th>Khách hàng</th>
                        <th>Ngày đặt</th>
                        <th>Giá trị</th>
                        <th>Lý do</th>
                        <th>Trạng thái</th>
                        <th>Ngày yêu cầu</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($result) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><strong>#<?php echo $row['return_id']; ?></strong></td>
                            <td><a href="../orders/detail.php?id=<?php echo $row['order_id']; ?>" 
                                   style="color: #3498db;">#<?php echo $row['order_id']; ?></a></td>
                            <td>
                                <strong><?php echo htmlspecialchars($row['customer_name']); ?></strong><br>
                                <small><?php echo htmlspecialchars($row['email']); ?></small>
                            </td>
                            <td><?php echo date('d/m/Y', strtotime($row['order_date'])); ?></td>
                            <td><strong><?php echo number_format($row['final_amount']); ?>đ</strong></td>
                            <td><?php echo htmlspecialchars(substr($row['reason'], 0, 50)) . (strlen($row['reason']) > 50 ? '...' : ''); ?></td>
                            <td>
                                <span class="badge <?php echo $row['status']; ?>">
                                    <?php 
                                    $status_text = [
                                        'pending' => 'Chờ xử lý',
                                        'approved' => 'Đã chấp nhận',
                                        'rejected' => 'Đã từ chối'
                                    ];
                                    echo $status_text[$row['status']];
                                    ?>
                                </span>
                            </td>
                            <td><?php echo date('d/m/Y H:i', strtotime($row['created_at'])); ?></td>
                            <td>
                                <a href="detail.php?id=<?php echo $row['return_id']; ?>" class="btn btn-view">👁️ Xem</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9" class="no-data">
                                <h3>📭 Không có yêu cầu trả hàng nào</h3>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>

<?php
mysqli_close($conn);
?>
