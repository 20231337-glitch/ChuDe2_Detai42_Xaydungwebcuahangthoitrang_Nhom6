<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/constants.php';

// Kiểm tra quyền admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

$return_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Lấy thông tin yêu cầu trả hàng
$sql = "SELECT 
    r.*,
    u.fullname as customer_name,
    u.email,
    u.phone,
    u.address,
    o.order_id,
    o.order_date,
    o.final_amount,
    o.order_status,
    o.payment_method,
    o.shipping_address
FROM order_returns r
JOIN users u ON r.user_id = u.user_id
JOIN orders o ON r.order_id = o.order_id
WHERE r.return_id = $return_id";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 0) {
    die('Không tìm thấy yêu cầu trả hàng!');
}

$return = mysqli_fetch_assoc($result);

// Lấy chi tiết đơn hàng
$sql_details = "SELECT 
    od.*,
    p.product_name,
    pi.image_url
FROM order_details od
LEFT JOIN product_variants pv ON od.variant_id = pv.variant_id
LEFT JOIN products p ON pv.product_id = p.product_id
LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
WHERE od.order_id = " . $return['order_id'];

$details_result = mysqli_query($conn, $sql_details);

// Xử lý khi admin approve/reject
if (['REQUEST_METHOD'] == 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    $admin_note = isset($_POST['admin_note']) ? trim($_POST['admin_note']) : '';
    
    if ($action == 'approve' || $action == 'reject') {
        mysqli_begin_transaction($conn);
        
        try {
            $new_status = ($action == 'approve') ? 'approved' : 'rejected';
            
            // 1. Cập nhật trạng thái return
            $update_sql = "UPDATE order_returns 
                           SET status = '$new_status',
                               admin_note = '$admin_note',
                               updated_at = NOW()
                           WHERE return_id = $return_id";
            mysqli_query($conn, $update_sql);
            
            if ($action == 'approve') {
                // 2. Hoàn tồn kho
                $restore_stock = "UPDATE product_variants pv
                                  JOIN order_details od ON pv.variant_id = od.variant_id
                                  SET pv.stock_quantity = pv.stock_quantity + od.quantity
                                  WHERE od.order_id = " . $return['order_id'];
                mysqli_query($conn, $restore_stock);
                
                // 3. Giảm sold_count
                $reduce_sold = "UPDATE products p
                                JOIN product_variants pv ON p.product_id = pv.product_id
                                JOIN order_details od ON pv.variant_id = od.variant_id
                                SET p.sold_count = GREATEST(0, p.sold_count - od.quantity)
                                WHERE od.order_id = " . $return['order_id'];
                mysqli_query($conn, $reduce_sold);
                
                // 4. Cập nhật trạng thái đơn hàng
                $cancel_order = "UPDATE orders 
                                 SET order_status = 'cancelled',
                                     cancelled_reason = 'Đã chấp nhận yêu cầu trả hàng',
                                     cancelled_by = 'admin',
                                     cancelled_at = NOW()
                                 WHERE order_id = " . $return['order_id'];
                mysqli_query($conn, $cancel_order);
                
                $notif_title = 'Yêu cầu trả hàng đã được chấp nhận';
                $notif_msg = 'Yêu cầu trả hàng #' . $return_id . ' của bạn đã được chấp nhận. Chúng tôi sẽ liên hệ với bạn sớm.';
            } else {
                $notif_title = 'Yêu cầu trả hàng bị từ chối';
                $notif_msg = 'Yêu cầu trả hàng #' . $return_id . ' của bạn đã bị từ chối. Lý do: ' . $admin_note;
            }
            
            // 5. Tạo thông báo
            $notif_sql = "INSERT INTO notifications 
                          (user_id, type, title, message, link, created_at)
                          VALUES 
                          (" . $return['user_id'] . ", 'return_update', '$notif_title', '$notif_msg', 
                           '/public/account/orders.php', NOW())";
            mysqli_query($conn, $notif_sql);
            
            // 6. Log hoạt động
            $log_sql = "INSERT INTO admin_logs 
                        (admin_id, action, table_name, record_id, old_value, new_value, created_at)
                        VALUES 
                        (" . $_SESSION['user_id'] . ", 'UPDATE', 'order_returns', $return_id, 
                         '{\"status\": \"" . $return['status'] . "\"}', 
                         '{\"status\": \"$new_status\"}', NOW())";
            mysqli_query($conn, $log_sql);
            
            mysqli_commit($conn);
            
            $success_msg = $action == 'approve' ? 
                'Đã chấp nhận yêu cầu trả hàng và hoàn tồn kho!' : 
                'Đã từ chối yêu cầu trả hàng!';
            
            echo "<script>alert('$success_msg'); window.location.href='index.php';</script>";
            exit;
            
        } catch (Exception $e) {
            mysqli_rollback($conn);
            $error = 'Có lỗi xảy ra: ' . $e->getMessage();
        }
    }
}

// Parse ảnh JSON
$images = json_decode($return['images'], true);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi tiết Yêu cầu Trả hàng #<?php echo $return_id; ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f7fa; }
        
        .container { max-width: 1200px; margin: 20px auto; padding: 0 20px; }
        
        .header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header h1 { color: #2c3e50; }
        
        .back-btn {
            padding: 10px 20px;
            background: #95a5a6;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        
        .back-btn:hover { background: #7f8c8d; }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .info-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .info-card h3 {
            color: #2c3e50;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #ecf0f1;
        }
        
        .info-row {
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
        }
        
        .info-row label { color: #7f8c8d; font-weight: 600; }
        .info-row span { color: #2c3e50; }
        
        .badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge.pending { background: #fff3cd; color: #856404; }
        .badge.approved { background: #d4edda; color: #155724; }
        .badge.rejected { background: #f8d7da; color: #721c24; }
        
        .reason-box {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            border-left: 4px solid #f39c12;
            margin-bottom: 20px;
        }
        
        .reason-box h4 { color: #e67e22; margin-bottom: 10px; }
        
        .images-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        
        .images-grid img {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 8px;
            border: 2px solid #ecf0f1;
            cursor: pointer;
        }
        
        .images-grid img:hover { border-color: #3498db; }
        
        .products-table {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            overflow: hidden;
            margin-bottom: 20px;
        }
        
        .products-table table { width: 100%; border-collapse: collapse; }
        
        .products-table th {
            background: #34495e;
            color: white;
            padding: 15px;
            text-align: left;
        }
        
        .products-table td {
            padding: 15px;
            border-bottom: 1px solid #ecf0f1;
        }
        
        .product-img {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 5px;
        }
        
        .action-form {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .action-form h3 {
            color: #2c3e50;
            margin-bottom: 15px;
        }
        
        .action-form textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 15px;
            font-family: inherit;
            resize: vertical;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
        }
        
        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
        }
        
        .btn-approve {
            background: #27ae60;
            color: white;
        }
        
        .btn-approve:hover { background: #229954; }
        
        .btn-reject {
            background: #e74c3c;
            color: white;
        }
        
        .btn-reject:hover { background: #c0392b; }
        
        .disabled-section {
            background: #ecf0f1;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            color: #7f8c8d;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📦 Chi tiết Yêu cầu Trả hàng #<?php echo $return_id; ?></h1>
            <a href="index.php" class="back-btn">⬅️ Quay lại</a>
        </div>
        
        <div class="info-grid">
            <div class="info-card">
                <h3>👤 Thông tin Khách hàng</h3>
                <div class="info-row">
                    <label>Họ tên:</label>
                    <span><?php echo htmlspecialchars($return['customer_name']); ?></span>
                </div>
                <div class="info-row">
                    <label>Email:</label>
                    <span><?php echo htmlspecialchars($return['email']); ?></span>
                </div>
                <div class="info-row">
                    <label>Điện thoại:</label>
                    <span><?php echo htmlspecialchars($return['phone']); ?></span>
                </div>
                <div class="info-row">
                    <label>Địa chỉ:</label>
                    <span><?php echo htmlspecialchars($return['address']); ?></span>
                </div>
            </div>
            
            <div class="info-card">
                <h3>📋 Thông tin Đơn hàng</h3>
                <div class="info-row">
                    <label>Mã đơn:</label>
                    <span><strong>#<?php echo $return['order_id']; ?></strong></span>
                </div>
                <div class="info-row">
                    <label>Ngày đặt:</label>
                    <span><?php echo date('d/m/Y H:i', strtotime($return['order_date'])); ?></span>
                </div>
                <div class="info-row">
                    <label>Giá trị:</label>
                    <span><strong><?php echo number_format($return['final_amount']); ?>đ</strong></span>
                </div>
                <div class="info-row">
                    <label>Phương thức TT:</label>
                    <span><?php echo $return['payment_method']; ?></span>
                </div>
                <div class="info-row">
                    <label>Trạng thái đơn:</label>
                    <span><?php echo $return['order_status']; ?></span>
                </div>
            </div>
            
            <div class="info-card">
                <h3>🔄 Thông tin Trả hàng</h3>
                <div class="info-row">
                    <label>Trạng thái:</label>
                    <span class="badge <?php echo $return['status']; ?>">
                        <?php 
                        $status_text = [
                            'pending' => 'Chờ xử lý',
                            'approved' => 'Đã chấp nhận',
                            'rejected' => 'Đã từ chối'
                        ];
                        echo $status_text[$return['status']];
                        ?>
                    </span>
                </div>
                <div class="info-row">
                    <label>Ngày yêu cầu:</label>
                    <span><?php echo date('d/m/Y H:i', strtotime($return['created_at'])); ?></span>
                </div>
                <?php if ($return['updated_at']): ?>
                <div class="info-row">
                    <label>Cập nhật:</label>
                    <span><?php echo date('d/m/Y H:i', strtotime($return['updated_at'])); ?></span>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="reason-box">
            <h4>📝 Lý do trả hàng:</h4>
            <p><?php echo nl2br(htmlspecialchars($return['reason'])); ?></p>
        </div>
        
        <?php if ($images && count($images) > 0): ?>
        <div class="info-card">
            <h3>📷 Hình ảnh đính kèm</h3>
            <div class="images-grid">
                <?php foreach ($images as $img): ?>
                    <img src="<?php echo htmlspecialchars($img); ?>" alt="Ảnh sản phẩm lỗi" 
                         onclick="window.open(this.src, '_blank')">
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="products-table">
            <h3 style="padding: 15px; background: #ecf0f1;">🛍️ Chi tiết Sản phẩm</h3>
            <table>
                <thead>
                    <tr>
                        <th>Ảnh</th>
                        <th>Sản phẩm</th>
                        <th>Size</th>
                        <th>Màu</th>
                        <th>Đơn giá</th>
                        <th>Số lượng</th>
                        <th>Thành tiền</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($detail = mysqli_fetch_assoc($details_result)): ?>
                    <tr>
                        <td>
                            <?php if ($detail['image_url']): ?>
                                <img src="<?php echo $detail['image_url']; ?>" class="product-img">
                            <?php else: ?>
                                <div style="width:60px;height:60px;background:#ecf0f1;border-radius:5px;"></div>
                            <?php endif; ?>
                        </td>
                        <td><strong><?php echo htmlspecialchars($detail['product_name']); ?></strong></td>
                        <td><?php echo htmlspecialchars($detail['size_name']); ?></td>
                        <td><?php echo htmlspecialchars($detail['color_name']); ?></td>
                        <td><?php echo number_format($detail['price']); ?>đ</td>
                        <td><?php echo $detail['quantity']; ?></td>
                        <td><strong><?php echo number_format($detail['price'] * $detail['quantity']); ?>đ</strong></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        
        <?php if ($return['status'] == 'pending'): ?>
        <div class="action-form">
            <h3>⚙️ Xử lý Yêu cầu</h3>
            <form method="POST">
                <label>Ghi chú của Admin:</label>
                <textarea name="admin_note" rows="4" placeholder="Nhập ghi chú (bắt buộc nếu từ chối)..."></textarea>
                
                <div class="action-buttons">
                    <button type="submit" name="action" value="approve" class="btn btn-approve" 
                            onclick="return confirm('Xác nhận CHẤP NHẬN yêu cầu trả hàng này?\n\nSẽ hoàn tồn kho và hủy đơn hàng!')">
                        ✅ Chấp nhận
                    </button>
                    <button type="submit" name="action" value="reject" class="btn btn-reject"
                            onclick="return confirm('Xác nhận TỪ CHỐI yêu cầu trả hàng này?')">
                        ❌ Từ chối
                    </button>
                </div>
            </form>
        </div>
        <?php else: ?>
        <div class="disabled-section">
            <h3>Yêu cầu này đã được xử lý</h3>
            <?php if ($return['admin_note']): ?>
                <p><strong>Ghi chú:</strong> <?php echo htmlspecialchars($return['admin_note']); ?></p>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
mysqli_close($conn);
?>
