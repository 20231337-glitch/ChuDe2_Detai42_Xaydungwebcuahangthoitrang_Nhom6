<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

$admin_name = $_SESSION['fullname'];

// Lấy danh sách mã giảm giá
$sql = "SELECT 
            c.*,
            (CASE 
                WHEN c.expiry_date < CURDATE() THEN 'expired'
                WHEN c.max_uses IS NOT NULL AND c.used_count >= c.max_uses THEN 'maxed_out'
                ELSE c.status
            END) as real_status
        FROM coupons c
        ORDER BY c.created_at DESC";
$result = mysqli_query($conn, $sql);

// Thống kê
$stats_sql = "SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'active' AND expiry_date >= CURDATE() THEN 1 ELSE 0 END) as active,
                SUM(used_count) as total_uses
               FROM coupons";
$stats = mysqli_fetch_assoc(mysqli_query($conn, $stats_sql));
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Mã Giảm Giá - Admin</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header h1 { font-size: 24px; margin-bottom: 5px; }
        .header a { color: white; text-decoration: none; margin-left: 20px; }
        
        .container { max-width: 1400px; margin: 30px auto; padding: 0 20px; }
        
        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            border-left: 4px solid #667eea;
        }
        
        .stat-card h3 { font-size: 14px; color: #666; margin-bottom: 10px; text-transform: uppercase; }
        .stat-card .value { font-size: 32px; font-weight: bold; color: #333; }
        .stat-card .sub { font-size: 13px; color: #999; margin-top: 8px; }
        
        .card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #667eea;
        }
        
        .card-header h2 { font-size: 20px; color: #333; }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-size: 14px;
            transition: background 0.3s;
        }
        .btn:hover { background: #5568d3; }
        
        .btn-success { background: #28a745; }
        .btn-success:hover { background: #218838; }
        
        .btn-danger { background: #dc3545; }
        .btn-danger:hover { background: #c82333; }
        
        .btn-warning { background: #ffc107; color: #333; }
        .btn-warning:hover { background: #e0a800; }
        
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; font-size: 14px; }
        th { background: #f8f9fa; font-weight: 600; color: #555; }
        tr:hover { background: #f8f9fa; }
        
        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .badge-active { background: #d4edda; color: #155724; }
        .badge-inactive { background: #f8d7da; color: #721c24; }
        .badge-expired { background: #fff3cd; color: #856404; }
        .badge-maxed { background: #e2e3e5; color: #383d41; }
        
        .badge-percent { background: #cfe2ff; color: #084298; }
        .badge-fixed { background: #d1e7dd; color: #0f5132; }
        
        .coupon-code {
            font-family: 'Courier New', monospace;
            font-weight: bold;
            font-size: 16px;
            color: #667eea;
        }
        
        .actions { display: flex; gap: 8px; }
        
        .progress-bar {
            width: 100%;
            height: 8px;
            background: #e9ecef;
            border-radius: 4px;
            overflow: hidden;
            margin-top: 5px;
        }
        
        .progress-fill {
            height: 100%;
            background: #28a745;
            transition: width 0.3s;
        }
        
        .progress-fill.warning { background: #ffc107; }
        .progress-fill.danger { background: #dc3545; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🎟️ Quản Lý Mã Giảm Giá</h1>
        <div>
            <a href="../dashboard/">← Dashboard</a>
            <a href="../auth/logout.php">Đăng xuất</a>
        </div>
    </div>

    <div class="container">
        <!-- Thống kê -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3>🎫 Tổng Mã Giảm Giá</h3>
                <div class="value"><?= number_format($stats['total']) ?></div>
                <div class="sub">Tất cả mã đã tạo</div>
            </div>
            
            <div class="stat-card">
                <h3>✅ Đang Hoạt Động</h3>
                <div class="value"><?= number_format($stats['active']) ?></div>
                <div class="sub">Mã còn hiệu lực</div>
            </div>
            
            <div class="stat-card">
                <h3>📊 Lượt Sử Dụng</h3>
                <div class="value"><?= number_format($stats['total_uses']) ?></div>
                <div class="sub">Tổng lượt đã dùng</div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h2>Danh Sách Mã Giảm Giá</h2>
                <a href="create.php" class="btn btn-success">+ Tạo Mã Mới</a>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>Mã Code</th>
                        <th>Loại / Giá Trị</th>
                        <th>ĐH Tối Thiểu</th>
                        <th>Giới Hạn</th>
                        <th>Đã Dùng</th>
                        <th>Hạn Dùng</th>
                        <th>Trạng Thái</th>
                        <th>Thao Tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($coupon = mysqli_fetch_assoc($result)): ?>
                    <?php
                        $usage_percent = 0;
                        if ($coupon['max_uses']) {
                            $usage_percent = ($coupon['used_count'] / $coupon['max_uses']) * 100;
                        }
                        
                        $bar_class = '';
                        if ($usage_percent >= 80) $bar_class = 'danger';
                        elseif ($usage_percent >= 50) $bar_class = 'warning';
                    ?>
                    <tr>
                        <td>
                            <span class="coupon-code"><?= htmlspecialchars($coupon['coupon_code']) ?></span>
                        </td>
                        <td>
                            <?php if($coupon['discount_type'] == 'percent'): ?>
                                <span class="badge badge-percent">% Phần trăm</span>
                                <strong><?= number_format($coupon['discount_value'], 0) ?>%</strong>
                            <?php else: ?>
                                <span class="badge badge-fixed">₫ Cố định</span>
                                <strong><?= number_format($coupon['discount_value'], 0, ',', '.') ?>đ</strong>
                            <?php endif; ?>
                        </td>
                        <td><?= number_format($coupon['min_order_value'], 0, ',', '.') ?>đ</td>
                        <td>
                            <?php if($coupon['max_uses']): ?>
                                <?= number_format($coupon['max_uses']) ?> lần
                                <div class="progress-bar">
                                    <div class="progress-fill <?= $bar_class ?>" 
                                         style="width: <?= min(100, $usage_percent) ?>%"></div>
                                </div>
                            <?php else: ?>
                                <em>Không giới hạn</em>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong><?= number_format($coupon['used_count']) ?></strong> lần
                        </td>
                        <td>
                            <?php
                                $expiry = new DateTime($coupon['expiry_date']);
                                $now = new DateTime();
                                $diff = $now->diff($expiry);
                                
                                if ($expiry < $now) {
                                    echo '<span style="color: #dc3545;">Đã hết hạn</span>';
                                } else {
                                    echo $expiry->format('d/m/Y');
                                    if ($diff->days <= 7) {
                                        echo '<br><small style="color: #ffc107;">Còn ' . $diff->days . ' ngày</small>';
                                    }
                                }
                            ?>
                        </td>
                        <td>
                            <?php
                                $status = $coupon['real_status'];
                                if ($status == 'expired') {
                                    echo '<span class="badge badge-expired">Hết hạn</span>';
                                } elseif ($status == 'maxed_out') {
                                    echo '<span class="badge badge-maxed">Đã hết lượt</span>';
                                } elseif ($status == 'active') {
                                    echo '<span class="badge badge-active">Hoạt động</span>';
                                } else {
                                    echo '<span class="badge badge-inactive">Tắt</span>';
                                }
                            ?>
                        </td>
                        <td>
                            <div class="actions">
                                <a href="edit.php?id=<?= $coupon['coupon_id'] ?>" class="btn">Sửa</a>
                                <a href="delete.php?id=<?= $coupon['coupon_id'] ?>" 
                                   class="btn btn-danger"
                                   onclick="return confirm('Bạn có chắc muốn xóa mã này?')">Xóa</a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
