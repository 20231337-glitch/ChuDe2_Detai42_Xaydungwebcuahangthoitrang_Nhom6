<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

$id = $_GET['id'] ?? 0;
$error = '';

// Lấy thông tin coupon
$sql = "SELECT * FROM coupons WHERE coupon_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$coupon = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$coupon) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $discount_type = $_POST['discount_type'] ?? 'percent';
    $discount_value = $_POST['discount_value'] ?? 0;
    $min_order_value = $_POST['min_order_value'] ?? 0;
    $max_uses = $_POST['max_uses'] ?? null;
    $max_uses_per_user = $_POST['max_uses_per_user'] ?? 1;
    $expiry_date = $_POST['expiry_date'] ?? '';
    $status = $_POST['status'] ?? 'active';
    
    if ($discount_value <= 0) {
        $error = 'Giá trị giảm giá phải lớn hơn 0';
    } elseif (empty($expiry_date)) {
        $error = 'Vui lòng chọn ngày hết hạn';
    } else {
        $sql = "UPDATE coupons 
                SET discount_type = ?, discount_value = ?, min_order_value = ?,
                    max_uses = ?, max_uses_per_user = ?, expiry_date = ?, status = ?
                WHERE coupon_id = ?";
        
        $stmt = mysqli_prepare($conn, $sql);
        
        if (empty($max_uses)) {
            $max_uses = null;
        }
        
        mysqli_stmt_bind_param($stmt, 'sdiiiisi',
            $discount_type, $discount_value, $min_order_value,
            $max_uses, $max_uses_per_user, $expiry_date, $status, $id
        );
        
        if (mysqli_stmt_execute($stmt)) {
            // Log
            $log_sql = "INSERT INTO admin_logs (admin_id, action, table_name, record_id, created_at)
                        VALUES (?, 'UPDATE', 'coupons', ?, NOW())";
            $log_stmt = mysqli_prepare($conn, $log_sql);
            mysqli_stmt_bind_param($log_stmt, 'ii', $_SESSION['user_id'], $id);
            mysqli_stmt_execute($log_stmt);
            
            header('Location: index.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Sửa Mã Giảm Giá</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px 40px; }
        .header h1 { font-size: 24px; }
        .container { max-width: 800px; margin: 30px auto; padding: 0 20px; }
        .card { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 500; }
        .form-group input, .form-group select { width: 100%; padding: 10px 15px; border: 2px solid #e0e0e0; border-radius: 6px; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .error { background: #fee; color: #c33; padding: 12px; border-radius: 6px; margin-bottom: 20px; }
        .btn { padding: 12px 30px; background: #667eea; color: white; border: none; border-radius: 6px; 
               cursor: pointer; margin-right: 10px; text-decoration: none; display: inline-block; }
        .btn:hover { background: #5568d3; }
        .btn-secondary { background: #6c757d; }
        .help-text { font-size: 12px; color: #6c757d; margin-top: 5px; }
        .info-box {
            background: #e7f3ff;
            border-left: 4px solid #2196F3;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 6px;
        }
        .info-box strong { color: #1976D2; }
    </style>
</head>
<body>
    <div class="header">
        <h1>✏️ Sửa Mã Giảm Giá</h1>
    </div>
    
    <div class="container">
        <div class="card">
            <?php if($error): ?>
                <div class="error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            
            <div class="info-box">
                <strong>Mã Coupon:</strong> <?= htmlspecialchars($coupon['coupon_code']) ?><br>
                <strong>Đã sử dụng:</strong> <?= $coupon['used_count'] ?> lần
            </div>
            
            <form method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label>Loại Giảm Giá *</label>
                        <select name="discount_type" required>
                            <option value="percent" <?= $coupon['discount_type'] == 'percent' ? 'selected' : '' ?>>Phần trăm (%)</option>
                            <option value="fixed" <?= $coupon['discount_type'] == 'fixed' ? 'selected' : '' ?>>Số tiền cố định</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Giá Trị Giảm *</label>
                        <input type="number" name="discount_value" value="<?= $coupon['discount_value'] ?>" 
                               required min="0" step="0.01">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Đơn Hàng Tối Thiểu (VNĐ)</label>
                    <input type="number" name="min_order_value" value="<?= $coupon['min_order_value'] ?>" 
                           min="0" step="1000">
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Tổng Số Lần Dùng</label>
                        <input type="number" name="max_uses" value="<?= $coupon['max_uses'] ?? '' ?>" min="1">
                        <div class="help-text">Để trống = không giới hạn</div>
                    </div>
                    
                    <div class="form-group">
                        <label>Số Lần/1 User *</label>
                        <input type="number" name="max_uses_per_user" value="<?= $coupon['max_uses_per_user'] ?>" 
                               min="1" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Ngày Hết Hạn *</label>
                        <input type="date" name="expiry_date" value="<?= $coupon['expiry_date'] ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Trạng Thái *</label>
                        <select name="status" required>
                            <option value="active" <?= $coupon['status'] == 'active' ? 'selected' : '' ?>>Hoạt động</option>
                            <option value="inactive" <?= $coupon['status'] == 'inactive' ? 'selected' : '' ?>>Tắt</option>
                        </select>
                    </div>
                </div>
                
                <div style="margin-top: 30px;">
                    <button type="submit" class="btn">💾 Cập Nhật</button>
                    <a href="index.php" class="btn btn-secondary">❌ Hủy</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
