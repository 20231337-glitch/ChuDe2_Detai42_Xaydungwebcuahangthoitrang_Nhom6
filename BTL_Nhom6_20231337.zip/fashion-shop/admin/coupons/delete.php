<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

$id = $_GET['id'] ?? 0;

// Delete coupon
$sql = "DELETE FROM coupons WHERE coupon_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);

// Log
$log_sql = "INSERT INTO admin_logs (admin_id, action, table_name, record_id, created_at)
            VALUES (?, 'DELETE', 'coupons', ?, NOW())";
$log_stmt = mysqli_prepare($conn, $log_sql);
mysqli_stmt_bind_param($log_stmt, 'ii', $_SESSION['user_id'], $id);
mysqli_stmt_execute($log_stmt);

header('Location: index.php');
exit;
?>
