<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $coupon_code = strtoupper(trim($_POST['coupon_code'] ?? ''));
    $discount_type = $_POST['discount_type'] ?? 'percent';
    $discount_value = $_POST['discount_value'] ?? 0;
    $min_order_value = $_POST['min_order_value'] ?? 0;
    $max_uses = $_POST['max_uses'] ?? null;
    $max_uses_per_user = $_POST['max_uses_per_user'] ?? 1;
    $expiry_date = $_POST['expiry_date'] ?? '';
    $status = $_POST['status'] ?? 'active';
    
    // Validate
    if (empty($coupon_code)) {
        $error = 'Vui lòng nhập mã coupon';
    } elseif ($discount_value <= 0) {
        $error = 'Giá trị giảm giá phải lớn hơn 0';
    } elseif ($discount_type == 'percent' && $discount_value > 100) {
        $error = 'Giảm giá phần trăm không được vượt quá 100%';
    } elseif (empty($expiry_date)) {
        $error = 'Vui lòng chọn ngày hết hạn';
    } else {
        // Kiểm tra mã đã tồn tại chưa
        $check_sql = "SELECT coupon_id FROM coupons WHERE coupon_code = ?";
        $check_stmt = mysqli_prepare($conn, $check_sql);
        mysqli_stmt_bind_param($check_stmt, 's', $coupon_code);
        mysqli_stmt_execute($check_stmt);
        $check_result = mysqli_stmt_get_result($check_stmt);
        
        if (mysqli_num_rows($check_result) > 0) {
            $error = 'Mã coupon này đã tồn tại!';
        } else {
            // Insert
            $sql = "INSERT INTO coupons (
                        coupon_code, discount_type, discount_value, 
                        min_order_value, max_uses, max_uses_per_user,
                        expiry_date, status, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
            
            $stmt = mysqli_prepare($conn, $sql);
            
            // Handle NULL for max_uses
            if (empty($max_uses)) {
                $max_uses = null;
            }
            
            mysqli_stmt_bind_param($stmt, 'ssdiiiis', 
                $coupon_code, $discount_type, $discount_value,
                $min_order_value, $max_uses, $max_uses_per_user,
                $expiry_date, $status
            );
            
            if (mysqli_stmt_execute($stmt)) {
                $coupon_id = mysqli_insert_id($conn);
                
                // Ghi log
                $log_sql = "INSERT INTO admin_logs (admin_id, action, table_name, record_id, new_value, created_at)
                            VALUES (?, 'CREATE', 'coupons', ?, ?, NOW())";
                $log_stmt = mysqli_prepare($conn, $log_sql);
                $new_value = json_encode([
                    'coupon_code' => $coupon_code,
                    'discount_type' => $discount_type,
                    'discount_value' => $discount_value
                ]);
                mysqli_stmt_bind_param($log_stmt, 'iis', $_SESSION['user_id'], $coupon_id, $new_value);
                mysqli_stmt_execute($log_stmt);
                
                header('Location: index.php');
                exit;
            } else {
                $error = 'Có lỗi xảy ra: ' . mysqli_error($conn);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tạo Mã Giảm Giá Mới</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 40px;
        }
        .header h1 { font-size: 24px; }
        
        .container { max-width: 800px; margin: 30px auto; padding: 0 20px; }
        
        .card {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        
        .form-group { margin-bottom: 20px; }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #333;
        }
        
        .form-group input, .form-group select {
            width: 100%;
            padding: 10px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            font-size: 14px;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .error {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        
        .btn {
            padding: 12px 30px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            margin-right: 10px;
            text-decoration: none;
            display: inline-block;
        }
        .btn:hover { background: #5568d3; }
        
        .btn-secondary { background: #6c757d; }
        .btn-secondary:hover { background: #5a6268; }
        
        .help-text {
            font-size: 12px;
            color: #6c757d;
            margin-top: 5px;
        }
        
        .preview-box {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            border-left: 4px solid #667eea;
            margin-top: 20px;
        }
        
        .preview-box h3 { font-size: 14px; margin-bottom: 10px; color: #667eea; }
        .preview-code { 
            font-family: 'Courier New', monospace;
            font-size: 24px;
            font-weight: bold;
            color: #333;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>➕ Tạo Mã Giảm Giá Mới</h1>
    </div>
    
    <div class="container">
        <div class="card">
            <?php if($error): ?>
                <div class="error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            
            <form method="POST" id="couponForm">
                <div class="form-group">
                    <label>Mã Coupon *</label>
                    <input type="text" name="coupon_code" id="coupon_code" required 
                           placeholder="VD: SALE10, TET2025, FREESHIP"
                           style="text-transform: uppercase;">
                    <div class="help-text">Mã sẽ tự động chuyển thành chữ HOA</div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Loại Giảm Giá *</label>
                        <select name="discount_type" id="discount_type" required>
                            <option value="percent">Phần trăm (%)</option>
                            <option value="fixed">Số tiền cố định (VNĐ)</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Giá Trị Giảm *</label>
                        <input type="number" name="discount_value" id="discount_value" required 
                               min="0" step="0.01" placeholder="Nhập giá trị">
                        <div class="help-text" id="value_hint">Nhập % (0-100) hoặc số tiền</div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Đơn Hàng Tối Thiểu (VNĐ)</label>
                    <input type="number" name="min_order_value" value="0" min="0" step="1000">
                    <div class="help-text">Đơn hàng phải đạt giá trị tối thiểu này mới áp dụng được mã</div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Tổng Số Lần Dùng</label>
                        <input type="number" name="max_uses" min="1" placeholder="Để trống = không giới hạn">
                        <div class="help-text">Tổng số lần mã này có thể được sử dụng</div>
                    </div>
                    
                    <div class="form-group">
                        <label>Số Lần/1 User *</label>
                        <input type="number" name="max_uses_per_user" value="1" min="1" required>
                        <div class="help-text">Mỗi khách hàng dùng tối đa bao nhiêu lần</div>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Ngày Hết Hạn *</label>
                        <input type="date" name="expiry_date" required 
                               min="<?= date('Y-m-d') ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Trạng Thái *</label>
                        <select name="status" required>
                            <option value="active">Hoạt động</option>
                            <option value="inactive">Tắt</option>
                        </select>
                    </div>
                </div>
                
                <!-- Preview -->
                <div class="preview-box" id="preview" style="display: none;">
                    <h3>📋 Xem Trước Mã Giảm Giá</h3>
                    <div class="preview-code" id="preview_code">SALE10</div>
                    <div id="preview_desc"></div>
                </div>
                
                <div style="margin-top: 30px;">
                    <button type="submit" class="btn">💾 Tạo Mã Giảm Giá</button>
                    <a href="index.php" class="btn btn-secondary">❌ Hủy</a>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        // Auto uppercase coupon code
        document.getElementById('coupon_code').addEventListener('input', function(e) {
            this.value = this.value.toUpperCase();
            updatePreview();
        });
        
        // Update hint based on discount type
        document.getElementById('discount_type').addEventListener('change', function() {
            const hint = document.getElementById('value_hint');
            if (this.value === 'percent') {
                hint.textContent = 'Nhập phần trăm (0-100)';
            } else {
                hint.textContent = 'Nhập số tiền giảm (VNĐ)';
            }
            updatePreview();
        });
        
        // Update preview
        document.getElementById('discount_value').addEventListener('input', updatePreview);
        document.querySelector('[name="min_order_value"]').addEventListener('input', updatePreview);
        
        function updatePreview() {
            const code = document.getElementById('coupon_code').value;
            const type = document.getElementById('discount_type').value;
            const value = document.getElementById('discount_value').value;
            const minOrder = document.querySelector('[name="min_order_value"]').value;
            
            if (code && value) {
                document.getElementById('preview').style.display = 'block';
                document.getElementById('preview_code').textContent = code;
                
                let desc = 'Giảm ';
                if (type === 'percent') {
                    desc += value + '%';
                } else {
                    desc += Number(value).toLocaleString('vi-VN') + 'đ';
                }
                
                if (minOrder > 0) {
                    desc += ' cho đơn hàng từ ' + Number(minOrder).toLocaleString('vi-VN') + 'đ';
                }
                
                document.getElementById('preview_desc').textContent = desc;
            } else {
                document.getElementById('preview').style.display = 'none';
            }
        }
    </script>
</body>
</html>
