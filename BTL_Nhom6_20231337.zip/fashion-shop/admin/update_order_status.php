<?php
require_once __DIR__ . '/includes/check_admin.php';

session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

// Kiểm tra đăng nhập admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

$order_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$new_status = isset($_GET['status']) ? $_GET['status'] : '';

$allowed_statuses = ['pending', 'confirmed', 'shipping', 'delivered', 'cancelled'];

if ($order_id <= 0 || !in_array($new_status, $allowed_statuses)) {
    $_SESSION['error'] = 'Dữ liệu không hợp lệ!';
    header('Location: orders.php');
    exit();
}

try {
    $pdo->beginTransaction();

    // Lấy thông tin đơn hàng hiện tại
    $sql = "SELECT * FROM orders WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$order_id]);
    $order = $stmt->fetch();

    if (!$order) {
        throw new Exception('Đơn hàng không tồn tại!');
    }

    // Kiểm tra logic chuyển trạng thái
    $current_status = $order['status'];
    
    // Không cho phép chuyển trạng thái nếu đơn đã hủy hoặc đã giao
    if (in_array($current_status, ['cancelled', 'delivered'])) {
        throw new Exception('Không thể thay đổi trạng thái đơn hàng này!');
    }

    // Logic chuyển trạng thái hợp lệ
    $valid_transitions = [
        'pending' => ['confirmed', 'cancelled'],
        'confirmed' => ['shipping', 'cancelled'],
        'shipping' => ['delivered', 'cancelled']
    ];

    if (!isset($valid_transitions[$current_status]) || !in_array($new_status, $valid_transitions[$current_status])) {
        throw new Exception('Không thể chuyển từ trạng thái "' . $current_status . '" sang "' . $new_status . '"!');
    }

    // Cập nhật trạng thái đơn hàng
    $sql = "UPDATE orders SET status = ?, updated_at = NOW() WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$new_status, $order_id]);

    // Thêm vào lịch sử trạng thái
    $sql = "INSERT INTO order_status_history (order_id, status, notes, created_at) 
            VALUES (?, ?, ?, NOW())";
    $notes = 'Cập nhật bởi Admin: ' . $_SESSION['full_name'];
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$order_id, $new_status, $notes]);

    // Nếu đơn hàng đã giao, cập nhật trạng thái thanh toán (nếu là COD)
    if ($new_status === 'delivered' && $order['payment_method'] === 'cod') {
        $sql = "UPDATE orders SET payment_status = 'paid' WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$order_id]);
    }

    $pdo->commit();
    $_SESSION['success'] = 'Cập nhật trạng thái đơn hàng thành công!';

} catch (Exception $e) {
    $pdo->rollBack();
    $_SESSION['error'] = 'Lỗi: ' . $e->getMessage();
}

header('Location: order_detail.php?id=' . $order_id);
exit();
?>
