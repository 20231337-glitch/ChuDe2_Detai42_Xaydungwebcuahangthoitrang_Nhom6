<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

$result = mysqli_query($conn, "SELECT * FROM colors ORDER BY display_order");
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản Lý Màu Sắc</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px 40px; }
        .header h1 { font-size: 24px; }
        .header a { color: white; text-decoration: none; margin-left: 20px; }
        .container { max-width: 1000px; margin: 30px auto; padding: 0 20px; }
        .card { background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .card-header { display: flex; justify-content: space-between; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 2px solid #667eea; }
        .btn { padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 6px; display: inline-block; }
        .btn-success { background: #28a745; }
        .btn-danger { background: #dc3545; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f8f9fa; }
        tr:hover { background: #f8f9fa; }
        .color-preview { width: 40px; height: 40px; border-radius: 6px; border: 2px solid #ddd; }
        .actions { display: flex; gap: 10px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🎨 Quản Lý Màu Sắc</h1>
        <div><a href="../dashboard/">← Dashboard</a> <a href="../auth/logout.php">Đăng xuất</a></div>
    </div>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2>Danh Sách Màu Sắc</h2>
                <a href="create.php" class="btn btn-success">+ Thêm Màu</a>
            </div>
            <table>
                <tr><th>ID</th><th>Preview</th><th>Tên Màu</th><th>Mã Màu</th><th>Thứ Tự</th><th>Thao Tác</th></tr>
                <?php while($color = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?= $color['color_id'] ?></td>
                    <td>
                        <div class="color-preview" style="background-color: <?= htmlspecialchars($color['color_code']) ?>"></div>
                    </td>
                    <td><strong><?= htmlspecialchars($color['color_name']) ?></strong></td>
                    <td><?= htmlspecialchars($color['color_code']) ?></td>
                    <td><?= $color['display_order'] ?></td>
                    <td class="actions">
                        <a href="edit.php?id=<?= $color['color_id'] ?>" class="btn">Sửa</a>
                        <a href="delete.php?id=<?= $color['color_id'] ?>" class="btn btn-danger" 
                           onclick="return confirm('Xóa màu này?')">Xóa</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </table>
        </div>
    </div>
</body>
</html>
