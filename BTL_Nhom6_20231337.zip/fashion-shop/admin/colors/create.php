<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $color_name = trim($_POST['color_name'] ?? '');
    $color_code = trim($_POST['color_code'] ?? '#000000');
    $display_order = $_POST['display_order'] ?? 0;
    
    if (empty($color_name)) {
        $error = 'Vui lòng nhập tên màu';
    } else {
        $sql = "INSERT INTO colors (color_name, color_code, display_order) VALUES (?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, 'ssi', $color_name, $color_code, $display_order);
        
        if (mysqli_stmt_execute($stmt)) {
            header('Location: index.php');
            exit;
        } else {
            $error = 'Có lỗi: ' . mysqli_error($conn);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thêm Màu Sắc</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px 40px; }
        .container { max-width: 600px; margin: 30px auto; padding: 0 20px; }
        .card { background: white; padding: 30px; border-radius: 12px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 500; }
        .form-group input { width: 100%; padding: 10px; border: 2px solid #e0e0e0; border-radius: 6px; }
        input[type="color"] { height: 50px; cursor: pointer; }
        .error { background: #fee; color: #c33; padding: 12px; border-radius: 6px; margin-bottom: 20px; }
        .btn { padding: 12px 30px; background: #667eea; color: white; border: none; border-radius: 6px; cursor: pointer; margin-right: 10px; }
        .btn-secondary { background: #6c757d; text-decoration: none; display: inline-block; }
    </style>
</head>
<body>
    <div class="header"><h1>➕ Thêm Màu Sắc Mới</h1></div>
    <div class="container">
        <div class="card">
            <?php if($error): ?><div class="error"><?= $error ?></div><?php endif; ?>
            <form method="POST">
                <div class="form-group">
                    <label>Tên Màu *</label>
                    <input type="text" name="color_name" required placeholder="VD: Đỏ, Xanh, Vàng...">
                </div>
                <div class="form-group">
                    <label>Mã Màu (HEX) *</label>
                    <input type="color" name="color_code" value="#000000">
                </div>
                <div class="form-group">
                    <label>Thứ Tự Hiển Thị</label>
                    <input type="number" name="display_order" value="0">
                </div>
                <button type="submit" class="btn">Lưu Màu</button>
                <a href="index.php" class="btn btn-secondary">Hủy</a>
            </form>
        </div>
    </div>
</body>
</html>
