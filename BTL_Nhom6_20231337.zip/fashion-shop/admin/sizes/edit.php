<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

$id = $_GET['id'] ?? 0;
$sql = "SELECT * FROM sizes WHERE size_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$size = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$size) {
    header('Location: index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $size_name = trim($_POST['size_name'] ?? '');
    $display_order = $_POST['display_order'] ?? 0;
    
    if (empty($size_name)) {
        $error = 'Vui lòng nhập tên size';
    } else {
        $sql = "UPDATE sizes SET size_name = ?, display_order = ? WHERE size_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, 'sii', $size_name, $display_order, $id);
        
        if (mysqli_stmt_execute($stmt)) {
            header('Location: index.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Sửa Size</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px 40px; }
        .container { max-width: 600px; margin: 30px auto; padding: 0 20px; }
        .card { background: white; padding: 30px; border-radius: 12px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 500; }
        .form-group input { width: 100%; padding: 10px; border: 2px solid #e0e0e0; border-radius: 6px; }
        .btn { padding: 12px 30px; background: #667eea; color: white; border: none; border-radius: 6px; cursor: pointer; margin-right: 10px; }
        .btn-secondary { background: #6c757d; text-decoration: none; display: inline-block; }
    </style>
</head>
<body>
    <div class="header"><h1>✏️ Sửa Size</h1></div>
    <div class="container">
        <div class="card">
            <form method="POST">
                <div class="form-group">
                    <label>Tên Size *</label>
                    <input type="text" name="size_name" value="<?= htmlspecialchars($size['size_name']) ?>" required>
                </div>
                <div class="form-group">
                    <label>Thứ Tự Hiển Thị</label>
                    <input type="number" name="display_order" value="<?= $size['display_order'] ?>">
                </div>
                <button type="submit" class="btn">Cập Nhật</button>
                <a href="index.php" class="btn btn-secondary">Hủy</a>
            </form>
        </div>
    </div>
</body>
</html>
