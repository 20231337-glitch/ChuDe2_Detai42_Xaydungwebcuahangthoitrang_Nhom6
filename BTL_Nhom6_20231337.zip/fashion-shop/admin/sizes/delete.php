<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

$id = $_GET['id'] ?? 0;
mysqli_query($conn, "DELETE FROM sizes WHERE size_id = $id");
header('Location: index.php');
exit;
?>
