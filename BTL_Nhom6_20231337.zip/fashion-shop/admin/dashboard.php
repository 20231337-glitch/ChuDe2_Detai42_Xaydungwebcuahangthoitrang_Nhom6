<?php
require_once __DIR__ . '/includes/check_admin.php';

/**
 * Admin Dashboard - Trang tổng quan
 */
require_once '../config/config.php';
require_once 'includes/auth_check.php';

$page_title = 'Dashboard';

// Lấy thống kê tổng quan
$stats = [];

// Tổng số sản phẩm
$sql = "SELECT COUNT(*) as total FROM products WHERE is_active = 1";
$result = fetchRow($sql);
$stats['total_products'] = $result['total'] ?? 0;

// Tổng số đơn hàng
$sql = "SELECT COUNT(*) as total FROM orders";
$result = fetchRow($sql);
$stats['total_orders'] = $result['total'] ?? 0;

// Tổng số khách hàng
$sql = "SELECT COUNT(*) as total FROM customers WHERE is_active = 1";
$result = fetchRow($sql);
$stats['total_customers'] = $result['total'] ?? 0;

// Doanh thu tháng này
$sql = "SELECT COALESCE(SUM(total_amount), 0) as revenue 
        FROM orders 
        WHERE MONTH(order_date) = MONTH(CURRENT_DATE()) 
        AND YEAR(order_date) = YEAR(CURRENT_DATE())
        AND order_status != 'Đã hủy'";
$result = fetchRow($sql);
$stats['monthly_revenue'] = $result['revenue'] ?? 0;

// Đơn hàng chờ xử lý
$sql = "SELECT COUNT(*) as total FROM orders WHERE order_status = 'Chờ xử lý'";
$result = fetchRow($sql);
$stats['pending_orders'] = $result['total'] ?? 0;

// Đơn hàng gần đây
$recent_orders = fetchData("
    SELECT o.*, c.full_name as customer_name 
    FROM orders o
    LEFT JOIN customers c ON o.customer_id = c.customer_id
    ORDER BY o.order_date DESC
    LIMIT 10
");

// Sản phẩm bán chạy
$top_products = fetchData("
    SELECT p.product_name, SUM(od.quantity) as total_sold,
           SUM(od.quantity * od.unit_price) as revenue
    FROM order_details od
    JOIN products p ON od.product_id = p.product_id
    GROUP BY p.product_id
    ORDER BY total_sold DESC
    LIMIT 5
");

include 'includes/header.php';
?>

<div class="dashboard">
    <!-- Statistics Cards -->
    <div class="stats-grid">
        <div class="stat-card bg-blue">
            <div class="stat-icon">📦</div>
            <div class="stat-info">
                <h3><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo number_format($stats['total_products']); ?></h3>
                <p>Sản phẩm</p>
            </div>
        </div>
        
        <div class="stat-card bg-green">
            <div class="stat-icon">🛒</div>
            <div class="stat-info">
                <h3><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo number_format($stats['total_orders']); ?></h3>
                <p>Đơn hàng</p>
            </div>
        </div>
        
        <div class="stat-card bg-purple">
            <div class="stat-icon">👥</div>
            <div class="stat-info">
                <h3><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo number_format($stats['total_customers']); ?></h3>
                <p>Khách hàng</p>
            </div>
        </div>
        
        <div class="stat-card bg-orange">
            <div class="stat-icon">💰</div>
            <div class="stat-info">
                <h3><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo formatPrice($stats['monthly_revenue']); ?></h3>
                <p>Doanh thu tháng</p>
            </div>
        </div>
    </div>
    
    <!-- Alerts -->
    <?php
require_once __DIR__ . '/includes/check_admin.php';
 if ($stats['pending_orders'] > 0): ?>
        <div class="alert alert-warning">
            ⚠️ Có <strong><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $stats['pending_orders']; ?></strong> đơn hàng đang chờ xử lý!
            <a href="<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo BASE_URL; ?>/admin/orders/">Xem ngay →</a>
        </div>
    <?php
require_once __DIR__ . '/includes/check_admin.php';
 endif; ?>
    
    <!-- Content Grid -->
    <div class="dashboard-grid">
        <!-- Recent Orders -->
        <div class="dashboard-card">
            <div class="card-header">
                <h3>🛒 Đơn hàng gần đây</h3>
                <a href="<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo BASE_URL; ?>/admin/orders/" class="btn-link">Xem tất cả →</a>
            </div>
            <div class="card-body">
                <?php
require_once __DIR__ . '/includes/check_admin.php';
 if (empty($recent_orders)): ?>
                    <p class="text-muted">Chưa có đơn hàng nào.</p>
                <?php
require_once __DIR__ . '/includes/check_admin.php';
 else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Mã ĐH</th>
                                <th>Khách hàng</th>
                                <th>Tổng tiền</th>
                                <th>Trạng thái</th>
                                <th>Ngày đặt</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
require_once __DIR__ . '/includes/check_admin.php';
 foreach ($recent_orders as $order): ?>
                                <tr>
                                    <td><strong>#<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $order['order_id']; ?></strong></td>
                                    <td><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $order['customer_name'] ?? 'N/A'; ?></td>
                                    <td><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo formatPrice($order['total_amount']); ?></td>
                                    <td>
                                        <span class="badge badge-<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo getOrderStatusClass($order['order_status']); ?>">
                                            <?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $order['order_status']; ?>
                                        </span>
                                    </td>
                                    <td><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo formatDate($order['order_date']); ?></td>
                                </tr>
                            <?php
require_once __DIR__ . '/includes/check_admin.php';
 endforeach; ?>
                        </tbody>
                    </table>
                <?php
require_once __DIR__ . '/includes/check_admin.php';
 endif; ?>
            </div>
        </div>
        
        <!-- Top Products -->
        <div class="dashboard-card">
            <div class="card-header">
                <h3>🏆 Sản phẩm bán chạy</h3>
            </div>
            <div class="card-body">
                <?php
require_once __DIR__ . '/includes/check_admin.php';
 if (empty($top_products)): ?>
                    <p class="text-muted">Chưa có dữ liệu.</p>
                <?php
require_once __DIR__ . '/includes/check_admin.php';
 else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Sản phẩm</th>
                                <th>Đã bán</th>
                                <th>Doanh thu</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
require_once __DIR__ . '/includes/check_admin.php';
 foreach ($top_products as $product): ?>
                                <tr>
                                    <td><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $product['product_name']; ?></td>
                                    <td><strong><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $product['total_sold']; ?></strong></td>
                                    <td><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo formatPrice($product['revenue']); ?></td>
                                </tr>
                            <?php
require_once __DIR__ . '/includes/check_admin.php';
 endforeach; ?>
                        </tbody>
                    </table>
                <?php
require_once __DIR__ . '/includes/check_admin.php';
 endif; ?>
            </div>
        </div>
    </div>
</div>

<?php
require_once __DIR__ . '/includes/check_admin.php';

// Helper function cho badge color
function getOrderStatusClass($status) {
    switch ($status) {
        case 'Chờ xử lý': return 'warning';
        case 'Đã xác nhận': return 'info';
        case 'Đang giao hàng': return 'primary';
        case 'Hoàn thành': return 'success';
        case 'Đã hủy': return 'danger';
        default: return 'secondary';
    }
}

include 'includes/footer.php';
?>
