<?php
/**
 * Header chung cho Admin Panel
 */
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Admin Panel'; ?> - Fashion Shop</title>
    <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>/css/admin/style.css">
    <?php if (isset($extra_css)): ?>
        <?php foreach ($extra_css as $css): ?>
            <link rel="stylesheet" href="<?php echo $css; ?>">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>👔 FASHION SHOP</h2>
                <p>Admin Panel</p>
            </div>
            
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="<?php echo BASE_URL; ?>/admin/dashboard.php" class="<?php echo (basename($_SERVER['PHP_SELF']) == 'dashboard.php') ? 'active' : ''; ?>">
                        📊 Dashboard
                    </a></li>
                    
                    <li class="nav-section">Sản phẩm</li>
                    <li><a href="<?php echo BASE_URL; ?>/admin/categories/">📁 Danh mục</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/admin/products/">👕 Sản phẩm</a></li>
                    
                    <li class="nav-section">Bán hàng</li>
                    <li><a href="<?php echo BASE_URL; ?>/admin/orders/">🛒 Đơn hàng</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/admin/customers/">👥 Khách hàng</a></li>
                    
                    <li class="nav-section">Quản lý</li>
                    <li><a href="<?php echo BASE_URL; ?>/admin/employees/">👨‍💼 Nhân viên</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/admin/suppliers/">🏭 Nhà cung cấp</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/admin/promotions/">🎁 Khuyến mãi</a></li>
                    
                    <li class="nav-section">Báo cáo</li>
                    <li><a href="<?php echo BASE_URL; ?>/admin/reports/">📈 Thống kê</a></li>
                </ul>
            </nav>
        </aside>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Bar -->
            <header class="topbar">
                <div class="topbar-left">
                    <h1><?php echo $page_title ?? 'Dashboard'; ?></h1>
                </div>
                <div class="topbar-right">
                    <span class="user-info">
                        👤 <?php echo $current_full_name; ?>
                    </span>
                    <a href="<?php echo BASE_URL; ?>/admin/logout.php" class="btn-logout">Đăng xuất</a>
                </div>
            </header>
            
            <!-- Flash Messages -->
            <?php $flash = getFlashMessage(); ?>
            <?php if ($flash): ?>
                <div class="alert alert-<?php echo $flash['type']; ?>">
                    <?php echo $flash['message']; ?>
                </div>
            <?php endif; ?>
            
            <!-- Page Content -->
            <div class="page-content">
