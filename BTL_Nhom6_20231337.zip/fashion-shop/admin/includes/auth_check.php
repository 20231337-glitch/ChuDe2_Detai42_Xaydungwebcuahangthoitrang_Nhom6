<?php
/**
 * Middleware kiểm tra quyền truy cập Admin
 */

// Kiểm tra session
if (!isLoggedIn()) {
    redirect(BASE_URL . '/admin/index.php');
    exit();
}

// Kiểm tra quyền Admin
if (!isAdmin()) {
    redirect(BASE_URL . '/index.php');
    exit();
}

// Lấy thông tin user hiện tại
$current_user_id = getCurrentUserId();
$current_username = $_SESSION['username'];
$current_full_name = $_SESSION['full_name'];
?>
