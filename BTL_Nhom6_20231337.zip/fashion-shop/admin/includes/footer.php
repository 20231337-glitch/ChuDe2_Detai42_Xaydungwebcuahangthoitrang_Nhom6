            </div>
            <!-- End Page Content -->
            
            <footer class="admin-footer">
                <p>&copy; 2024 Fashion Shop Admin Panel. All rights reserved.</p>
            </footer>
        </div>
        <!-- End Main Content -->
    </div>
    
    <script src="<?php echo ASSETS_URL; ?>/js/admin/script.js"></script>
    <?php if (isset($extra_js)): ?>
        <?php foreach ($extra_js as $js): ?>
            <script src="<?php echo $js; ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>
