<?php
/**
 * Admin Access Control - Kiểm tra quyền truy cập Admin
 * File này được thêm vào tất cả các trang admin để bảo vệ khỏi truy cập trái phép
 */

// Khởi động session nếu chưa có
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Kiểm tra user đã đăng nhập chưa
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    // Chuyển hướng về trang login admin
    header('Location: ' . (defined('BASE_URL') ? BASE_URL : '') . '/admin/auth/login.php');
    exit;
}

// Kiểm tra role có phải admin không
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    // Không phải admin, chuyển về trang chủ
    header('Location: ' . (defined('BASE_URL') ? BASE_URL : '') . '/index.php');
    exit;
}

// Lấy thông tin admin hiện tại
$current_user_id = $_SESSION['user_id'];
$current_username = $_SESSION['username'] ?? 'admin';
$current_role = $_SESSION['role'];
?>