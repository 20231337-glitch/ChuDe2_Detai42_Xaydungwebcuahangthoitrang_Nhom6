﻿# ADMIN PANEL - FASHION SHOP

## 📋 Tài khoản đăng nhập mặc định

**Username:** admin  
**Password:** admin123

## 🚀 Hướng dẫn sử dụng

### Bước 1: Import Database
Chạy file SQL để tạo tài khoản admin:
```sql
mysql -u root fashion_shop < admin/setup_admin.sql
```

Hoặc copy nội dung file setup_admin.sql và chạy trong phpMyAdmin.

### Bước 2: Truy cập Admin Panel
Mở trình duyệt và truy cập:
```
http://localhost/fashion-shop/admin/
```

### Bước 3: Đăng nhập
- Nhập username: dmin
- Nhập password: dmin123
- Click "Đăng nhập"

## 📂 Cấu trúc Admin Panel
```
admin/
├── index.php              # Trang đăng nhập
├── dashboard.php          # Dashboard chính
├── logout.php             # Đăng xuất
├── setup_admin.sql        # SQL tạo tài khoản admin
├── includes/
│   ├── auth_check.php     # Middleware xác thực
│   ├── header.php         # Header chung
│   └── footer.php         # Footer chung
├── categories/            # Quản lý danh mục (đang phát triển)
├── products/              # Quản lý sản phẩm (đang phát triển)
├── orders/                # Quản lý đơn hàng (đang phát triển)
├── customers/             # Quản lý khách hàng (đang phát triển)
├── employees/             # Quản lý nhân viên (đang phát triển)
├── suppliers/             # Quản lý nhà cung cấp (đang phát triển)
├── promotions/            # Quản lý khuyến mãi (đang phát triển)
└── reports/               # Báo cáo thống kê (đang phát triển)
```

## ✅ Chức năng đã hoàn thành (Giai đoạn 1)

- ✓ Hệ thống đăng nhập Admin
- ✓ Dashboard với thống kê tổng quan
- ✓ Sidebar navigation
- ✓ Bảo mật middleware
- ✓ Responsive design
- ✓ Session management

## 🔜 Chức năng sẽ phát triển

Các module quản lý chi tiết sẽ được phát triển trong các giai đoạn tiếp theo.

## 🔒 Bảo mật

- Tất cả trang admin đều được bảo vệ bởi middleware uth_check.php
- Password được hash bằng password_hash() (bcrypt)
- Session timeout tự động
- SQL Injection prevention với Prepared Statements

## 📞 Hỗ trợ

Nếu gặp vấn đề, vui lòng kiểm tra:
1. XAMPP Apache đang chạy
2. Database đã import đầy đủ
3. File config/database.php có thông tin đúng
4. Đã chạy file setup_admin.sql

---
© 2024 Fashion Shop Admin Panel
