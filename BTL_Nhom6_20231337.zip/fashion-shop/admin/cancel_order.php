<?php
require_once __DIR__ . '/includes/check_admin.php';

session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

// Kiểm tra đăng nhập admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

$order_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($order_id <= 0) {
    $_SESSION['error'] = 'Dữ liệu không hợp lệ!';
    header('Location: orders.php');
    exit();
}

try {
    $pdo->beginTransaction();

    // Lấy thông tin đơn hàng
    $sql = "SELECT * FROM orders WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$order_id]);
    $order = $stmt->fetch();

    if (!$order) {
        throw new Exception('Đơn hàng không tồn tại!');
    }

    // Kiểm tra trạng thái
    if (in_array($order['status'], ['cancelled', 'delivered'])) {
        throw new Exception('Không thể hủy đơn hàng ở trạng thái này!');
    }

    // Lấy danh sách sản phẩm trong đơn hàng
    $sql = "SELECT variant_id, quantity FROM order_items WHERE order_id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$order_id]);
    $order_items = $stmt->fetchAll();

    // Hoàn trả số lượng sản phẩm vào kho
    foreach ($order_items as $item) {
        $sql = "UPDATE product_variants 
                SET stock_quantity = stock_quantity + ? 
                WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$item['quantity'], $item['variant_id']]);
    }

    // Cập nhật trạng thái đơn hàng thành cancelled
    $sql = "UPDATE orders SET status = 'cancelled', updated_at = NOW() WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$order_id]);

    // Thêm vào lịch sử trạng thái
    $sql = "INSERT INTO order_status_history (order_id, status, notes, created_at) 
            VALUES (?, 'cancelled', ?, NOW())";
    $notes = 'Đơn hàng bị hủy bởi Admin: ' . $_SESSION['full_name'];
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$order_id, $notes]);

    // Nếu đã thanh toán, cập nhật trạng thái thanh toán thành refunded
    if ($order['payment_status'] === 'paid') {
        $sql = "UPDATE orders SET payment_status = 'refunded' WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$order_id]);
    }

    $pdo->commit();
    $_SESSION['success'] = 'Đã hủy đơn hàng và hoàn trả số lượng sản phẩm vào kho!';

} catch (Exception $e) {
    $pdo->rollBack();
    $_SESSION['error'] = 'Lỗi: ' . $e->getMessage();
}

header('Location: order_detail.php?id=' . $order_id);
exit();
?>
