<?php
require_once __DIR__ . '/../includes/check_admin.php';

session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

$order_id = $_GET['id'] ?? 0;
$error = '';
$success = '';

// Lấy thông tin đơn hàng
$sql = "SELECT o.*, u.fullname 
        FROM orders o
        JOIN users u ON o.user_id = u.user_id
        WHERE o.order_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $order_id);
mysqli_stmt_execute($stmt);
$order = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$order) {
    header('Location: index.php');
    exit;
}

// Xử lý cập nhật
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_status = $_POST['order_status'] ?? '';
    $payment_status = $_POST['payment_status'] ?? $order['payment_status'];
    $note = trim($_POST['note'] ?? '');
    
    if (empty($new_status)) {
        $error = 'Vui lòng chọn trạng thái';
    } else {
        // Validate workflow
        $valid_transitions = [
            'processing' => ['confirmed', 'cancelled'],
            'confirmed' => ['shipping', 'cancelled'],
            'shipping' => ['completed', 'cancelled'],
            'completed' => [],
            'cancelled' => []
        ];
        
        if (!in_array($new_status, $valid_transitions[$order['order_status']])) {
            $error = 'Không thể chuyển từ trạng thái "' . $order['order_status'] . '" sang "' . $new_status . '"';
        } else {
            // BEGIN TRANSACTION
            mysqli_begin_transaction($conn);
            
            try {
                // Update order status
                $update_sql = "UPDATE orders 
                               SET order_status = ?, payment_status = ?
                               WHERE order_id = ?";
                $stmt = mysqli_prepare($conn, $update_sql);
                mysqli_stmt_bind_param($stmt, 'ssi', $new_status, $payment_status, $order_id);
                mysqli_stmt_execute($stmt);
                
                // Tạo thông báo cho khách hàng
                $notification_titles = [
                    'confirmed' => 'Đơn hàng đã được xác nhận',
                    'shipping' => 'Đơn hàng đang được giao',
                    'completed' => 'Đơn hàng đã hoàn thành',
                    'cancelled' => 'Đơn hàng đã bị hủy'
                ];
                
                $notification_messages = [
                    'confirmed' => 'Đơn hàng #' . $order_id . ' đã được xác nhận và sẽ sớm được giao đến bạn.',
                    'shipping' => 'Đơn hàng #' . $order_id . ' đang trên đường giao đến bạn.',
                    'completed' => 'Đơn hàng #' . $order_id . ' đã được giao thành công. Cảm ơn bạn đã mua hàng!',
                    'cancelled' => 'Đơn hàng #' . $order_id . ' đã bị hủy.' . ($note ? ' Lý do: ' . $note : '')
                ];
                
                if (isset($notification_titles[$new_status])) {
                    $notif_sql = "INSERT INTO notifications (user_id, type, title, message, link, created_at)
                                  VALUES (?, 'order_update', ?, ?, ?, NOW())";
                    $notif_stmt = mysqli_prepare($conn, $notif_sql);
                    $link = '/public/account/order_detail.php?id=' . $order_id;
                    mysqli_stmt_bind_param($notif_stmt, 'isss', 
                        $order['user_id'], 
                        $notification_titles[$new_status],
                        $notification_messages[$new_status],
                        $link
                    );
                    mysqli_stmt_execute($notif_stmt);
                }
                
                // Ghi log
                $log_sql = "INSERT INTO admin_logs (admin_id, action, table_name, record_id, old_value, new_value, created_at)
                            VALUES (?, 'UPDATE', 'orders', ?, ?, ?, NOW())";
                $log_stmt = mysqli_prepare($conn, $log_sql);
                $old_value = json_encode(['order_status' => $order['order_status']]);
                $new_value = json_encode(['order_status' => $new_status, 'note' => $note]);
                mysqli_stmt_bind_param($log_stmt, 'iiss', $_SESSION['user_id'], $order_id, $old_value, $new_value);
                mysqli_stmt_execute($log_stmt);
                
                // COMMIT
                mysqli_commit($conn);
                
                $success = 'Cập nhật trạng thái thành công!';
                
                // Refresh order data
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, 'i', $order_id);
                mysqli_stmt_execute($stmt);
                $order = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
                
            } catch (Exception $e) {
                mysqli_rollback($conn);
                $error = 'Có lỗi xảy ra: ' . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Cập Nhật Trạng Thái Đơn #<?= $order_id ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 40px;
        }
        .header h1 { font-size: 24px; }
        .header a { color: white; text-decoration: none; margin-right: 20px; }
        
        .container { max-width: 800px; margin: 30px auto; padding: 0 20px; }
        
        .card {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 20px;
        }
        
        .info-box {
            background: #e7f3ff;
            border-left: 4px solid #2196F3;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 6px;
        }
        
        .info-box strong { color: #1976D2; }
        
        .form-group { margin-bottom: 20px; }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #333;
        }
        
        .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            font-size: 14px;
        }
        
        .form-group textarea { min-height: 100px; resize: vertical; }
        
        .help-text {
            font-size: 12px;
            color: #6c757d;
            margin-top: 5px;
        }
        
        .error {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        
        .success {
            background: #d4edda;
            color: #155724;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        
        .btn {
            padding: 12px 30px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            margin-right: 10px;
            text-decoration: none;
            display: inline-block;
        }
        .btn:hover { background: #5568d3; }
        
        .btn-secondary { background: #6c757d; }
        .btn-secondary:hover { background: #5a6268; }
        
        .workflow {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 20px 0;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        
        .workflow-step {
            text-align: center;
            flex: 1;
            position: relative;
        }
        
        .workflow-step:not(:last-child):after {
            content: '→';
            position: absolute;
            right: -20px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
            color: #999;
        }
        
        .workflow-step.active {
            color: #667eea;
            font-weight: bold;
        }
        
        .workflow-step.completed {
            color: #28a745;
        }
        
        .badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 500;
        }
        
        .badge-processing { background: #fff3cd; color: #856404; }
        .badge-confirmed { background: #d1ecf1; color: #0c5460; }
        .badge-shipping { background: #cfe2ff; color: #084298; }
        .badge-completed { background: #d4edda; color: #155724; }
        .badge-cancelled { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🔄 Cập Nhật Trạng Thái Đơn Hàng</h1>
        <a href="detail.php?id=<?= $order_id ?>">← Quay lại chi tiết</a>
        <a href="index.php">Danh sách đơn</a>
    </div>
    
    <div class="container">
        <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($error): ?>
            <div class="error">❌ <?= htmlspecialchars($error) ?></div>
        <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
        
        <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($success): ?>
            <div class="success">✅ <?= htmlspecialchars($success) ?></div>
        <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
        
        <div class="card">
            <div class="info-box">
                <strong>Đơn hàng:</strong> #<?= $order_id ?> - <?= htmlspecialchars($order['fullname']) ?><br>
                <strong>Trạng thái hiện tại:</strong> 
                <span class="badge badge-<?= $order['order_status'] ?>">
                    <?php
require_once __DIR__ . '/../includes/check_admin.php';

                        echo match($order['order_status']) {
                            'processing' => '⏳ Đang xử lý',
                            'confirmed' => '✅ Đã xác nhận',
                            'shipping' => '🚚 Đang giao',
                            'completed' => '✔️ Hoàn thành',
                            'cancelled' => '❌ Đã hủy',
                            default => $order['order_status']
                        };
                    ?>
                </span>
            </div>
            
            <!-- Workflow -->
            <div class="workflow">
                <div class="workflow-step <?= in_array($order['order_status'], ['processing', 'confirmed', 'shipping', 'completed']) ? 'completed' : '' ?>">
                    <div>⏳</div>
                    <small>Đang xử lý</small>
                </div>
                <div class="workflow-step <?= in_array($order['order_status'], ['confirmed', 'shipping', 'completed']) ? 'completed' : '' ?>">
                    <div>✅</div>
                    <small>Đã xác nhận</small>
                </div>
                <div class="workflow-step <?= in_array($order['order_status'], ['shipping', 'completed']) ? 'completed' : '' ?>">
                    <div>🚚</div>
                    <small>Đang giao</small>
                </div>
                <div class="workflow-step <?= $order['order_status'] == 'completed' ? 'completed' : '' ?>">
                    <div>✔️</div>
                    <small>Hoàn thành</small>
                </div>
            </div>
            
            <form method="POST">
                <div class="form-group">
                    <label>Trạng Thái Đơn Hàng *</label>
                    <select name="order_status" required>
                        <?php
require_once __DIR__ . '/../includes/check_admin.php';

                        $statuses = [
                            'processing' => '⏳ Đang xử lý',
                            'confirmed' => '✅ Đã xác nhận',
                            'shipping' => '🚚 Đang giao',
                            'completed' => '✔️ Hoàn thành'
                        ];
                        
                        // Chỉ hiển thị các trạng thái hợp lệ
                        $current = $order['order_status'];
                        foreach($statuses as $key => $label) {
                            $disabled = '';
                            
                            // Logic disable
                            if ($current == 'processing' && !in_array($key, ['processing', 'confirmed'])) {
                                $disabled = 'disabled';
                            } elseif ($current == 'confirmed' && !in_array($key, ['confirmed', 'shipping'])) {
                                $disabled = 'disabled';
                            } elseif ($current == 'shipping' && !in_array($key, ['shipping', 'completed'])) {
                                $disabled = 'disabled';
                            } elseif ($current == 'completed') {
                                $disabled = 'disabled';
                            }
                            
                            $selected = $key == $current ? 'selected' : '';
                            echo "<option value='$key' $selected $disabled>$label</option>";
                        }
                        ?>
                    </select>
                    <div class="help-text">
                        <?php
require_once __DIR__ . '/../includes/check_admin.php';

                        if ($current == 'processing') {
                            echo '💡 Có thể chuyển sang: Đã xác nhận';
                        } elseif ($current == 'confirmed') {
                            echo '💡 Có thể chuyển sang: Đang giao';
                        } elseif ($current == 'shipping') {
                            echo '💡 Có thể chuyển sang: Hoàn thành';
                        } elseif ($current == 'completed') {
                            echo '✓ Đơn hàng đã hoàn thành, không thể thay đổi';
                        }
                        ?>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Trạng Thái Thanh Toán</label>
                    <select name="payment_status">
                        <option value="pending" <?= $order['payment_status'] == 'pending' ? 'selected' : '' ?>>⏳ Chờ thanh toán</option>
                        <option value="paid" <?= $order['payment_status'] == 'paid' ? 'selected' : '' ?>>✓ Đã thanh toán</option>
                        <option value="failed" <?= $order['payment_status'] == 'failed' ? 'selected' : '' ?>>✗ Thất bại</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Ghi Chú (Tùy chọn)</label>
                    <textarea name="note" placeholder="Nhập ghi chú về việc cập nhật trạng thái..."></textarea>
                </div>
                
                <div style="margin-top: 30px;">
                    <button type="submit" class="btn">💾 Cập Nhật Trạng Thái</button>
                    <a href="detail.php?id=<?= $order_id ?>" class="btn btn-secondary">❌ Hủy</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
