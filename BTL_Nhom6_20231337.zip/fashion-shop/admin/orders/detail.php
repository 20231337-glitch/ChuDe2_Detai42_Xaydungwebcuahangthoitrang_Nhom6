<?php
require_once __DIR__ . '/../includes/check_admin.php';

session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

$order_id = $_GET['id'] ?? 0;

// Lấy thông tin đơn hàng
$sql = "SELECT o.*, u.fullname, u.email, u.phone
        FROM orders o
        JOIN users u ON o.user_id = u.user_id
        WHERE o.order_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $order_id);
mysqli_stmt_execute($stmt);
$order = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$order) {
    header('Location: index.php');
    exit;
}

// Lấy chi tiết sản phẩm trong đơn
$details_sql = "SELECT 
                    od.*,
                    p.product_name,
                    pi.image_url
                FROM order_details od
                LEFT JOIN product_variants pv ON od.variant_id = pv.variant_id
                LEFT JOIN products p ON pv.product_id = p.product_id
                LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
                WHERE od.order_id = ?";
$stmt = mysqli_prepare($conn, $details_sql);
mysqli_stmt_bind_param($stmt, 'i', $order_id);
mysqli_stmt_execute($stmt);
$details = mysqli_stmt_get_result($stmt);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Chi Tiết Đơn Hàng #<?= $order_id ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 40px;
        }
        .header h1 { font-size: 24px; }
        .header a { color: white; text-decoration: none; margin-right: 20px; }
        
        .container { max-width: 1200px; margin: 30px auto; padding: 0 20px; }
        
        .card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 20px;
        }
        
        .card h2 {
            font-size: 18px;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #667eea;
            color: #333;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .info-item {
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        
        .info-item label {
            display: block;
            font-size: 12px;
            color: #666;
            margin-bottom: 5px;
            text-transform: uppercase;
        }
        
        .info-item .value {
            font-size: 16px;
            font-weight: 500;
            color: #333;
        }
        
        .badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 500;
        }
        
        .badge-processing { background: #fff3cd; color: #856404; }
        .badge-confirmed { background: #d1ecf1; color: #0c5460; }
        .badge-shipping { background: #cfe2ff; color: #084298; }
        .badge-completed { background: #d4edda; color: #155724; }
        .badge-cancelled { background: #f8d7da; color: #721c24; }
        
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f8f9fa; font-weight: 600; color: #555; font-size: 13px; }
        
        .product-image {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 8px;
            border: 2px solid #eee;
        }
        
        .summary-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        
        .summary-row.total {
            border-bottom: none;
            border-top: 2px solid #333;
            margin-top: 10px;
            padding-top: 15px;
            font-size: 18px;
            font-weight: bold;
        }
        
        .btn {
            padding: 10px 20px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            display: inline-block;
            margin-right: 10px;
        }
        .btn:hover { background: #5568d3; }
        
        .btn-success { background: #28a745; }
        .btn-warning { background: #ffc107; color: #333; }
        .btn-danger { background: #dc3545; }
        
        .timeline {
            position: relative;
            padding-left: 30px;
        }
        
        .timeline-item {
            position: relative;
            padding-bottom: 20px;
        }
        
        .timeline-item:before {
            content: '';
            position: absolute;
            left: -24px;
            top: 0;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #667eea;
            border: 3px solid white;
            box-shadow: 0 0 0 2px #667eea;
        }
        
        .timeline-item:after {
            content: '';
            position: absolute;
            left: -19px;
            top: 12px;
            width: 2px;
            height: calc(100% - 12px);
            background: #e0e0e0;
        }
        
        .timeline-item:last-child:after { display: none; }
        
        .timeline-item.completed:before { background: #28a745; box-shadow: 0 0 0 2px #28a745; }
    </style>
</head>
<body>
    <div class="header">
        <h1>📋 Chi Tiết Đơn Hàng #<?= $order_id ?></h1>
        <a href="index.php">← Quay lại danh sách</a>
    </div>
    
    <div class="container">
        <!-- Thông tin đơn hàng -->
        <div class="card">
            <h2>📦 Thông Tin Đơn Hàng</h2>
            
            <div class="info-grid">
                <div class="info-item">
                    <label>Mã Đơn Hàng</label>
                    <div class="value" style="color: #667eea;">#<?= $order['order_id'] ?></div>
                </div>
                
                <div class="info-item">
                    <label>Ngày Đặt</label>
                    <div class="value"><?= date('d/m/Y H:i', strtotime($order['order_date'])) ?></div>
                </div>
                
                <div class="info-item">
                    <label>Trạng Thái Đơn</label>
                    <div class="value">
                        <span class="badge badge-<?= $order['order_status'] ?>">
                            <?php
require_once __DIR__ . '/../includes/check_admin.php';

                                echo match($order['order_status']) {
                                    'processing' => '⏳ Đang xử lý',
                                    'confirmed' => '✅ Đã xác nhận',
                                    'shipping' => '🚚 Đang giao',
                                    'completed' => '✔️ Hoàn thành',
                                    'cancelled' => '❌ Đã hủy',
                                    default => $order['order_status']
                                };
                            ?>
                        </span>
                    </div>
                </div>
                
                <div class="info-item">
                    <label>Thanh Toán</label>
                    <div class="value">
                        <?= $order['payment_method'] == 'cod' ? '💵 COD' : '💳 Chuyển khoản' ?>
                        <br>
                        <small style="color: <?= $order['payment_status'] == 'paid' ? '#28a745' : '#ffc107' ?>;">
                            <?= $order['payment_status'] == 'paid' ? '✓ Đã thanh toán' : '⏳ Chưa thanh toán' ?>
                        </small>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Thông tin khách hàng -->
        <div class="card">
            <h2>👤 Thông Tin Khách Hàng</h2>
            
            <div class="info-grid">
                <div class="info-item">
                    <label>Họ Tên</label>
                    <div class="value"><?= htmlspecialchars($order['fullname']) ?></div>
                </div>
                
                <div class="info-item">
                    <label>Email</label>
                    <div class="value"><?= htmlspecialchars($order['email']) ?></div>
                </div>
                
                <div class="info-item">
                    <label>Số Điện Thoại</label>
                    <div class="value"><?= htmlspecialchars($order['phone']) ?></div>
                </div>
                
                <div class="info-item" style="grid-column: 1 / -1;">
                    <label>Địa Chỉ Giao Hàng</label>
                    <div class="value"><?= htmlspecialchars($order['shipping_address']) ?></div>
                </div>
                
                <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($order['note']): ?>
                <div class="info-item" style="grid-column: 1 / -1;">
                    <label>Ghi Chú</label>
                    <div class="value" style="color: #666;"><?= htmlspecialchars($order['note']) ?></div>
                </div>
                <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
            </div>
        </div>
        
        <!-- Chi tiết sản phẩm -->
        <div class="card">
            <h2>🛍️ Sản Phẩm Đã Đặt</h2>
            
            <table>
                <thead>
                    <tr>
                        <th>Hình</th>
                        <th>Sản Phẩm</th>
                        <th>Đơn Giá</th>
                        <th>Số Lượng</th>
                        <th>Thành Tiền</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
require_once __DIR__ . '/../includes/check_admin.php';
 while($item = mysqli_fetch_assoc($details)): ?>
                    <tr>
                        <td>
                            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($item['image_url']): ?>
                                <img src="../../<?= htmlspecialchars($item['image_url']) ?>" class="product-image" alt="">
                            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 else: ?>
                                <div style="width:60px;height:60px;background:#ddd;border-radius:8px;"></div>
                            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
                        </td>
                        <td>
                            <strong><?= htmlspecialchars($item['product_name']) ?></strong><br>
                            <small style="color: #666;">
                                Size: <?= htmlspecialchars($item['size_name']) ?> | 
                                Màu: <?= htmlspecialchars($item['color_name']) ?>
                            </small>
                        </td>
                        <td><?= number_format($item['price'], 0, ',', '.') ?>đ</td>
                        <td><strong>×<?= $item['quantity'] ?></strong></td>
                        <td><strong><?= number_format($item['subtotal'], 0, ',', '.') ?>đ</strong></td>
                    </tr>
                    <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endwhile; ?>
                </tbody>
            </table>
            
            <!-- Tổng kết -->
            <div style="max-width: 400px; margin-left: auto; margin-top: 20px;">
                <div class="summary-row">
                    <span>Tạm tính:</span>
                    <strong><?= number_format($order['total_amount'], 0, ',', '.') ?>đ</strong>
                </div>
                
                <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($order['discount_amount'] > 0): ?>
                <div class="summary-row">
                    <span>Giảm giá:
                        <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($order['coupon_code']): ?>
                            <small style="color: #28a745;">(<?= $order['coupon_code'] ?>)</small>
                        <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
                    </span>
                    <strong style="color: #28a745;">-<?= number_format($order['discount_amount'], 0, ',', '.') ?>đ</strong>
                </div>
                <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
                
                <div class="summary-row total">
                    <span>Tổng Cộng:</span>
                    <span style="color: #667eea;"><?= number_format($order['final_amount'], 0, ',', '.') ?>đ</span>
                </div>
            </div>
        </div>
        
        <!-- Timeline trạng thái -->
        <div class="card">
            <h2>📅 Lịch Sử Đơn Hàng</h2>
            
            <div class="timeline">
                <div class="timeline-item completed">
                    <strong>Đơn hàng được tạo</strong><br>
                    <small style="color: #666;"><?= date('d/m/Y H:i', strtotime($order['order_date'])) ?></small>
                </div>
                
                <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($order['order_status'] != 'processing'): ?>
                <div class="timeline-item completed">
                    <strong>Đã xác nhận</strong><br>
                    <small style="color: #666;">Admin đã xác nhận đơn hàng</small>
                </div>
                <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
                
                <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if(in_array($order['order_status'], ['shipping', 'completed'])): ?>
                <div class="timeline-item completed">
                    <strong>Đang giao hàng</strong><br>
                    <small style="color: #666;">Đơn hàng đang được vận chuyển</small>
                </div>
                <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
                
                <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($order['order_status'] == 'completed'): ?>
                <div class="timeline-item completed">
                    <strong>Hoàn thành</strong><br>
                    <small style="color: #666;">Giao hàng thành công</small>
                </div>
                <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
                
                <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($order['order_status'] == 'cancelled'): ?>
                <div class="timeline-item" style="color: #dc3545;">
                    <strong>Đã hủy</strong><br>
                    <small><?= htmlspecialchars($order['cancelled_reason'] ?? 'Không rõ lý do') ?></small><br>
                    <small style="color: #999;">Hủy bởi: <?= $order['cancelled_by'] ?? 'N/A' ?></small>
                </div>
                <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
            </div>
        </div>
        
        <!-- Actions -->
        <div style="margin-top: 20px;">
            <a href="index.php" class="btn">← Quay lại</a>
            
            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($order['order_status'] != 'cancelled' && $order['order_status'] != 'completed'): ?>
                <a href="update_status.php?id=<?= $order_id ?>" class="btn btn-warning">Cập Nhật Trạng Thái</a>
            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
            
            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($order['order_status'] == 'processing'): ?>
                <a href="cancel.php?id=<?= $order_id ?>" class="btn btn-danger" 
                   onclick="return confirm('Bạn có chắc muốn hủy đơn hàng này?')">Hủy Đơn</a>
            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
        </div>
    </div>
</body>
</html>
