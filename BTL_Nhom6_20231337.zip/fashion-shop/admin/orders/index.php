<?php
require_once __DIR__ . '/../includes/check_admin.php';

session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

// Lọc theo trạng thái
$filter_status = $_GET['status'] ?? '';
$where_clause = "1=1";
if ($filter_status) {
    $where_clause = "o.order_status = '" . mysqli_real_escape_string($conn, $filter_status) . "'";
}

// Lấy danh sách đơn hàng
$sql = "SELECT 
            o.*,
            u.fullname as customer_name,
            u.email as customer_email,
            COUNT(od.order_detail_id) as total_items
        FROM orders o
        JOIN users u ON o.user_id = u.user_id
        LEFT JOIN order_details od ON o.order_id = od.order_id
        WHERE $where_clause
        GROUP BY o.order_id
        ORDER BY o.order_date DESC
        LIMIT 50";
$result = mysqli_query($conn, $sql);

// Thống kê tổng quan
$stats_sql = "SELECT 
                COUNT(*) as total_orders,
                SUM(CASE WHEN order_status = 'processing' THEN 1 ELSE 0 END) as processing,
                SUM(CASE WHEN order_status = 'confirmed' THEN 1 ELSE 0 END) as confirmed,
                SUM(CASE WHEN order_status = 'shipping' THEN 1 ELSE 0 END) as shipping,
                SUM(CASE WHEN order_status = 'completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN order_status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
                SUM(CASE WHEN order_status IN ('completed', 'shipping') AND payment_status = 'paid' THEN final_amount ELSE 0 END) as total_revenue
               FROM orders";
$stats = mysqli_fetch_assoc(mysqli_query($conn, $stats_sql));
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Đơn Hàng - Admin</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header h1 { font-size: 24px; margin-bottom: 5px; }
        .header a { color: white; text-decoration: none; margin-left: 20px; }
        
        .container { max-width: 1600px; margin: 30px auto; padding: 0 20px; }
        
        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            border-left: 4px solid #667eea;
        }
        
        .stat-card h3 { font-size: 13px; color: #666; margin-bottom: 8px; text-transform: uppercase; }
        .stat-card .value { font-size: 28px; font-weight: bold; color: #333; }
        .stat-card .sub { font-size: 12px; color: #999; margin-top: 5px; }
        
        .stat-card.processing { border-left-color: #ffc107; }
        .stat-card.confirmed { border-left-color: #17a2b8; }
        .stat-card.shipping { border-left-color: #007bff; }
        .stat-card.completed { border-left-color: #28a745; }
        
        .card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #667eea;
        }
        
        .card-header h2 { font-size: 20px; color: #333; }
        
        /* Filter Tabs */
        .filter-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        
        .filter-tab {
            padding: 8px 16px;
            background: #f8f9fa;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            text-decoration: none;
            color: #333;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .filter-tab:hover { background: #e9ecef; }
        .filter-tab.active {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
        
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; font-size: 13px; }
        th { background: #f8f9fa; font-weight: 600; color: #555; }
        tr:hover { background: #f8f9fa; }
        
        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 500;
        }
        
        .badge-processing { background: #fff3cd; color: #856404; }
        .badge-confirmed { background: #d1ecf1; color: #0c5460; }
        .badge-shipping { background: #cfe2ff; color: #084298; }
        .badge-completed { background: #d4edda; color: #155724; }
        .badge-cancelled { background: #f8d7da; color: #721c24; }
        
        .badge-paid { background: #d4edda; color: #155724; }
        .badge-pending { background: #fff3cd; color: #856404; }
        .badge-failed { background: #f8d7da; color: #721c24; }
        
        .btn {
            display: inline-block;
            padding: 8px 16px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-size: 13px;
            transition: background 0.3s;
        }
        .btn:hover { background: #5568d3; }
        
        .btn-sm { padding: 5px 12px; font-size: 12px; }
        
        .actions { display: flex; gap: 5px; }
        
        .order-id {
            font-weight: bold;
            color: #667eea;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>📦 Quản Lý Đơn Hàng</h1>
        <div>
            <a href="../dashboard/">← Dashboard</a>
            <a href="../auth/logout.php">Đăng xuất</a>
        </div>
    </div>

    <div class="container">
        <!-- Thống kê -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3>💰 Tổng Doanh Thu</h3>
                <div class="value"><?= number_format($stats['total_revenue'], 0, ',', '.') ?>đ</div>
                <div class="sub">Từ đơn hoàn thành</div>
            </div>
            
            <div class="stat-card processing">
                <h3>⏳ Đang Xử Lý</h3>
                <div class="value"><?= number_format($stats['processing']) ?></div>
                <div class="sub">Chờ xác nhận</div>
            </div>
            
            <div class="stat-card confirmed">
                <h3>✅ Đã Xác Nhận</h3>
                <div class="value"><?= number_format($stats['confirmed']) ?></div>
                <div class="sub">Sẵn sàng giao</div>
            </div>
            
            <div class="stat-card shipping">
                <h3>🚚 Đang Giao</h3>
                <div class="value"><?= number_format($stats['shipping']) ?></div>
                <div class="sub">Trên đường giao</div>
            </div>
            
            <div class="stat-card completed">
                <h3>✔️ Hoàn Thành</h3>
                <div class="value"><?= number_format($stats['completed']) ?></div>
                <div class="sub">Giao thành công</div>
            </div>
            
            <div class="stat-card">
                <h3>❌ Đã Hủy</h3>
                <div class="value"><?= number_format($stats['cancelled']) ?></div>
                <div class="sub">Bị hủy</div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h2>Danh Sách Đơn Hàng</h2>
            </div>
            
            <!-- Filter Tabs -->
            <div class="filter-tabs">
                <a href="index.php" class="filter-tab <?= empty($filter_status) ? 'active' : '' ?>">
                    Tất cả (<?= $stats['total_orders'] ?>)
                </a>
                <a href="?status=processing" class="filter-tab <?= $filter_status == 'processing' ? 'active' : '' ?>">
                    ⏳ Đang xử lý (<?= $stats['processing'] ?>)
                </a>
                <a href="?status=confirmed" class="filter-tab <?= $filter_status == 'confirmed' ? 'active' : '' ?>">
                    ✅ Đã xác nhận (<?= $stats['confirmed'] ?>)
                </a>
                <a href="?status=shipping" class="filter-tab <?= $filter_status == 'shipping' ? 'active' : '' ?>">
                    🚚 Đang giao (<?= $stats['shipping'] ?>)
                </a>
                <a href="?status=completed" class="filter-tab <?= $filter_status == 'completed' ? 'active' : '' ?>">
                    ✔️ Hoàn thành (<?= $stats['completed'] ?>)
                </a>
                <a href="?status=cancelled" class="filter-tab <?= $filter_status == 'cancelled' ? 'active' : '' ?>">
                    ❌ Đã hủy (<?= $stats['cancelled'] ?>)
                </a>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>Mã ĐH</th>
                        <th>Khách Hàng</th>
                        <th>Ngày Đặt</th>
                        <th>Sản Phẩm</th>
                        <th>Tổng Tiền</th>
                        <th>Thanh Toán</th>
                        <th>Trạng Thái</th>
                        <th>Thao Tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if(mysqli_num_rows($result) > 0): ?>
                        <?php
require_once __DIR__ . '/../includes/check_admin.php';
 while($order = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td>
                                <span class="order-id">#<?= $order['order_id'] ?></span>
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($order['customer_name']) ?></strong><br>
                                <small style="color: #666;"><?= htmlspecialchars($order['customer_email']) ?></small>
                            </td>
                            <td>
                                <?= date('d/m/Y', strtotime($order['order_date'])) ?><br>
                                <small style="color: #999;"><?= date('H:i', strtotime($order['order_date'])) ?></small>
                            </td>
                            <td><?= $order['total_items'] ?> sản phẩm</td>
                            <td>
                                <strong><?= number_format($order['final_amount'], 0, ',', '.') ?>đ</strong>
                                <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($order['discount_amount'] > 0): ?>
                                    <br><small style="color: #28a745;">-<?= number_format($order['discount_amount'], 0, ',', '.') ?>đ</small>
                                <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
                            </td>
                            <td>
                                <span class="badge badge-<?= $order['payment_status'] ?>">
                                    <?php
require_once __DIR__ . '/../includes/check_admin.php';

                                        echo match($order['payment_status']) {
                                            'paid' => '✓ Đã thanh toán',
                                            'pending' => '⏳ Chờ thanh toán',
                                            'failed' => '✗ Thất bại',
                                            default => $order['payment_status']
                                        };
                                    ?>
                                </span>
                            </td>
                            <td>
                                <span class="badge badge-<?= $order['order_status'] ?>">
                                    <?php
require_once __DIR__ . '/../includes/check_admin.php';

                                        echo match($order['order_status']) {
                                            'processing' => '⏳ Đang xử lý',
                                            'confirmed' => '✅ Đã xác nhận',
                                            'shipping' => '🚚 Đang giao',
                                            'completed' => '✔️ Hoàn thành',
                                            'cancelled' => '❌ Đã hủy',
                                            default => $order['order_status']
                                        };
                                    ?>
                                </span>
                            </td>
                            <td>
                                <div class="actions">
                                    <a href="detail.php?id=<?= $order['order_id'] ?>" class="btn btn-sm">Xem</a>
                                    <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($order['order_status'] != 'cancelled' && $order['order_status'] != 'completed'): ?>
                                        <a href="update_status.php?id=<?= $order['order_id'] ?>" class="btn btn-sm">Cập nhật</a>
                                    <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endwhile; ?>
                    <?php
require_once __DIR__ . '/../includes/check_admin.php';
 else: ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 40px; color: #999;">
                                Không có đơn hàng nào
                            </td>
                        </tr>
                    <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
