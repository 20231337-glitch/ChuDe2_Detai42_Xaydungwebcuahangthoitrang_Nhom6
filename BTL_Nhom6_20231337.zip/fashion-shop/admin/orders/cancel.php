<?php
require_once __DIR__ . '/../includes/check_admin.php';

session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

$order_id = $_GET['id'] ?? 0;
$error = '';

// Lấy thông tin đơn hàng
$sql = "SELECT o.*, u.fullname 
        FROM orders o
        JOIN users u ON o.user_id = u.user_id
        WHERE o.order_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $order_id);
mysqli_stmt_execute($stmt);
$order = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$order) {
    header('Location: index.php');
    exit;
}

// Chỉ được hủy nếu đang ở trạng thái processing
if ($order['order_status'] != 'processing') {
    header('Location: detail.php?id=' . $order_id);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reason = trim($_POST['reason'] ?? '');
    
    if (empty($reason)) {
        $error = 'Vui lòng nhập lý do hủy đơn';
    } else {
        // BEGIN TRANSACTION
        mysqli_begin_transaction($conn);
        
        try {
            // 1. Hoàn lại tồn kho
            $restore_sql = "UPDATE product_variants pv
                            JOIN order_details od ON pv.variant_id = od.variant_id
                            SET pv.stock_quantity = pv.stock_quantity + od.quantity,
                                pv.status = 'in_stock'
                            WHERE od.order_id = ?";
            $stmt = mysqli_prepare($conn, $restore_sql);
            mysqli_stmt_bind_param($stmt, 'i', $order_id);
            mysqli_stmt_execute($stmt);
            
            // 2. Giảm sold_count
            $sold_sql = "UPDATE products p
                         JOIN product_variants pv ON p.product_id = pv.product_id
                         JOIN order_details od ON pv.variant_id = od.variant_id
                         SET p.sold_count = GREATEST(0, p.sold_count - od.quantity)
                         WHERE od.order_id = ?";
            $stmt = mysqli_prepare($conn, $sold_sql);
            mysqli_stmt_bind_param($stmt, 'i', $order_id);
            mysqli_stmt_execute($stmt);
            
            // 3. Hoàn coupon (nếu có)
            if ($order['coupon_code']) {
                // Giảm used_count
                $coupon_sql = "UPDATE coupons 
                               SET used_count = GREATEST(0, used_count - 1)
                               WHERE coupon_code = ?";
                $stmt = mysqli_prepare($conn, $coupon_sql);
                mysqli_stmt_bind_param($stmt, 's', $order['coupon_code']);
                mysqli_stmt_execute($stmt);
                
                // Xóa lịch sử sử dụng
                $usage_sql = "DELETE FROM coupon_usage WHERE order_id = ?";
                $stmt = mysqli_prepare($conn, $usage_sql);
                mysqli_stmt_bind_param($stmt, 'i', $order_id);
                mysqli_stmt_execute($stmt);
            }
            
            // 4. Cập nhật trạng thái đơn
            $update_sql = "UPDATE orders 
                           SET order_status = 'cancelled',
                               cancelled_reason = ?,
                               cancelled_by = 'admin',
                               cancelled_at = NOW()
                           WHERE order_id = ?";
            $stmt = mysqli_prepare($conn, $update_sql);
            mysqli_stmt_bind_param($stmt, 'si', $reason, $order_id);
            mysqli_stmt_execute($stmt);
            
            // 5. Tạo thông báo
            $notif_sql = "INSERT INTO notifications (user_id, type, title, message, link, created_at)
                          VALUES (?, 'order_update', 'Đơn hàng đã bị hủy', ?, ?, NOW())";
            $notif_stmt = mysqli_prepare($conn, $notif_sql);
            $message = 'Đơn hàng #' . $order_id . ' đã bị hủy. Lý do: ' . $reason;
            $link = '/public/account/order_detail.php?id=' . $order_id;
            mysqli_stmt_bind_param($notif_stmt, 'iss', $order['user_id'], $message, $link);
            mysqli_stmt_execute($notif_stmt);
            
            // 6. Ghi log
            $log_sql = "INSERT INTO admin_logs (admin_id, action, table_name, record_id, old_value, new_value, created_at)
                        VALUES (?, 'UPDATE', 'orders', ?, ?, ?, NOW())";
            $log_stmt = mysqli_prepare($conn, $log_sql);
            $old_value = json_encode(['order_status' => $order['order_status']]);
            $new_value = json_encode(['order_status' => 'cancelled', 'reason' => $reason, 'cancelled_by' => 'admin']);
            mysqli_stmt_bind_param($log_stmt, 'iiss', $_SESSION['user_id'], $order_id, $old_value, $new_value);
            mysqli_stmt_execute($log_stmt);
            
            // COMMIT
            mysqli_commit($conn);
            
            header('Location: detail.php?id=' . $order_id);
            exit;
            
        } catch (Exception $e) {
            mysqli_rollback($conn);
            $error = 'Có lỗi xảy ra: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Hủy Đơn Hàng #<?= $order_id ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; }
        
        .header {
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            color: white;
            padding: 20px 40px;
        }
        .header h1 { font-size: 24px; }
        .header a { color: white; text-decoration: none; }
        
        .container { max-width: 700px; margin: 30px auto; padding: 0 20px; }
        
        .card {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        
        .warning-box {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 6px;
        }
        
        .warning-box strong { color: #856404; }
        
        .info-box {
            background: #f8f9fa;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 6px;
        }
        
        .form-group { margin-bottom: 20px; }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #333;
        }
        
        .form-group textarea {
            width: 100%;
            padding: 10px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            font-size: 14px;
            min-height: 120px;
            resize: vertical;
        }
        
        .error {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        
        .btn {
            padding: 12px 30px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            margin-right: 10px;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-danger {
            background: #dc3545;
        }
        .btn-danger:hover { background: #c82333; }
        
        .btn-secondary { background: #6c757d; }
        .btn-secondary:hover { background: #5a6268; }
    </style>
</head>
<body>
    <div class="header">
        <h1>❌ Hủy Đơn Hàng</h1>
        <a href="detail.php?id=<?= $order_id ?>">← Quay lại</a>
    </div>
    
    <div class="container">
        <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($error): ?>
            <div class="error">❌ <?= htmlspecialchars($error) ?></div>
        <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
        
        <div class="card">
            <div class="warning-box">
                <strong>⚠️ Cảnh báo:</strong> Hành động này sẽ:
                <ul style="margin-top: 10px; margin-left: 20px;">
                    <li>Hoàn lại tồn kho cho tất cả sản phẩm</li>
                    <li>Giảm sold_count của sản phẩm</li>
                    <li>Hoàn lại mã giảm giá (nếu có)</li>
                    <li>Gửi thông báo đến khách hàng</li>
                </ul>
            </div>
            
            <div class="info-box">
                <strong>Đơn hàng:</strong> #<?= $order_id ?><br>
                <strong>Khách hàng:</strong> <?= htmlspecialchars($order['fullname']) ?><br>
                <strong>Tổng tiền:</strong> <?= number_format($order['final_amount'], 0, ',', '.') ?>đ
            </div>
            
            <form method="POST" onsubmit="return confirm('Bạn có chắc chắn muốn HỦY đơn hàng này?')">
                <div class="form-group">
                    <label>Lý Do Hủy Đơn *</label>
                    <textarea name="reason" required placeholder="Nhập lý do hủy đơn hàng (khách hàng sẽ nhìn thấy)..."></textarea>
                </div>
                
                <div style="margin-top: 30px;">
                    <button type="submit" class="btn btn-danger">❌ Xác Nhận Hủy Đơn</button>
                    <a href="detail.php?id=<?= $order_id ?>" class="btn btn-secondary">Quay Lại</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
