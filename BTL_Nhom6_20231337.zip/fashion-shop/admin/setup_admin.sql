﻿-- ============================================
-- Tạo tài khoản Admin mặc định
-- Username: admin
-- Password: admin123
-- ============================================

-- Insert Admin User
INSERT INTO users (username, password_hash, email, full_name, phone_number, role_id, is_active, created_at, last_login) 
VALUES (
    'admin',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- password: admin123
    'admin@fashionshop.com',
    'Administrator',
    '0123456789',
    1, -- role_id = 1 (Admin)
    1,
    NOW(),
    NOW()
)
ON DUPLICATE KEY UPDATE username = username;

-- Kiểm tra
SELECT user_id, username, email, full_name, role_id, is_active 
FROM users 
WHERE username = 'admin';
