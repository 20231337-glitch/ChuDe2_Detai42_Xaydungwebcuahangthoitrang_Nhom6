<?php
require_once __DIR__ . '/../includes/check_admin.php';

session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

// Lấy danh sách sản phẩm
$sql = "SELECT 
            p.*,
            c.category_name,
            pi.image_url,
            COUNT(DISTINCT pv.variant_id) as total_variants,
            SUM(pv.stock_quantity) as total_stock
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.category_id
        LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
        LEFT JOIN product_variants pv ON p.product_id = pv.product_id
        WHERE p.deleted_at IS NULL
        GROUP BY p.product_id
        ORDER BY p.created_at DESC";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Sản Phẩm - Admin</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header h1 { font-size: 24px; margin-bottom: 5px; }
        .header a { color: white; text-decoration: none; margin-left: 20px; }
        
        .container { max-width: 1400px; margin: 30px auto; padding: 0 20px; }
        
        .card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #667eea;
        }
        
        .card-header h2 { font-size: 20px; color: #333; }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-size: 14px;
            transition: background 0.3s;
        }
        .btn:hover { background: #5568d3; }
        
        .btn-success { background: #28a745; }
        .btn-success:hover { background: #218838; }
        
        .btn-danger { background: #dc3545; }
        .btn-danger:hover { background: #c82333; }
        
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f8f9fa; font-weight: 600; color: #555; font-size: 13px; }
        tr:hover { background: #f8f9fa; }
        
        .product-image { 
            width: 60px; 
            height: 60px; 
            object-fit: cover; 
            border-radius: 8px; 
            border: 2px solid #eee;
        }
        
        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }
        .badge-active { background: #d4edda; color: #155724; }
        .badge-inactive { background: #f8d7da; color: #721c24; }
        
        .actions { display: flex; gap: 8px; }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 25px;
        }
        
        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
        }
        
        .stat-card h3 { font-size: 14px; opacity: 0.9; margin-bottom: 10px; }
        .stat-card .value { font-size: 28px; font-weight: bold; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🎁 Quản Lý Sản Phẩm</h1>
        <div>
            <a href="../dashboard/">← Dashboard</a>
            <a href="../auth/logout.php">Đăng xuất</a>
        </div>
    </div>

    <div class="container">
        <!-- Thống kê nhanh -->
        <div class="stats">
            <?php
require_once __DIR__ . '/../includes/check_admin.php';

            $total = mysqli_num_rows($result);
            mysqli_data_seek($result, 0);
            $total_stock = 0;
            $total_sold = 0;
            while($p = mysqli_fetch_assoc($result)) {
                $total_stock += $p['total_stock'];
                $total_sold += $p['sold_count'];
            }
            mysqli_data_seek($result, 0);
            ?>
            <div class="stat-card">
                <h3>Tổng Sản Phẩm</h3>
                <div class="value"><?= $total ?></div>
            </div>
            <div class="stat-card">
                <h3>Tổng Tồn Kho</h3>
                <div class="value"><?= number_format($total_stock) ?></div>
            </div>
            <div class="stat-card">
                <h3>Đã Bán</h3>
                <div class="value"><?= number_format($total_sold) ?></div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h2>Danh Sách Sản Phẩm</h2>
                <a href="create.php" class="btn btn-success">+ Thêm Sản Phẩm</a>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>Hình</th>
                        <th>Tên Sản Phẩm</th>
                        <th>Danh Mục</th>
                        <th>Giá Gốc</th>
                        <th>Biến Thể</th>
                        <th>Tồn Kho</th>
                        <th>Đã Bán</th>
                        <th>Trạng Thái</th>
                        <th>Thao Tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
require_once __DIR__ . '/../includes/check_admin.php';
 while($product = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td>
                            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($product['image_url']): ?>
                                <img src="../../<?= htmlspecialchars($product['image_url']) ?>" 
                                     alt="" class="product-image">
                            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 else: ?>
                                <div style="width:60px;height:60px;background:#ddd;border-radius:8px;"></div>
                            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
                        </td>
                        <td><strong><?= htmlspecialchars($product['product_name']) ?></strong></td>
                        <td><?= htmlspecialchars($product['category_name'] ?? 'N/A') ?></td>
                        <td><strong><?= number_format($product['base_price'], 0, ',', '.') ?>đ</strong></td>
                        <td><?= $product['total_variants'] ?? 0 ?> biến thể</td>
                        <td><?= number_format($product['total_stock'] ?? 0) ?></td>
                        <td><?= number_format($product['sold_count']) ?></td>
                        <td>
                            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($product['status'] == 'active'): ?>
                                <span class="badge badge-active">Hoạt động</span>
                            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 else: ?>
                                <span class="badge badge-inactive">Tắt</span>
                            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
                        </td>
                        <td>
                            <div class="actions">
                                <a href="edit.php?id=<?= $product['product_id'] ?>" class="btn">Sửa</a>
                                <a href="delete.php?id=<?= $product['product_id'] ?>" 
                                   class="btn btn-danger"
                                   onclick="return confirm('Bạn có chắc muốn xóa sản phẩm này?')">Xóa</a>
                            </div>
                        </td>
                    </tr>
                    <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
