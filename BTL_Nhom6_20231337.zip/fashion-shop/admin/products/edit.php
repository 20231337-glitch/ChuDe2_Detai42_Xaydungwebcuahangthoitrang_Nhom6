<?php
require_once __DIR__ . '/../includes/check_admin.php';

session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

$product_id = $_GET['id'] ?? 0;
$error = '';

// Lấy thông tin sản phẩm
$sql = "SELECT * FROM products WHERE product_id = ? AND deleted_at IS NULL";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $product_id);
mysqli_stmt_execute($stmt);
$product = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$product) {
    header('Location: index.php');
    exit;
}

// Lấy danh mục
$categories = mysqli_query($conn, "SELECT * FROM categories WHERE deleted_at IS NULL AND status = 'active' ORDER BY category_name");

// Lấy ảnh sản phẩm
$images = mysqli_query($conn, "SELECT * FROM product_images WHERE product_id = $product_id ORDER BY is_primary DESC, display_order");

// Lấy biến thể
$variants_sql = "SELECT pv.*, s.size_name, c.color_name 
                 FROM product_variants pv
                 JOIN sizes s ON pv.size_id = s.size_id
                 JOIN colors c ON pv.color_id = c.color_id
                 WHERE pv.product_id = $product_id";
$variants = mysqli_query($conn, $variants_sql);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_name = trim($_POST['product_name'] ?? '');
    $category_id = $_POST['category_id'] ?? 0;
    $description = trim($_POST['description'] ?? '');
    $base_price = $_POST['base_price'] ?? 0;
    $status = $_POST['status'] ?? 'active';
    
    if (empty($product_name)) {
        $error = 'Vui lòng nhập tên sản phẩm';
    } else {
        $slug = create_slug($product_name);
        
        $sql = "UPDATE products 
                SET product_name = ?, slug = ?, category_id = ?, 
                    description = ?, base_price = ?, status = ?
                WHERE product_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, 'ssisssi', $product_name, $slug, $category_id, $description, $base_price, $status, $product_id);
        
        if (mysqli_stmt_execute($stmt)) {
            // Log
            $log_sql = "INSERT INTO admin_logs (admin_id, action, table_name, record_id, created_at)
                        VALUES (?, 'UPDATE', 'products', ?, NOW())";
            $log_stmt = mysqli_prepare($conn, $log_sql);
            mysqli_stmt_bind_param($log_stmt, 'ii', $_SESSION['user_id'], $product_id);
            mysqli_stmt_execute($log_stmt);
            
            header('Location: index.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Sửa Sản Phẩm</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px 40px; }
        .header h1 { font-size: 24px; }
        .container { max-width: 1000px; margin: 30px auto; padding: 0 20px; }
        .card { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 20px; }
        .card h2 { font-size: 18px; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #667eea; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 500; }
        .form-group input, .form-group textarea, .form-group select {
            width: 100%; padding: 10px 15px; border: 2px solid #e0e0e0; border-radius: 6px;
        }
        .form-group textarea { min-height: 120px; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .error { background: #fee; color: #c33; padding: 12px; border-radius: 6px; margin-bottom: 20px; }
        .btn { padding: 12px 30px; background: #667eea; color: white; border: none; border-radius: 6px; 
               cursor: pointer; margin-right: 10px; text-decoration: none; display: inline-block; }
        .btn:hover { background: #5568d3; }
        .btn-secondary { background: #6c757d; }
        .btn-success { background: #28a745; }
        
        .images-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        .image-item {
            position: relative;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            overflow: hidden;
        }
        .image-item img { width: 100%; height: 150px; object-fit: cover; }
        .image-primary { border-color: #28a745; }
        .primary-badge {
            position: absolute;
            top: 5px;
            left: 5px;
            background: #28a745;
            color: white;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 11px;
        }
        
        .variants-table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        .variants-table th, .variants-table td { padding: 10px; border: 1px solid #e0e0e0; }
        .variants-table th { background: #f8f9fa; }
    </style>
</head>
<body>
    <div class="header">
        <h1>✏️ Sửa Sản Phẩm</h1>
    </div>
    
    <div class="container">
        <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
        
        <form method="POST">
            <div class="card">
                <h2>📝 Thông Tin Cơ Bản</h2>
                
                <div class="form-group">
                    <label>Tên Sản Phẩm *</label>
                    <input type="text" name="product_name" value="<?= htmlspecialchars($product['product_name']) ?>" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Danh Mục *</label>
                        <select name="category_id" required>
                            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 while($cat = mysqli_fetch_assoc($categories)): ?>
                                <option value="<?= $cat['category_id'] ?>" 
                                    <?= $cat['category_id'] == $product['category_id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($cat['category_name']) ?>
                                </option>
                            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Giá Gốc (VNĐ) *</label>
                        <input type="number" name="base_price" value="<?= $product['base_price'] ?>" required min="0" step="1000">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Mô Tả</label>
                    <textarea name="description"><?= htmlspecialchars($product['description'] ?? '') ?></textarea>
                </div>
                
                <div class="form-group">
                    <label>Trạng Thái</label>
                    <select name="status">
                        <option value="active" <?= $product['status'] == 'active' ? 'selected' : '' ?>>Hoạt động</option>
                        <option value="inactive" <?= $product['status'] == 'inactive' ? 'selected' : '' ?>>Tắt</option>
                    </select>
                </div>
            </div>
            
            <div class="card">
                <h2>📷 Hình Ảnh Hiện Tại</h2>
                <div class="images-grid">
                    <?php
require_once __DIR__ . '/../includes/check_admin.php';
 while($img = mysqli_fetch_assoc($images)): ?>
                        <div class="image-item <?= $img['is_primary'] ? 'image-primary' : '' ?>">
                            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($img['is_primary']): ?>
                                <span class="primary-badge">Ảnh chính</span>
                            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
                            <img src="../../<?= htmlspecialchars($img['image_url']) ?>" alt="">
                        </div>
                    <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endwhile; ?>
                </div>
                <p style="margin-top: 15px; color: #666; font-size: 13px;">
                    💡 Để thêm/xóa ảnh, vui lòng liên hệ với quản trị viên hoặc tạo tính năng upload riêng
                </p>
            </div>
            
            <div class="card">
                <h2>🎨 Biến Thể Hiện Tại</h2>
                <table class="variants-table">
                    <thead>
                        <tr>
                            <th>Size</th>
                            <th>Màu</th>
                            <th>Tồn Kho</th>
                            <th>Trạng Thái</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
require_once __DIR__ . '/../includes/check_admin.php';
 while($v = mysqli_fetch_assoc($variants)): ?>
                        <tr>
                            <td><?= htmlspecialchars($v['size_name']) ?></td>
                            <td><?= htmlspecialchars($v['color_name']) ?></td>
                            <td><?= number_format($v['stock_quantity']) ?></td>
                            <td><?= $v['status'] ?></td>
                        </tr>
                        <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endwhile; ?>
                    </tbody>
                </table>
                <p style="margin-top: 15px; color: #666; font-size: 13px;">
                    💡 Để sửa biến thể, cần tạo trang quản lý biến thể riêng
                </p>
            </div>
            
            <div style="margin-top: 20px;">
                <button type="submit" class="btn btn-success">💾 Cập Nhật</button>
                <a href="index.php" class="btn btn-secondary">❌ Hủy</a>
            </div>
        </form>
    </div>
</body>
</html>
