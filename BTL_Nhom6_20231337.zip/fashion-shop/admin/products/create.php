<?php
require_once __DIR__ . '/../includes/check_admin.php';

session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

$error = '';
$success = '';

// Lấy danh sách danh mục
$categories = mysqli_query($conn, "SELECT * FROM categories WHERE deleted_at IS NULL AND status = 'active' ORDER BY category_name");

// Lấy danh sách sizes
$sizes = mysqli_query($conn, "SELECT * FROM sizes ORDER BY display_order");

// Lấy danh sách colors
$colors = mysqli_query($conn, "SELECT * FROM colors ORDER BY display_order");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_name = trim($_POST['product_name'] ?? '');
    $category_id = $_POST['category_id'] ?? 0;
    $description = trim($_POST['description'] ?? '');
    $base_price = $_POST['base_price'] ?? 0;
    $status = $_POST['status'] ?? 'active';
    
    if (empty($product_name)) {
        $error = 'Vui lòng nhập tên sản phẩm';
    } elseif ($base_price <= 0) {
        $error = 'Giá sản phẩm phải lớn hơn 0';
    } else {
        // Tạo slug
        $slug = create_slug($product_name);
        
        // BEGIN TRANSACTION
        mysqli_begin_transaction($conn);
        
        try {
            // 1. Insert sản phẩm
            $sql = "INSERT INTO products (product_name, slug, category_id, description, base_price, status, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, NOW())";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, 'ssisss', $product_name, $slug, $category_id, $description, $base_price, $status);
            mysqli_stmt_execute($stmt);
            
            $product_id = mysqli_insert_id($conn);
            
            // 2. Upload ảnh (nếu có)
            if (isset($_FILES['images']) && $_FILES['images']['name'][0] != '') {
                $upload_dir = '../../uploads/products/';
                $display_order = 0;
                $is_primary = 1;
                
                foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
                    if ($_FILES['images']['error'][$key] == 0) {
                        $file_name = time() . '_' . $key . '_' . $_FILES['images']['name'][$key];
                        $file_path = $upload_dir . $file_name;
                        
                        if (move_uploaded_file($tmp_name, $file_path)) {
                            $image_url = 'uploads/products/' . $file_name;
                            
                            $img_sql = "INSERT INTO product_images (product_id, image_url, is_primary, display_order)
                                        VALUES (?, ?, ?, ?)";
                            $img_stmt = mysqli_prepare($conn, $img_sql);
                            mysqli_stmt_bind_param($img_stmt, 'isii', $product_id, $image_url, $is_primary, $display_order);
                            mysqli_stmt_execute($img_stmt);
                            
                            $is_primary = 0; // Chỉ ảnh đầu tiên là primary
                            $display_order++;
                        }
                    }
                }
            }
            
            // 3. Tạo biến thể (Size × Color)
            if (isset($_POST['variants']) && is_array($_POST['variants'])) {
                foreach ($_POST['variants'] as $variant) {
                    $size_id = $variant['size_id'] ?? 0;
                    $color_id = $variant['color_id'] ?? 0;
                    $stock_qty = $variant['stock_quantity'] ?? 0;
                    
                    if ($size_id > 0 && $color_id > 0 && $stock_qty > 0) {
                        $variant_status = $stock_qty > 0 ? 'in_stock' : 'out_of_stock';
                        
                        $var_sql = "INSERT INTO product_variants (product_id, size_id, color_id, stock_quantity, status)
                                    VALUES (?, ?, ?, ?, ?)";
                        $var_stmt = mysqli_prepare($conn, $var_sql);
                        mysqli_stmt_bind_param($var_stmt, 'iiiis', $product_id, $size_id, $color_id, $stock_qty, $variant_status);
                        mysqli_stmt_execute($var_stmt);
                    }
                }
            }
            
            // Ghi log
            $log_sql = "INSERT INTO admin_logs (admin_id, action, table_name, record_id, new_value, created_at)
                        VALUES (?, 'CREATE', 'products', ?, ?, NOW())";
            $log_stmt = mysqli_prepare($conn, $log_sql);
            $new_value = json_encode(['product_name' => $product_name, 'base_price' => $base_price]);
            mysqli_stmt_bind_param($log_stmt, 'iis', $_SESSION['user_id'], $product_id, $new_value);
            mysqli_stmt_execute($log_stmt);
            
            // COMMIT
            mysqli_commit($conn);
            
            header('Location: index.php');
            exit;
            
        } catch (Exception $e) {
            mysqli_rollback($conn);
            $error = 'Có lỗi xảy ra: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thêm Sản Phẩm Mới</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 40px;
        }
        .header h1 { font-size: 24px; }
        
        .container { max-width: 1000px; margin: 30px auto; padding: 0 20px; }
        
        .card {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 20px;
        }
        
        .card h2 {
            font-size: 18px;
            color: #333;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #667eea;
        }
        
        .form-group { margin-bottom: 20px; }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #333;
        }
        
        .form-group input, .form-group textarea, .form-group select {
            width: 100%;
            padding: 10px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            font-size: 14px;
        }
        
        .form-group textarea { min-height: 120px; resize: vertical; }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .error {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        
        .btn {
            padding: 12px 30px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            margin-right: 10px;
            text-decoration: none;
            display: inline-block;
        }
        .btn:hover { background: #5568d3; }
        
        .btn-secondary { background: #6c757d; }
        .btn-secondary:hover { background: #5a6268; }
        
        .btn-success { background: #28a745; }
        .btn-success:hover { background: #218838; }
        
        /* Variants Table */
        .variants-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        
        .variants-table th,
        .variants-table td {
            padding: 10px;
            border: 1px solid #e0e0e0;
            text-align: left;
        }
        
        .variants-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #555;
        }
        
        .variants-table select,
        .variants-table input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .add-variant-btn {
            margin-top: 10px;
            padding: 8px 20px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }
        
        .remove-variant-btn {
            padding: 5px 10px;
            background: #dc3545;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        
        /* Image Upload */
        .image-upload-area {
            border: 2px dashed #ddd;
            border-radius: 8px;
            padding: 30px;
            text-align: center;
            background: #f8f9fa;
        }
        
        .image-upload-area input[type="file"] {
            display: none;
        }
        
        .upload-label {
            cursor: pointer;
            color: #667eea;
            font-weight: 500;
        }
        
        .upload-label:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="header">
        <h1>➕ Thêm Sản Phẩm Mới</h1>
    </div>
    
    <div class="container">
        <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
        
        <form method="POST" enctype="multipart/form-data">
            <!-- Thông tin cơ bản -->
            <div class="card">
                <h2>📝 Thông Tin Cơ Bản</h2>
                
                <div class="form-group">
                    <label>Tên Sản Phẩm *</label>
                    <input type="text" name="product_name" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Danh Mục *</label>
                        <select name="category_id" required>
                            <option value="">-- Chọn danh mục --</option>
                            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 while($cat = mysqli_fetch_assoc($categories)): ?>
                                <option value="<?= $cat['category_id'] ?>"><?= htmlspecialchars($cat['category_name']) ?></option>
                            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Giá Gốc (VNĐ) *</label>
                        <input type="number" name="base_price" required min="0" step="1000">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Mô Tả</label>
                    <textarea name="description"></textarea>
                </div>
                
                <div class="form-group">
                    <label>Trạng Thái</label>
                    <select name="status">
                        <option value="active">Hoạt động</option>
                        <option value="inactive">Tắt</option>
                    </select>
                </div>
            </div>
            
            <!-- Upload ảnh -->
            <div class="card">
                <h2>📷 Hình Ảnh Sản Phẩm</h2>
                
                <div class="image-upload-area">
                    <p>📁 Chọn ảnh sản phẩm (có thể chọn nhiều ảnh)</p>
                    <p style="font-size: 13px; color: #666; margin-top: 10px;">Ảnh đầu tiên sẽ là ảnh chính</p>
                    <label for="images" class="upload-label">
                        <strong>Nhấn để chọn ảnh</strong>
                    </label>
                    <input type="file" name="images[]" id="images" multiple accept="image/*">
                </div>
            </div>
            
            <!-- Biến thể (Size × Color) -->
            <div class="card">
                <h2>🎨 Biến Thể Sản Phẩm (Size × Màu)</h2>
                
                <table class="variants-table" id="variantsTable">
                    <thead>
                        <tr>
                            <th>Size</th>
                            <th>Màu Sắc</th>
                            <th>Số Lượng</th>
                            <th>Thao Tác</th>
                        </tr>
                    </thead>
                    <tbody id="variantsList">
                        <tr>
                            <td>
                                <select name="variants[0][size_id]" required>
                                    <option value="">-- Chọn size --</option>
                                    <?php
require_once __DIR__ . '/../includes/check_admin.php';
 
                                    mysqli_data_seek($sizes, 0);
                                    while($size = mysqli_fetch_assoc($sizes)): 
                                    ?>
                                        <option value="<?= $size['size_id'] ?>"><?= htmlspecialchars($size['size_name']) ?></option>
                                    <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endwhile; ?>
                                </select>
                            </td>
                            <td>
                                <select name="variants[0][color_id]" required>
                                    <option value="">-- Chọn màu --</option>
                                    <?php
require_once __DIR__ . '/../includes/check_admin.php';
 
                                    mysqli_data_seek($colors, 0);
                                    while($color = mysqli_fetch_assoc($colors)): 
                                    ?>
                                        <option value="<?= $color['color_id'] ?>">
                                            <?= htmlspecialchars($color['color_name']) ?>
                                        </option>
                                    <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endwhile; ?>
                                </select>
                            </td>
                            <td>
                                <input type="number" name="variants[0][stock_quantity]" 
                                       min="0" value="0" required>
                            </td>
                            <td>
                                <button type="button" class="remove-variant-btn" onclick="removeVariant(this)">Xóa</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
                
                <button type="button" class="add-variant-btn" onclick="addVariant()">+ Thêm Biến Thể</button>
            </div>
            
            <!-- Actions -->
            <div style="margin-top: 20px;">
                <button type="submit" class="btn btn-success">💾 Lưu Sản Phẩm</button>
                <a href="index.php" class="btn btn-secondary">❌ Hủy</a>
            </div>
        </form>
    </div>
    
    <script>
        let variantIndex = 1;
        
        // Lấy options cho size và color
        const sizeOptions = <?= json_encode(mysqli_fetch_all(mysqli_query($conn, "SELECT * FROM sizes ORDER BY display_order"), MYSQLI_ASSOC)) ?>;
        const colorOptions = <?= json_encode(mysqli_fetch_all(mysqli_query($conn, "SELECT * FROM colors ORDER BY display_order"), MYSQLI_ASSOC)) ?>;
        
        function addVariant() {
            const tbody = document.getElementById('variantsList');
            const tr = document.createElement('tr');
            
            // Size select
            let sizeSelect = '<select name="variants[' + variantIndex + '][size_id]" required><option value="">-- Chọn size --</option>';
            sizeOptions.forEach(size => {
                sizeSelect += '<option value="' + size.size_id + '">' + size.size_name + '</option>';
            });
            sizeSelect += '</select>';
            
            // Color select
            let colorSelect = '<select name="variants[' + variantIndex + '][color_id]" required><option value="">-- Chọn màu --</option>';
            colorOptions.forEach(color => {
                colorSelect += '<option value="' + color.color_id + '">' + color.color_name + '</option>';
            });
            colorSelect += '</select>';
            
            tr.innerHTML = 
                <td> + sizeSelect + </td>
                <td> + colorSelect + </td>
                <td><input type="number" name="variants[ + variantIndex + ][stock_quantity]" min="0" value="0" required></td>
                <td><button type="button" class="remove-variant-btn" onclick="removeVariant(this)">Xóa</button></td>
            ;
            
            tbody.appendChild(tr);
            variantIndex++;
        }
        
        function removeVariant(btn) {
            const tbody = document.getElementById('variantsList');
            if (tbody.children.length > 1) {
                btn.closest('tr').remove();
            } else {
                alert('Phải có ít nhất 1 biến thể!');
            }
        }
        
        // Preview ảnh khi chọn
        document.getElementById('images').addEventListener('change', function(e) {
            const files = e.target.files;
            if (files.length > 0) {
                const area = document.querySelector('.image-upload-area');
                area.innerHTML = '<p>✅ Đã chọn ' + files.length + ' ảnh</p>';
                area.innerHTML += '<label for="images" class="upload-label"><strong>Chọn lại</strong></label>';
                area.innerHTML += '<input type="file" name="images[]" id="images" multiple accept="image/*">';
                
                // Re-attach event
                document.getElementById('images').addEventListener('change', arguments.callee);
            }
        });
    </script>
</body>
</html>
