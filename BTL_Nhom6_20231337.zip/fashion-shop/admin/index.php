<?php
require_once __DIR__ . '/includes/check_admin.php';

/**
 * Trang đăng nhập Admin
 */
session_start();
require_once '../config/config.php';

// Nếu đã đăng nhập, chuyển về dashboard
if (isLoggedIn() && isAdmin()) {
    redirect(BASE_URL . '/admin/dashboard.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Vui lòng nhập đầy đủ thông tin!';
    } else {
        // Truy vấn user
        $sql = "SELECT u.*, r.role_name 
                FROM users u 
                JOIN roles r ON u.role_id = r.role_id 
                WHERE u.username = ? AND u.is_active = 1";
        
        $user = fetchRow($sql, [$username], 's');
        
        if ($user && password_verify($password, $user['password_hash'])) {
            // Kiểm tra quyền Admin
            if ($user['role_id'] == ROLE_ADMIN) {
                // Lưu session
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['role_id'] = $user['role_id'];
                $_SESSION['role_name'] = $user['role_name'];
                
                // Cập nhật last login
                $updateSql = "UPDATE users SET last_login = NOW() WHERE user_id = ?";
                executeQuery($updateSql, [$user['user_id']], 'i');
                
                redirect(BASE_URL . '/admin/dashboard.php');
            } else {
                $error = 'Bạn không có quyền truy cập Admin!';
            }
        } else {
            $error = 'Tên đăng nhập hoặc mật khẩu không đúng!';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập Admin - Fashion Shop</title>
    <link rel="stylesheet" href="<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo ASSETS_URL; ?>/css/admin/login.css">
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <div class="logo">
                <h1>🎯 FASHION SHOP</h1>
                <p>Admin Panel</p>
            </div>
            
            <form method="POST" action="" class="login-form">
                <h2>Đăng nhập hệ thống</h2>
                
                <?php
require_once __DIR__ . '/includes/check_admin.php';
 if ($error): ?>
                    <div class="alert alert-error">
                        <?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $error; ?>
                    </div>
                <?php
require_once __DIR__ . '/includes/check_admin.php';
 endif; ?>
                
                <div class="form-group">
                    <label for="username">Tên đăng nhập</label>
                    <input type="text" id="username" name="username" 
                           value="<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $_POST['username'] ?? ''; ?>" 
                           required autofocus>
                </div>
                
                <div class="form-group">
                    <label for="password">Mật khẩu</label>
                    <input type="password" id="password" name="password" required>
                </div>
                
                <button type="submit" class="btn-login">Đăng nhập</button>
                
                <div class="demo-info">
                    <p><strong>Demo Account:</strong></p>
                    <p>Username: <code>admin</code></p>
                    <p>Password: <code>admin123</code></p>
                </div>
            </form>
            
            <div class="footer">
                <a href="<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo BASE_URL; ?>">← Về trang chủ</a>
            </div>
        </div>
    </div>
</body>
</html>
