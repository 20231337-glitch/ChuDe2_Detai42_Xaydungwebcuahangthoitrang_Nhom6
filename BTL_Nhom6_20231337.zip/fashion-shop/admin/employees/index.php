<?php
/**
 * Quản lý Nhân viên
 */
require_once '../../config/config.php';
require_once '../includes/auth_check.php';

$page_title = 'Quản lý Nhân viên';

include '../includes/header.php';
?>

<div class="placeholder-content">
    <div style="text-align: center; padding: 60px 20px;">
        <h2 style="font-size: 2.5em; color: #999; margin-bottom: 20px;">🚧</h2>
        <h3 style="color: #555; margin-bottom: 15px;">Quản lý Nhân viên</h3>
        <p style="color: #999; font-size: 1.1em;">Chức năng đang được phát triển...</p>
        <p style="color: #bbb; margin-top: 10px;">Sẽ hoàn thành trong các giai đoạn tiếp theo</p>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
