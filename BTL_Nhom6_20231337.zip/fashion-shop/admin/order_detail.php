<?php
require_once __DIR__ . '/includes/check_admin.php';

session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

// Kiểm tra đăng nhập admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

$order_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($order_id <= 0) {
    header('Location: orders.php');
    exit();
}

// Lấy thông tin đơn hàng
$sql = "SELECT o.*, u.full_name as user_name, u.email as user_email 
        FROM orders o 
        LEFT JOIN users u ON o.user_id = u.id 
        WHERE o.id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$order_id]);
$order = $stmt->fetch();

if (!$order) {
    header('Location: orders.php');
    exit();
}

// Lấy chi tiết sản phẩm trong đơn hàng
$sql = "SELECT oi.*, p.name as product_name, p.image_url, pv.size, pv.color 
        FROM order_items oi
        JOIN product_variants pv ON oi.variant_id = pv.id
        JOIN products p ON pv.product_id = p.id
        WHERE oi.order_id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$order_id]);
$order_items = $stmt->fetchAll();

// Lấy lịch sử trạng thái
$sql = "SELECT * FROM order_status_history 
        WHERE order_id = ? 
        ORDER BY created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute([$order_id]);
$status_history = $stmt->fetchAll();

$status_labels = [
    'pending' => 'Chờ xác nhận',
    'confirmed' => 'Đã xác nhận',
    'shipping' => 'Đang giao',
    'delivered' => 'Đã giao',
    'cancelled' => 'Đã hủy'
];

$status_colors = [
    'pending' => 'warning',
    'confirmed' => 'info',
    'shipping' => 'primary',
    'delivered' => 'success',
    'cancelled' => 'danger'
];

$payment_methods = [
    'cod' => 'Thanh toán khi nhận hàng (COD)',
    'bank_transfer' => 'Chuyển khoản ngân hàng',
    'momo' => 'Ví MoMo',
    'vnpay' => 'VNPay'
];

$payment_status_labels = [
    'pending' => 'Chưa thanh toán',
    'paid' => 'Đã thanh toán',
    'refunded' => 'Đã hoàn tiền'
];
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi tiết đơn hàng #<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $order['id']; ?> - Fashion Shop Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .order-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        .info-card {
            border-radius: 10px;
            border: 1px solid #e0e0e0;
            margin-bottom: 20px;
        }
        .info-card .card-header {
            background-color: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
            font-weight: 600;
        }
        .product-item {
            border-bottom: 1px solid #e0e0e0;
            padding: 15px 0;
        }
        .product-item:last-child {
            border-bottom: none;
        }
        .product-img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 5px;
        }
        .timeline {
            position: relative;
            padding-left: 30px;
        }
        .timeline-item {
            position: relative;
            padding-bottom: 20px;
        }
        .timeline-item::before {
            content: '';
            position: absolute;
            left: -22px;
            top: 5px;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background-color: #667eea;
        }
        .timeline-item::after {
            content: '';
            position: absolute;
            left: -18px;
            top: 15px;
            width: 2px;
            height: calc(100% - 10px);
            background-color: #e0e0e0;
        }
        .timeline-item:last-child::after {
            display: none;
        }
        .action-buttons .btn {
            margin-right: 10px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <?php
require_once __DIR__ . '/includes/check_admin.php';
 include 'includes/header.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-2">
                <?php
require_once __DIR__ . '/includes/check_admin.php';
 include 'includes/sidebar.php'; ?>
            </div>
            
            <div class="col-md-10">
                <!-- Header -->
                <div class="order-header">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h2><i class="fas fa-receipt"></i> Đơn hàng #<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $order['id']; ?></h2>
                            <p class="mb-0">Ngày đặt: <?php
require_once __DIR__ . '/includes/check_admin.php';
 echo date('d/m/Y H:i', strtotime($order['created_at'])); ?></p>
                        </div>
                        <div class="col-md-4 text-end">
                            <span class="badge bg-<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $status_colors[$order['status']]; ?> fs-5">
                                <?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $status_labels[$order['status']]; ?>
                            </span>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Cột trái -->
                    <div class="col-md-8">
                        <!-- Thông tin khách hàng -->
                        <div class="card info-card">
                            <div class="card-header">
                                <i class="fas fa-user"></i> Thông tin khách hàng
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <p><strong>Họ tên:</strong> <?php
require_once __DIR__ . '/includes/check_admin.php';
 echo htmlspecialchars($order['customer_name']); ?></p>
                                        <p><strong>Số điện thoại:</strong> <?php
require_once __DIR__ . '/includes/check_admin.php';
 echo htmlspecialchars($order['customer_phone']); ?></p>
                                        <p><strong>Email:</strong> <?php
require_once __DIR__ . '/includes/check_admin.php';
 echo htmlspecialchars($order['customer_email']); ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <p><strong>Địa chỉ giao hàng:</strong><br>
                                        <?php
require_once __DIR__ . '/includes/check_admin.php';
 echo nl2br(htmlspecialchars($order['shipping_address'])); ?></p>
                                    </div>
                                </div>
                                <?php
require_once __DIR__ . '/includes/check_admin.php';
 if ($order['notes']): ?>
                                    <p><strong>Ghi chú:</strong><br><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo nl2br(htmlspecialchars($order['notes'])); ?></p>
                                <?php
require_once __DIR__ . '/includes/check_admin.php';
 endif; ?>
                            </div>
                        </div>

                        <!-- Danh sách sản phẩm -->
                        <div class="card info-card">
                            <div class="card-header">
                                <i class="fas fa-shopping-bag"></i> Sản phẩm (<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo count($order_items); ?> sản phẩm)
                            </div>
                            <div class="card-body">
                                <?php
require_once __DIR__ . '/includes/check_admin.php';
 foreach ($order_items as $item): ?>
                                    <div class="product-item">
                                        <div class="row align-items-center">
                                            <div class="col-md-2">
                                                <img src="<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo htmlspecialchars($item['image_url']); ?>" 
                                                     alt="<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo htmlspecialchars($item['product_name']); ?>" 
                                                     class="product-img">
                                            </div>
                                            <div class="col-md-6">
                                                <h6 class="mb-1"><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo htmlspecialchars($item['product_name']); ?></h6>
                                                <p class="text-muted mb-0">
                                                    <small>
                                                        Size: <?php
require_once __DIR__ . '/includes/check_admin.php';
 echo htmlspecialchars($item['size']); ?> | 
                                                        Màu: <?php
require_once __DIR__ . '/includes/check_admin.php';
 echo htmlspecialchars($item['color']); ?>
                                                    </small>
                                                </p>
                                            </div>
                                            <div class="col-md-2 text-center">
                                                <p class="mb-0">x<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $item['quantity']; ?></p>
                                            </div>
                                            <div class="col-md-2 text-end">
                                                <p class="mb-0"><strong><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo number_format($item['price']); ?>₫</strong></p>
                                                <p class="text-muted mb-0"><small>= <?php
require_once __DIR__ . '/includes/check_admin.php';
 echo number_format($item['price'] * $item['quantity']); ?>₫</small></p>
                                            </div>
                                        </div>
                                    </div>
                                <?php
require_once __DIR__ . '/includes/check_admin.php';
 endforeach; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Cột phải -->
                    <div class="col-md-4">
                        <!-- Thông tin thanh toán -->
                        <div class="card info-card">
                            <div class="card-header">
                                <i class="fas fa-credit-card"></i> Thông tin thanh toán
                            </div>
                            <div class="card-body">
                                <p><strong>Phương thức:</strong><br><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $payment_methods[$order['payment_method']]; ?></p>
                                <p><strong>Trạng thái:</strong> 
                                    <span class="badge bg-<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $order['payment_status'] === 'paid' ? 'success' : 'warning'; ?>">
                                        <?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $payment_status_labels[$order['payment_status']]; ?>
                                    </span>
                                </p>
                                <hr>
                                <div class="d-flex justify-content-between">
                                    <span>Tạm tính:</span>
                                    <strong><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo number_format($order['subtotal']); ?>₫</strong>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <span>Phí vận chuyển:</span>
                                    <strong><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo number_format($order['shipping_fee']); ?>₫</strong>
                                </div>
                                <?php
require_once __DIR__ . '/includes/check_admin.php';
 if ($order['discount_amount'] > 0): ?>
                                    <div class="d-flex justify-content-between text-success">
                                        <span>Giảm giá:</span>
                                        <strong>-<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo number_format($order['discount_amount']); ?>₫</strong>
                                    </div>
                                <?php
require_once __DIR__ . '/includes/check_admin.php';
 endif; ?>
                                <hr>
                                <div class="d-flex justify-content-between">
                                    <h5>Tổng cộng:</h5>
                                    <h5 class="text-primary"><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo number_format($order['total_amount']); ?>₫</h5>
                                </div>
                            </div>
                        </div>

                        <!-- Lịch sử trạng thái -->
                        <div class="card info-card">
                            <div class="card-header">
                                <i class="fas fa-history"></i> Lịch sử trạng thái
                            </div>
                            <div class="card-body">
                                <div class="timeline">
                                    <?php
require_once __DIR__ . '/includes/check_admin.php';
 foreach ($status_history as $history): ?>
                                        <div class="timeline-item">
                                            <strong><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $status_labels[$history['status']]; ?></strong><br>
                                            <small class="text-muted"><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo date('d/m/Y H:i', strtotime($history['created_at'])); ?></small>
                                            <?php
require_once __DIR__ . '/includes/check_admin.php';
 if ($history['notes']): ?>
                                                <p class="mb-0 mt-2"><em><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo htmlspecialchars($history['notes']); ?></em></p>
                                            <?php
require_once __DIR__ . '/includes/check_admin.php';
 endif; ?>
                                        </div>
                                    <?php
require_once __DIR__ . '/includes/check_admin.php';
 endforeach; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Thao tác -->
                        <div class="card info-card">
                            <div class="card-header">
                                <i class="fas fa-cog"></i> Thao tác
                            </div>
                            <div class="card-body action-buttons">
                                <?php
require_once __DIR__ . '/includes/check_admin.php';
 if ($order['status'] === 'pending'): ?>
                                    <a href="update_order_status.php?id=<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $order['id']; ?>&status=confirmed" 
                                       class="btn btn-success" onclick="return confirm('Xác nhận đơn hàng này?')">
                                        <i class="fas fa-check"></i> Xác nhận đơn
                                    </a>
                                    <a href="cancel_order.php?id=<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $order['id']; ?>" 
                                       class="btn btn-danger" onclick="return confirm('Hủy đơn hàng này?')">
                                        <i class="fas fa-times"></i> Hủy đơn
                                    </a>
                                <?php
require_once __DIR__ . '/includes/check_admin.php';
 elseif ($order['status'] === 'confirmed'): ?>
                                    <a href="update_order_status.php?id=<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $order['id']; ?>&status=shipping" 
                                       class="btn btn-primary" onclick="return confirm('Chuyển sang trạng thái đang giao?')">
                                        <i class="fas fa-truck"></i> Bắt đầu giao hàng
                                    </a>
                                <?php
require_once __DIR__ . '/includes/check_admin.php';
 elseif ($order['status'] === 'shipping'): ?>
                                    <a href="update_order_status.php?id=<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $order['id']; ?>&status=delivered" 
                                       class="btn btn-success" onclick="return confirm('Xác nhận đã giao hàng thành công?')">
                                        <i class="fas fa-check-double"></i> Đã giao hàng
                                    </a>
                                <?php
require_once __DIR__ . '/includes/check_admin.php';
 endif; ?>
                                
                                <a href="orders.php" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left"></i> Quay lại
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
