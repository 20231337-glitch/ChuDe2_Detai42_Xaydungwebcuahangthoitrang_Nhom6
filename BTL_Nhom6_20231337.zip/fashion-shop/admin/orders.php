<?php
require_once __DIR__ . '/includes/check_admin.php';

session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

// Kiểm tra đăng nhập admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

// Lấy danh sách đơn hàng
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Xây dựng query
$where_conditions = [];
$params = [];

if ($status_filter !== '') {
    $where_conditions[] = "o.status = ?";
    $params[] = $status_filter;
}

if ($search !== '') {
    $where_conditions[] = "(o.id = ? OR o.customer_name LIKE ? OR o.customer_phone LIKE ? OR o.customer_email LIKE ?)";
    $params[] = $search;
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$where_clause = count($where_conditions) > 0 ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Đếm tổng số đơn hàng
$count_sql = "SELECT COUNT(*) as total FROM orders o $where_clause";
$count_stmt = $pdo->prepare($count_sql);
$count_stmt->execute($params);
$total_orders = $count_stmt->fetch()['total'];
$total_pages = ceil($total_orders / $limit);

// Lấy danh sách đơn hàng
$sql = "SELECT o.*, u.full_name as user_name 
        FROM orders o 
        LEFT JOIN users u ON o.user_id = u.id 
        $where_clause 
        ORDER BY o.created_at DESC 
        LIMIT $limit OFFSET $offset";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

// Thống kê đơn hàng theo trạng thái
$stats_sql = "SELECT status, COUNT(*) as count, SUM(total_amount) as total_revenue 
               FROM orders 
               GROUP BY status";
$stats_stmt = $pdo->query($stats_sql);
$stats = $stats_stmt->fetchAll(PDO::FETCH_KEY_PAIR);

$status_labels = [
    'pending' => 'Chờ xác nhận',
    'confirmed' => 'Đã xác nhận',
    'shipping' => 'Đang giao',
    'delivered' => 'Đã giao',
    'cancelled' => 'Đã hủy'
];

$status_colors = [
    'pending' => 'warning',
    'confirmed' => 'info',
    'shipping' => 'primary',
    'delivered' => 'success',
    'cancelled' => 'danger'
];
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý đơn hàng - Fashion Shop Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .order-stats {
            margin-bottom: 30px;
        }
        .stat-card {
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            color: white;
        }
        .stat-card h3 {
            margin: 0;
            font-size: 2rem;
        }
        .stat-card p {
            margin: 5px 0 0 0;
            opacity: 0.9;
        }
        .order-table th {
            background-color: #f8f9fa;
        }
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <?php
require_once __DIR__ . '/includes/check_admin.php';
 include 'includes/header.php'; ?>
    
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-2">
                <?php
require_once __DIR__ . '/includes/check_admin.php';
 include 'includes/sidebar.php'; ?>
            </div>
            
            <div class="col-md-10">
                <h2><i class="fas fa-shopping-cart"></i> Quản lý đơn hàng</h2>
                
                <!-- Thống kê -->
                <div class="order-stats">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="stat-card bg-warning">
                                <h3><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo number_format($stats['pending'] ?? 0); ?></h3>
                                <p>Chờ xác nhận</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="stat-card bg-info">
                                <h3><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo number_format($stats['confirmed'] ?? 0); ?></h3>
                                <p>Đã xác nhận</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="stat-card bg-primary">
                                <h3><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo number_format($stats['shipping'] ?? 0); ?></h3>
                                <p>Đang giao</p>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="stat-card bg-success">
                                <h3><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo number_format($stats['delivered'] ?? 0); ?></h3>
                                <p>Đã giao</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Bộ lọc và tìm kiếm -->
                <div class="card mb-4">
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label">Trạng thái</label>
                                <select name="status" class="form-select">
                                    <option value="">Tất cả</option>
                                    <?php
require_once __DIR__ . '/includes/check_admin.php';
 foreach ($status_labels as $value => $label): ?>
                                        <option value="<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $value; ?>" <?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $status_filter === $value ? 'selected' : ''; ?>>
                                            <?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $label; ?>
                                        </option>
                                    <?php
require_once __DIR__ . '/includes/check_admin.php';
 endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Tìm kiếm</label>
                                <input type="text" name="search" class="form-control" 
                                       placeholder="Mã đơn hàng, tên, SĐT, email..." 
                                       value="<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo htmlspecialchars($search); ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">&nbsp;</label>
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="fas fa-search"></i> Tìm kiếm
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Bảng đơn hàng -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover order-table">
                                <thead>
                                    <tr>
                                        <th>Mã ĐH</th>
                                        <th>Khách hàng</th>
                                        <th>SĐT</th>
                                        <th>Tổng tiền</th>
                                        <th>Trạng thái</th>
                                        <th>Ngày đặt</th>
                                        <th>Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
require_once __DIR__ . '/includes/check_admin.php';
 if (count($orders) > 0): ?>
                                        <?php
require_once __DIR__ . '/includes/check_admin.php';
 foreach ($orders as $order): ?>
                                            <tr>
                                                <td><strong>#<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $order['id']; ?></strong></td>
                                                <td>
                                                    <?php
require_once __DIR__ . '/includes/check_admin.php';
 echo htmlspecialchars($order['customer_name']); ?>
                                                    <?php
require_once __DIR__ . '/includes/check_admin.php';
 if ($order['user_name']): ?>
                                                        <br><small class="text-muted">(<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo htmlspecialchars($order['user_name']); ?>)</small>
                                                    <?php
require_once __DIR__ . '/includes/check_admin.php';
 endif; ?>
                                                </td>
                                                <td><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo htmlspecialchars($order['customer_phone']); ?></td>
                                                <td><strong><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo number_format($order['total_amount']); ?>₫</strong></td>
                                                <td>
                                                    <span class="status-badge bg-<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $status_colors[$order['status']]; ?>">
                                                        <?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $status_labels[$order['status']]; ?>
                                                    </span>
                                                </td>
                                                <td><?php
require_once __DIR__ . '/includes/check_admin.php';
 echo date('d/m/Y H:i', strtotime($order['created_at'])); ?></td>
                                                <td>
                                                    <a href="order_detail.php?id=<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $order['id']; ?>" 
                                                       class="btn btn-sm btn-info" title="Xem chi tiết">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php
require_once __DIR__ . '/includes/check_admin.php';
 endforeach; ?>
                                    <?php
require_once __DIR__ . '/includes/check_admin.php';
 else: ?>
                                        <tr>
                                            <td colspan="7" class="text-center text-muted py-4">
                                                <i class="fas fa-inbox fa-3x mb-3"></i>
                                                <p>Không có đơn hàng nào</p>
                                            </td>
                                        </tr>
                                    <?php
require_once __DIR__ . '/includes/check_admin.php';
 endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Phân trang -->
                        <?php
require_once __DIR__ . '/includes/check_admin.php';
 if ($total_pages > 1): ?>
                            <nav aria-label="Page navigation">
                                <ul class="pagination justify-content-center">
                                    <?php
require_once __DIR__ . '/includes/check_admin.php';
 for ($i = 1; $i <= $total_pages; $i++): ?>
                                        <li class="page-item <?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $i === $page ? 'active' : ''; ?>">
                                            <a class="page-link" href="?page=<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $i; ?>&status=<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $status_filter; ?>&search=<?php
require_once __DIR__ . '/includes/check_admin.php';
 echo urlencode($search); ?>">
                                                <?php
require_once __DIR__ . '/includes/check_admin.php';
 echo $i; ?>
                                            </a>
                                        </li>
                                    <?php
require_once __DIR__ . '/includes/check_admin.php';
 endfor; ?>
                                </ul>
                            </nav>
                        <?php
require_once __DIR__ . '/includes/check_admin.php';
 endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
