<?php
require_once __DIR__ . '/../includes/check_admin.php';

session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

// Kiểm tra quyền admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

$admin_name = $_SESSION['fullname'];

// Lấy danh sách danh mục
$sql = "SELECT * FROM categories WHERE deleted_at IS NULL ORDER BY category_name";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Danh Mục - Admin</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header h1 { font-size: 24px; margin-bottom: 5px; }
        .header a { color: white; text-decoration: none; margin-left: 20px; }
        
        .container { max-width: 1200px; margin: 30px auto; padding: 0 20px; }
        
        .card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #667eea;
        }
        
        .card-header h2 { font-size: 20px; color: #333; }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-size: 14px;
            transition: background 0.3s;
        }
        .btn:hover { background: #5568d3; }
        
        .btn-success { background: #28a745; }
        .btn-success:hover { background: #218838; }
        
        .btn-danger { background: #dc3545; }
        .btn-danger:hover { background: #c82333; }
        
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f8f9fa; font-weight: 600; color: #555; }
        tr:hover { background: #f8f9fa; }
        
        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }
        .badge-active { background: #d4edda; color: #155724; }
        .badge-inactive { background: #f8d7da; color: #721c24; }
        
        .actions { display: flex; gap: 10px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>📂 Quản Lý Danh Mục</h1>
        <div>
            <a href="../dashboard/">← Dashboard</a>
            <a href="../auth/logout.php">Đăng xuất</a>
        </div>
    </div>

    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2>Danh Sách Danh Mục</h2>
                <a href="create.php" class="btn btn-success">+ Thêm Danh Mục</a>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tên Danh Mục</th>
                        <th>Slug</th>
                        <th>Mô Tả</th>
                        <th>Trạng Thái</th>
                        <th>Thao Tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
require_once __DIR__ . '/../includes/check_admin.php';
 while($cat = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?= $cat['category_id'] ?></td>
                        <td><strong><?= htmlspecialchars($cat['category_name']) ?></strong></td>
                        <td><?= htmlspecialchars($cat['slug']) ?></td>
                        <td><?= htmlspecialchars(substr($cat['description'] ?? '', 0, 50)) ?>...</td>
                        <td>
                            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($cat['status'] == 'active'): ?>
                                <span class="badge badge-active">Hoạt động</span>
                            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 else: ?>
                                <span class="badge badge-inactive">Tắt</span>
                            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
                        </td>
                        <td>
                            <div class="actions">
                                <a href="edit.php?id=<?= $cat['category_id'] ?>" class="btn">Sửa</a>
                                <a href="delete.php?id=<?= $cat['category_id'] ?>" 
                                   class="btn btn-danger"
                                   onclick="return confirm('Bạn có chắc muốn xóa danh mục này?')">Xóa</a>
                            </div>
                        </td>
                    </tr>
                    <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
