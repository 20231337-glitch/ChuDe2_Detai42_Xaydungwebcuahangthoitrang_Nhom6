<?php
require_once __DIR__ . '/../includes/check_admin.php';

session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

$id = $_GET['id'] ?? 0;
$error = '';

// Lấy thông tin danh mục
$sql = "SELECT * FROM categories WHERE category_id = ? AND deleted_at IS NULL";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$category = mysqli_fetch_assoc($result);

if (!$category) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['category_name'] ?? '');
    $slug = trim($_POST['slug'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $status = $_POST['status'] ?? 'active';
    
    if (empty($name)) {
        $error = 'Vui lòng nhập tên danh mục';
    } else {
        $old_value = json_encode($category);
        
        $sql = "UPDATE categories SET category_name = ?, slug = ?, description = ?, status = ? WHERE category_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, 'ssssi', $name, $slug, $description, $status, $id);
        
        if (mysqli_stmt_execute($stmt)) {
            // Log
            $new_value = json_encode(['category_name' => $name, 'slug' => $slug, 'status' => $status]);
            $log_sql = "INSERT INTO admin_logs (admin_id, action, table_name, record_id, old_value, new_value, created_at)
                        VALUES (?, 'UPDATE', 'categories', ?, ?, ?, NOW())";
            $log_stmt = mysqli_prepare($conn, $log_sql);
            mysqli_stmt_bind_param($log_stmt, 'iiss', $_SESSION['user_id'], $id, $old_value, $new_value);
            mysqli_stmt_execute($log_stmt);
            
            header('Location: index.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Sửa Danh Mục</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px 40px; }
        .header h1 { font-size: 24px; }
        .container { max-width: 800px; margin: 30px auto; padding: 0 20px; }
        .card { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 500; color: #333; }
        .form-group input, .form-group textarea, .form-group select {
            width: 100%; padding: 10px 15px; border: 2px solid #e0e0e0; border-radius: 6px; font-size: 14px;
        }
        .form-group textarea { min-height: 100px; }
        .error { background: #fee; color: #c33; padding: 12px; border-radius: 6px; margin-bottom: 20px; }
        .btn { padding: 12px 30px; background: #667eea; color: white; border: none; border-radius: 6px; 
               cursor: pointer; font-size: 14px; margin-right: 10px; text-decoration: none; display: inline-block; }
        .btn:hover { background: #5568d3; }
        .btn-secondary { background: #6c757d; }
        .btn-secondary:hover { background: #5a6268; }
    </style>
</head>
<body>
    <div class="header">
        <h1>✏️ Sửa Danh Mục</h1>
    </div>
    
    <div class="container">
        <div class="card">
            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 if($error): ?>
                <div class="error"><?= htmlspecialchars($error) ?></div>
            <?php
require_once __DIR__ . '/../includes/check_admin.php';
 endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label>Tên Danh Mục *</label>
                    <input type="text" name="category_name" value="<?= htmlspecialchars($category['category_name']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Slug</label>
                    <input type="text" name="slug" value="<?= htmlspecialchars($category['slug']) ?>">
                </div>
                
                <div class="form-group">
                    <label>Mô Tả</label>
                    <textarea name="description"><?= htmlspecialchars($category['description'] ?? '') ?></textarea>
                </div>
                
                <div class="form-group">
                    <label>Trạng Thái</label>
                    <select name="status">
                        <option value="active" <?= $category['status'] == 'active' ? 'selected' : '' ?>>Hoạt động</option>
                        <option value="inactive" <?= $category['status'] == 'inactive' ? 'selected' : '' ?>>Tắt</option>
                    </select>
                </div>
                
                <button type="submit" class="btn">Cập Nhật</button>
                <a href="index.php" class="btn btn-secondary">Hủy</a>
            </form>
        </div>
    </div>
</body>
</html>
