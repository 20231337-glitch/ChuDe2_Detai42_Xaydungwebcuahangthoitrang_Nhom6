<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

// Kiểm tra quyền admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

$admin_name = $_SESSION['fullname'];

// ===== 1. THỐNG KÊ TỔNG QUAN =====

// 1.1 Tổng doanh thu
$sql_revenue = "SELECT SUM(final_amount) as total_revenue
               FROM orders
               WHERE order_status IN ('completed', 'shipping')
               AND payment_status = 'paid'";
$result_revenue = mysqli_query($conn, $sql_revenue);
$total_revenue = mysqli_fetch_assoc($result_revenue)['total_revenue'] ?? 0;

// 1.2 Tổng đơn hàng
$sql_total_orders = "SELECT COUNT(*) as total FROM orders";
$result_total_orders = mysqli_query($conn, $sql_total_orders);
$total_orders = mysqli_fetch_assoc($result_total_orders)['total'] ?? 0;

// 1.3 Tổng khách hàng
$sql_total_customers = "SELECT COUNT(*) as total FROM users WHERE role = 'customer' AND deleted_at IS NULL";
$result_total_customers = mysqli_query($conn, $sql_total_customers);
$total_customers = mysqli_fetch_assoc($result_total_customers)['total'] ?? 0;

// 1.4 Tổng sản phẩm
$sql_total_products = "SELECT COUNT(*) as total FROM products WHERE deleted_at IS NULL";
$result_total_products = mysqli_query($conn, $sql_total_products);
$total_products = mysqli_fetch_assoc($result_total_products)['total'] ?? 0;

// 1.5 Khách hàng mới trong tháng
$sql_new_customers = "SELECT COUNT(*) as new_customers
                      FROM users
                      WHERE role = 'customer'
                      AND created_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)";
$result_new_customers = mysqli_query($conn, $sql_new_customers);
$new_customers = mysqli_fetch_assoc($result_new_customers)['new_customers'] ?? 0;

// ===== 2. THỐNG KÊ ĐƠN HÀNG THEO TRẠNG THÁI =====
$sql_orders_status = "SELECT 
                          order_status,
                          COUNT(*) as total_orders,
                          SUM(final_amount) as total_amount
                      FROM orders
                      GROUP BY order_status";
$result_orders_status = mysqli_query($conn, $sql_orders_status);
$orders_by_status = [];
while($row = mysqli_fetch_assoc($result_orders_status)) {
    $orders_by_status[$row['order_status']] = $row;
}

// ===== 3. TOP 10 SẢN PHẨM BÁN CHẠY =====
$sql_top_products = "SELECT p.product_id, p.product_name, p.sold_count, p.base_price, pi.image_url
                     FROM products p
                     LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
                     WHERE p.deleted_at IS NULL
                     ORDER BY p.sold_count DESC
                     LIMIT 10";
$result_top_products = mysqli_query($conn, $sql_top_products);

// ===== 4. DOANH THU THEO THÁNG (12 THÁNG GẦN NHẤT) =====
$sql_revenue_monthly = "SELECT 
                            DATE_FORMAT(order_date, '%Y-%m') as month,
                            COUNT(*) as total_orders,
                            SUM(final_amount) as revenue
                        FROM orders
                        WHERE order_status IN ('completed', 'shipping')
                        AND order_date >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
                        GROUP BY DATE_FORMAT(order_date, '%Y-%m')
                        ORDER BY month";
$result_revenue_monthly = mysqli_query($conn, $sql_revenue_monthly);
$monthly_data = [];
while($row = mysqli_fetch_assoc($result_revenue_monthly)) {
    $monthly_data[] = $row;
}

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Fashion Shop</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Inter', sans-serif; 
            background: #f5f7fa;
            overflow-x: hidden;
        }
        
        /* ===== SIDEBAR ===== */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 260px;
            height: 100vh;
            background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
            color: white;
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 4px 0 15px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 30px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .sidebar-header h2 {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 5px;
        }
        .sidebar-header p {
            font-size: 13px;
            opacity: 0.8;
        }
        
        .sidebar-nav {
            padding: 20px 0;
        }
        .sidebar-nav ul {
            list-style: none;
        }
        .sidebar-nav .nav-section {
            padding: 15px 20px 8px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            opacity: 0.6;
            letter-spacing: 1px;
        }
        .sidebar-nav a {
            display: block;
            padding: 12px 20px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 14px;
        }
        .sidebar-nav a:hover,
        .sidebar-nav a.active {
            background: rgba(255,255,255,0.15);
            border-left: 3px solid white;
            padding-left: 17px;
        }
        
        /* ===== MAIN CONTENT ===== */
        .main-content {
            margin-left: 260px;
            min-height: 100vh;
        }
        
        /* Top Bar */
        .topbar {
            background: white;
            padding: 20px 30px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .topbar h1 {
            font-size: 24px;
            font-weight: 600;
            color: #333;
        }
        .topbar-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        .user-info {
            font-size: 14px;
            color: #666;
        }
        .btn-logout {
            padding: 8px 16px;
            background: #dc3545;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-size: 13px;
            transition: background 0.3s;
        }
        .btn-logout:hover {
            background: #c82333;
            color: white;
        }
        
        /* Page Content */
        .page-content {
            padding: 30px;
        }
        
        /* Stat Cards */
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            height: 100%;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            border-left: 4px solid transparent;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }
        .stat-card.revenue { border-left-color: #667eea; }
        .stat-card.orders { border-left-color: #f093fb; }
        .stat-card.customers { border-left-color: #4facfe; }
        .stat-card.products { border-left-color: #43e97b; }
        
        .stat-card .icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin-bottom: 15px;
        }
        .stat-card.revenue .icon { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }
        .stat-card.orders .icon { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; }
        .stat-card.customers .icon { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white; }
        .stat-card.products .icon { background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: white; }
        
        .stat-card .value {
            font-size: 26px;
            font-weight: 700;
            color: #333;
            margin-bottom: 5px;
        }
        .stat-card .label {
            font-size: 13px;
            color: #999;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 8px;
        }
        .stat-card .sub {
            font-size: 12px;
            color: #28a745;
            font-weight: 500;
        }
        
        /* Content Card */
        .content-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .content-card h2 {
            font-size: 18px;
            font-weight: 600;
            color: #333;
            margin-bottom: 20px;
            padding-bottom: 12px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        /* Status Grid */
        .status-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 15px;
        }
        .status-item {
            background: #f8f9fa;
            padding: 18px;
            border-radius: 10px;
            border-left: 3px solid #667eea;
        }
        .status-item .label {
            font-size: 13px;
            color: #666;
            margin-bottom: 8px;
        }
        .status-item .count {
            font-size: 24px;
            font-weight: 700;
            color: #333;
            margin-bottom: 5px;
        }
        .status-item .amount {
            font-size: 12px;
            color: #999;
        }
        
        /* Table */
        table.table {
            margin-bottom: 0;
        }
        table thead {
            background: #f8f9fa;
        }
        table thead th {
            font-weight: 600;
            color: #666;
            border: none;
            padding: 12px;
            font-size: 13px;
            text-transform: uppercase;
        }
        table tbody td {
            padding: 12px;
            vertical-align: middle;
            border-bottom: 1px solid #f0f0f0;
            font-size: 14px;
        }
        table tbody tr:hover {
            background: #f8f9fa;
        }
        .product-thumb {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 8px;
        }
        
        /* Chart Container */
        #revenueChart {
            max-height: 350px;
        }
        
        /* Buttons */
        .btn-custom {
            padding: 10px 20px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            display: inline-block;
            margin-right: 10px;
            margin-bottom: 10px;
            transition: all 0.3s;
        }
        .btn-custom:hover {
            background: #5568d3;
            transform: translateY(-2px);
            color: white;
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <h2>👔 FASHION SHOP</h2>
            <p>Admin Panel</p>
        </div>
        
        <nav class="sidebar-nav">
            <ul>
                <li><a href="#" class="active">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a></li>
                
                <li class="nav-section">Sản phẩm</li>
                <li><a href="../categories/"><i class="bi bi-folder"></i> Danh mục</a></li>
                <li><a href="../products/"><i class="bi bi-box"></i> Sản phẩm</a></li>
                <li><a href="../colors/"><i class="bi bi-palette"></i> Màu sắc</a></li>
                <li><a href="../sizes/"><i class="bi bi-rulers"></i> Kích thước</a></li>
                
                <li class="nav-section">Bán hàng</li>
                <li><a href="../orders/"><i class="bi bi-cart"></i> Đơn hàng</a></li>
                <li><a href="../customers/"><i class="bi bi-people"></i> Khách hàng</a></li>
                <li><a href="../coupons/"><i class="bi bi-ticket-perforated"></i> Mã giảm giá</a></li>
                
                <li class="nav-section">Khác</li>
                <li><a href="../reviews/"><i class="bi bi-star"></i> Đánh giá</a></li>
                <li><a href="../logs/"><i class="bi bi-journal-text"></i> Logs</a></li>
            </ul>
        </nav>
    </aside>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <header class="topbar">
            <h1><i class="bi bi-speedometer2"></i> Dashboard</h1>
            <div class="topbar-right">
                <span class="user-info">
                    <i class="bi bi-person-circle"></i> <?= htmlspecialchars($admin_name) ?>
                </span>
                <a href="../auth/logout.php" class="btn-logout">
                    <i class="bi bi-box-arrow-right"></i> Đăng xuất
                </a>
            </div>
        </header>
        
        <!-- Page Content -->
        <div class="page-content">
            <!-- Thống kê tổng quan -->
            <div class="row g-3 mb-4">
                <div class="col-lg-3 col-md-6">
                    <div class="stat-card revenue">
                        <div class="icon">💰</div>
                        <div class="label">Tổng Doanh Thu</div>
                        <div class="value"><?= number_format($total_revenue, 0, ',', '.') ?>đ</div>
                        <div class="sub">Đã thanh toán</div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6">
                    <div class="stat-card orders">
                        <div class="icon">📦</div>
                        <div class="label">Tổng Đơn Hàng</div>
                        <div class="value"><?= number_format($total_orders) ?></div>
                        <div class="sub">Tất cả trạng thái</div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6">
                    <div class="stat-card customers">
                        <div class="icon">👥</div>
                        <div class="label">Khách Hàng</div>
                        <div class="value"><?= number_format($total_customers) ?></div>
                        <div class="sub"><i class="bi bi-arrow-up"></i> +<?= $new_customers ?> mới tháng này</div>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6">
                    <div class="stat-card products">
                        <div class="icon">🎁</div>
                        <div class="label">Sản Phẩm</div>
                        <div class="value"><?= number_format($total_products) ?></div>
                        <div class="sub">Đang hoạt động</div>
                    </div>
                </div>
            </div>

            <!-- Đơn hàng theo trạng thái -->
            <div class="content-card">
                <h2><i class="bi bi-graph-up"></i> Đơn Hàng Theo Trạng Thái</h2>
                <div class="status-grid">
                    <?php
                    $status_labels = [
                        'processing' => '⏳ Đang xử lý',
                        'confirmed' => '✅ Đã xác nhận',
                        'shipping' => '🚚 Đang giao',
                        'completed' => '✔️ Hoàn thành',
                        'cancelled' => '❌ Đã hủy'
                    ];
                    
                    foreach($status_labels as $status => $label):
                        $data = $orders_by_status[$status] ?? ['total_orders' => 0, 'total_amount' => 0];
                    ?>
                    <div class="status-item">
                        <div class="label"><?= $label ?></div>
                        <div class="count"><?= number_format($data['total_orders']) ?></div>
                        <div class="amount"><?= number_format($data['total_amount'], 0, ',', '.') ?>đ</div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="row">
                <!-- Biểu đồ doanh thu -->
                <div class="col-lg-8">
                    <div class="content-card">
                        <h2><i class="bi bi-bar-chart-line"></i> Doanh Thu 12 Tháng Gần Nhất</h2>
                        <canvas id="revenueChart"></canvas>
                    </div>
                </div>

                <!-- Top sản phẩm -->
                <div class="col-lg-4">
                    <div class="content-card">
                        <h2><i class="bi bi-fire"></i> Top 10 Sản Phẩm</h2>
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Ảnh</th>
                                    <th>Tên</th>
                                    <th>Bán</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $count = 0;
                                while($product = mysqli_fetch_assoc($result_top_products)): 
                                    if($count >= 5) break; // Chỉ hiển thị 5 sản phẩm
                                    $count++;
                                ?>
                                <tr>
                                    <td>
                                        <?php if($product['image_url']): ?>
                                            <img src="../../<?= htmlspecialchars($product['image_url']) ?>" 
                                                 alt="" class="product-thumb">
                                        <?php else: ?>
                                            <div style="width:50px;height:50px;background:#ddd;border-radius:8px;"></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <strong><?= htmlspecialchars(mb_substr($product['product_name'], 0, 20)) ?>...</strong><br>
                                        <small class="text-muted"><?= number_format($product['base_price'], 0, ',', '.') ?>đ</small>
                                    </td>
                                    <td><span class="badge bg-primary"><?= number_format($product['sold_count']) ?></span></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="content-card">
                <h2><i class="bi bi-lightning-charge"></i> Thao Tác Nhanh</h2>
                <a href="../products/" class="btn-custom"><i class="bi bi-plus-circle"></i> Thêm Sản Phẩm</a>
                <a href="../orders/" class="btn-custom"><i class="bi bi-box-seam"></i> Quản Lý Đơn Hàng</a>
                <a href="../coupons/" class="btn-custom"><i class="bi bi-ticket-perforated"></i> Tạo Mã Giảm Giá</a>
                <a href="../customers/" class="btn-custom"><i class="bi bi-people"></i> Xem Khách Hàng</a>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    
    <script>
        // Dữ liệu từ PHP
        const monthlyData = <?= json_encode($monthly_data) ?>;
        
        // Chuẩn bị dữ liệu cho Chart.js
        const labels = monthlyData.map(item => {
            const [year, month] = item.month.split('-');
            return `Tháng ${month}/${year}`;
        });
        
        const revenues = monthlyData.map(item => parseFloat(item.revenue));
        
        // Tạo biểu đồ
        const ctx = document.getElementById('revenueChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Doanh thu (đ)',
                    data: revenues,
                    backgroundColor: 'rgba(102, 126, 234, 0.8)',
                    borderColor: 'rgba(102, 126, 234, 1)',
                    borderWidth: 1,
                    borderRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                label += new Intl.NumberFormat('vi-VN').format(context.parsed.y) + 'đ';
                                return label;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return new Intl.NumberFormat('vi-VN', {
                                    notation: 'compact',
                                    compactDisplay: 'short'
                                }).format(value) + 'đ';
                            }
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>