<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/constants.php';

// Kiểm tra quyền admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

// Lấy tham số lọc
$table_filter = isset($_GET['table']) ? $_GET['table'] : 'all';
$action_filter = isset($_GET['action']) ? $_GET['action'] : 'all';
$admin_filter = isset($_GET['admin_id']) ? intval($_GET['admin_id']) : 0;
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';

// Build query
$sql = "SELECT 
    l.*,
    u.fullname as admin_name,
    u.email as admin_email
FROM admin_logs l
JOIN users u ON l.admin_id = u.user_id
WHERE 1=1";

if ($table_filter != 'all') {
    $sql .= " AND l.table_name = '$table_filter'";
}

if ($action_filter != 'all') {
    $sql .= " AND l.action = '$action_filter'";
}

if ($admin_filter > 0) {
    $sql .= " AND l.admin_id = $admin_filter";
}

if ($date_from != '') {
    $sql .= " AND DATE(l.created_at) >= '$date_from'";
}

if ($date_to != '') {
    $sql .= " AND DATE(l.created_at) <= '$date_to'";
}

$sql .= " ORDER BY l.created_at DESC LIMIT 100";

$result = mysqli_query($conn, $sql);

// Lấy danh sách admin để filter
$admin_list = mysqli_query($conn, "SELECT user_id, fullname FROM users WHERE role='admin' ORDER BY fullname");

// Thống kê nhanh
$stats = mysqli_fetch_assoc(mysqli_query($conn, 
    "SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN action='CREATE' THEN 1 ELSE 0 END) as total_create,
        SUM(CASE WHEN action='UPDATE' THEN 1 ELSE 0 END) as total_update,
        SUM(CASE WHEN action='DELETE' THEN 1 ELSE 0 END) as total_delete
    FROM admin_logs
    WHERE DATE(created_at) = CURDATE()"
));
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xem Log hoạt động - Admin</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f7fa; }
        
        .container { max-width: 1600px; margin: 20px auto; padding: 0 20px; }
        
        .header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .header h1 { color: #2c3e50; margin-bottom: 10px; }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            border-left: 4px solid #3498db;
        }
        
        .stat-card.create { border-left-color: #27ae60; }
        .stat-card.update { border-left-color: #f39c12; }
        .stat-card.delete { border-left-color: #e74c3c; }
        
        .stat-card h3 { font-size: 14px; color: #7f8c8d; margin-bottom: 5px; }
        .stat-card .number { font-size: 32px; font-weight: bold; color: #2c3e50; }
        
        .filters {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }
        
        .filter-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .filters select, .filters input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            width: 100%;
        }
        
        .filter-buttons {
            display: flex;
            gap: 10px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-primary { background: #3498db; color: white; }
        .btn-primary:hover { background: #2980b9; }
        
        .btn-secondary { background: #95a5a6; color: white; }
        .btn-secondary:hover { background: #7f8c8d; }
        
        .table-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            overflow-x: auto;
        }
        
        table { width: 100%; border-collapse: collapse; min-width: 1200px; }
        
        th {
            background: #34495e;
            color: white;
            padding: 12px 10px;
            text-align: left;
            font-weight: 600;
            font-size: 13px;
        }
        
        td {
            padding: 12px 10px;
            border-bottom: 1px solid #ecf0f1;
            font-size: 13px;
        }
        
        tr:hover { background: #f8f9fa; }
        
        .badge {
            padding: 4px 8px;
            border-radius: 15px;
            font-size: 11px;
            font-weight: 600;
            display: inline-block;
        }
        
        .badge.CREATE { background: #d4edda; color: #155724; }
        .badge.UPDATE { background: #fff3cd; color: #856404; }
        .badge.DELETE { background: #f8d7da; color: #721c24; }
        
        .json-preview {
            max-width: 300px;
            max-height: 60px;
            overflow: hidden;
            text-overflow: ellipsis;
            font-family: 'Courier New', monospace;
            font-size: 11px;
            background: #f8f9fa;
            padding: 5px;
            border-radius: 3px;
            cursor: pointer;
        }
        
        .json-preview:hover { background: #e9ecef; }
        
        .no-data {
            text-align: center;
            padding: 50px;
            color: #7f8c8d;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📊 Nhật ký Hoạt động Admin</h1>
            <p>Theo dõi tất cả hoạt động thay đổi dữ liệu của admin</p>
        </div>
        
        <div class="stats">
            <div class="stat-card">
                <h3>Tổng hôm nay</h3>
                <div class="number"><?php echo $stats['total']; ?></div>
            </div>
            <div class="stat-card create">
                <h3>Thêm mới</h3>
                <div class="number"><?php echo $stats['total_create']; ?></div>
            </div>
            <div class="stat-card update">
                <h3>Cập nhật</h3>
                <div class="number"><?php echo $stats['total_update']; ?></div>
            </div>
            <div class="stat-card delete">
                <h3>Xóa</h3>
                <div class="number"><?php echo $stats['total_delete']; ?></div>
            </div>
        </div>
        
        <div class="filters">
            <form method="GET">
                <div class="filter-row">
                    <div>
                        <label style="display:block;margin-bottom:5px;font-size:13px;color:#7f8c8d;">Bảng dữ liệu:</label>
                        <select name="table">
                            <option value="all">Tất cả bảng</option>
                            <option value="products" <?php echo $table_filter=='products'?'selected':''; ?>>Sản phẩm</option>
                            <option value="categories" <?php echo $table_filter=='categories'?'selected':''; ?>>Danh mục</option>
                            <option value="orders" <?php echo $table_filter=='orders'?'selected':''; ?>>Đơn hàng</option>
                            <option value="users" <?php echo $table_filter=='users'?'selected':''; ?>>Người dùng</option>
                            <option value="coupons" <?php echo $table_filter=='coupons'?'selected':''; ?>>Mã giảm giá</option>
                            <option value="reviews" <?php echo $table_filter=='reviews'?'selected':''; ?>>Đánh giá</option>
                            <option value="order_returns" <?php echo $table_filter=='order_returns'?'selected':''; ?>>Trả hàng</option>
                        </select>
                    </div>
                    
                    <div>
                        <label style="display:block;margin-bottom:5px;font-size:13px;color:#7f8c8d;">Hành động:</label>
                        <select name="action">
                            <option value="all">Tất cả</option>
                            <option value="CREATE" <?php echo $action_filter=='CREATE'?'selected':''; ?>>Thêm mới</option>
                            <option value="UPDATE" <?php echo $action_filter=='UPDATE'?'selected':''; ?>>Cập nhật</option>
                            <option value="DELETE" <?php echo $action_filter=='DELETE'?'selected':''; ?>>Xóa</option>
                        </select>
                    </div>
                    
                    <div>
                        <label style="display:block;margin-bottom:5px;font-size:13px;color:#7f8c8d;">Admin:</label>
                        <select name="admin_id">
                            <option value="0">Tất cả admin</option>
                            <?php while ($admin = mysqli_fetch_assoc($admin_list)): ?>
                                <option value="<?php echo $admin['user_id']; ?>" 
                                        <?php echo $admin_filter==$admin['user_id']?'selected':''; ?>>
                                    <?php echo htmlspecialchars($admin['fullname']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div>
                        <label style="display:block;margin-bottom:5px;font-size:13px;color:#7f8c8d;">Từ ngày:</label>
                        <input type="date" name="date_from" value="<?php echo $date_from; ?>">
                    </div>
                    
                    <div>
                        <label style="display:block;margin-bottom:5px;font-size:13px;color:#7f8c8d;">Đến ngày:</label>
                        <input type="date" name="date_to" value="<?php echo $date_to; ?>">
                    </div>
                </div>
                
                <div class="filter-buttons">
                    <button type="submit" class="btn btn-primary">🔍 Lọc</button>
                    <a href="index.php" class="btn btn-secondary">🔄 Reset</a>
                </div>
            </form>
        </div>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Thời gian</th>
                        <th>Admin</th>
                        <th>Hành động</th>
                        <th>Bảng</th>
                        <th>Record ID</th>
                        <th>Giá trị cũ</th>
                        <th>Giá trị mới</th>
                        <th>IP</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($result) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><strong>#<?php echo $row['log_id']; ?></strong></td>
                            <td><?php echo date('d/m/Y H:i:s', strtotime($row['created_at'])); ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($row['admin_name']); ?></strong><br>
                                <small style="color:#7f8c8d;"><?php echo htmlspecialchars($row['admin_email']); ?></small>
                            </td>
                            <td><span class="badge <?php echo $row['action']; ?>"><?php echo $row['action']; ?></span></td>
                            <td><code><?php echo $row['table_name']; ?></code></td>
                            <td><?php echo $row['record_id'] ? '#'$row['record_id'] : '-'; ?></td>
                            <td>
                                <?php if ($row['old_value']): ?>
                                    <div class="json-preview" title="Click để xem chi tiết" 
                                         onclick="alert(this.getAttribute('data-full'));"
                                         data-full="<?php echo htmlspecialchars($row['old_value']); ?>">
                                        <?php echo htmlspecialchars(substr($row['old_value'], 0, 50)); ?>...
                                    </div>
                                <?php else: ?>
                                    <span style="color:#95a5a6;">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($row['new_value']): ?>
                                    <div class="json-preview" title="Click để xem chi tiết"
                                         onclick="alert(this.getAttribute('data-full'));"
                                         data-full="<?php echo htmlspecialchars($row['new_value']); ?>">
                                        <?php echo htmlspecialchars(substr($row['new_value'], 0, 50)); ?>...
                                    </div>
                                <?php else: ?>
                                    <span style="color:#95a5a6;">-</span>
                                <?php endif; ?>
                            </td>
                            <td><small><?php echo $row['ip_address'] ?: '-'; ?></small></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9" class="no-data">
                                <h3>📭 Không có log nào phù hợp</h3>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <div style="background:white;padding:15px;border-radius:10px;margin-top:20px;text-align:center;color:#7f8c8d;">
            <small>Hiển thị tối đa 100 log gần nhất theo điều kiện lọc</small>
        </div>
    </div>
</body>
</html>

<?php
mysqli_close($conn);
?>
