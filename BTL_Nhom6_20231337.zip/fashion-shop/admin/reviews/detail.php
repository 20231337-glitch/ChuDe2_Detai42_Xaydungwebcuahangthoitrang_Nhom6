<?php
require_once '../../config/database.php';
require_once '../../config/session.php';
require_once '../includes/auth_check.php';

check_admin();

$review_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Lấy thông tin đánh giá
$sql = "SELECT 
    r.*,
    u.fullname as customer_name,
    u.email as customer_email,
    u.phone as customer_phone,
    p.product_name,
    p.product_id,
    o.order_id,
    o.order_date
FROM reviews r
JOIN users u ON r.user_id = u.user_id
JOIN products p ON r.product_id = p.product_id
LEFT JOIN orders o ON r.order_id = o.order_id
WHERE r.review_id = ?";

$stmt = $pdo->prepare($sql);
$stmt->execute([$review_id]);
$review = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$review) {
    header('Location: index.php?error=Đánh giá không tồn tại');
    exit;
}

$page_title = 'Chi tiết đánh giá #' . $review_id;
include '../includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><?php echo $page_title; ?></h2>
                <a href="index.php" class="btn btn-secondary">← Quay lại</a>
            </div>

            <div class="row">
                <div class="col-md-8">
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0">Nội dung đánh giá</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <strong>Sản phẩm:</strong><br>
                                <a href="../../public/products/detail.php?id=<?php echo $review['product_id']; ?>" target="_blank">
                                    <h5><?php echo htmlspecialchars($review['product_name']); ?></h5>
                                </a>
                            </div>

                            <div class="mb-3">
                                <strong>Đánh giá:</strong><br>
                                <div class="text-warning h4">
                                    <?php echo str_repeat('⭐', $review['rating']); ?>
                                    <span class="text-dark">(<?php echo $review['rating']; ?>/5)</span>
                                </div>
                            </div>

                            <div class="mb-3">
                                <strong>Nội dung:</strong>
                                <div class="p-3 bg-light border rounded">
                                    <?php echo nl2br(htmlspecialchars($review['comment'] ?? 'Không có nội dung')); ?>
                                </div>
                            </div>

                            <?php if (!empty($review['images'])): ?>
                                <div class="mb-3">
                                    <strong>Hình ảnh đính kèm:</strong><br>
                                    <?php
                                    $images = json_decode($review['images'], true);
                                    if (is_array($images)) {
                                        foreach ($images as $image) {
                                            echo '<img src="../../' . htmlspecialchars($image) . '" alt="Review Image" class="img-thumbnail m-1" style="max-width: 200px;">';
                                        }
                                    }
                                    ?>
                                </div>
                            <?php endif; ?>

                            <div class="mb-3">
                                <strong>Ngày tạo:</strong>
                                <?php echo date('d/m/Y H:i:s', strtotime($review['created_at'])); ?>
                            </div>

                            <div class="mb-3">
                                <strong>Trạng thái:</strong>
                                <?php
                                $status_badges = [
                                    'pending' => 'warning',
                                    'approved' => 'success',
                                    'rejected' => 'danger'
                                ];
                                $status_labels = [
                                    'pending' => 'Chờ duyệt',
                                    'approved' => 'Đã duyệt',
                                    'rejected' => 'Đã từ chối'
                                ];
                                $badge = $status_badges[$review['status']] ?? 'secondary';
                                $label = $status_labels[$review['status']] ?? $review['status'];
                                ?>
                                <span class="badge bg-<?php echo $badge; ?> fs-6"><?php echo $label; ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- Actions -->
                    <?php if ($review['status'] === 'pending'): ?>
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Thao tác</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-flex gap-2">
                                    <a href="approve.php?id=<?php echo $review_id; ?>" 
                                       class="btn btn-success"
                                       onclick="return confirm('Bạn có chắc muốn duyệt đánh giá này?')">
                                        <i class="fas fa-check"></i> Duyệt đánh giá
                                    </a>
                                    <a href="reject.php?id=<?php echo $review_id; ?>" 
                                       class="btn btn-warning"
                                       onclick="return confirm('Bạn có chắc muốn từ chối đánh giá này?')">
                                        <i class="fas fa-times"></i> Từ chối
                                    </a>
                                    <a href="delete.php?id=<?php echo $review_id; ?>" 
                                       class="btn btn-danger"
                                       onclick="return confirm('Bạn có chắc muốn XÓA đánh giá này?')">
                                        <i class="fas fa-trash"></i> Xóa
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-header bg-success text-white">
                            <h5 class="mb-0">Thông tin khách hàng</h5>
                        </div>
                        <div class="card-body">
                            <p><strong>Họ tên:</strong><br><?php echo htmlspecialchars($review['customer_name']); ?></p>
                            <p><strong>Email:</strong><br><?php echo htmlspecialchars($review['customer_email']); ?></p>
                            <p><strong>SĐT:</strong><br><?php echo htmlspecialchars($review['customer_phone'] ?? 'N/A'); ?></p>
                            <a href="../customers/detail.php?id=<?php echo $review['user_id']; ?>" class="btn btn-sm btn-info">
                                <i class="fas fa-user"></i> Xem hồ sơ
                            </a>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header bg-info text-white">
                            <h5 class="mb-0">Thông tin đơn hàng</h5>
                        </div>
                        <div class="card-body">
                            <?php if ($review['order_id']): ?>
                                <p><strong>Mã đơn:</strong> #<?php echo $review['order_id']; ?></p>
                                <p><strong>Ngày đặt:</strong><br><?php echo date('d/m/Y', strtotime($review['order_date'])); ?></p>
                                <a href="../orders/detail.php?id=<?php echo $review['order_id']; ?>" class="btn btn-sm btn-info">
                                    <i class="fas fa-shopping-cart"></i> Xem đơn hàng
                                </a>
                            <?php else: ?>
                                <p class="text-muted">Không có thông tin đơn hàng</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
