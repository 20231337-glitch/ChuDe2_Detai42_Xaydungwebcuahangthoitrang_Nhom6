<?php
require_once '../../config/database.php';
require_once '../../config/session.php';
require_once '../includes/auth_check.php';

check_admin();

$review_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($review_id <= 0) {
    header('Location: index.php?error=ID không hợp lệ');
    exit;
}

try {
    $pdo->beginTransaction();
    
    // Kiểm tra đánh giá tồn tại
    $check_sql = "SELECT * FROM reviews WHERE review_id = ?";
    $check_stmt = $pdo->prepare($check_sql);
    $check_stmt->execute([$review_id]);
    $review = $check_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$review) {
        throw new Exception('Đánh giá không tồn tại');
    }
    
    // Xóa ảnh nếu có
    if (!empty($review['images'])) {
        $images = json_decode($review['images'], true);
        if (is_array($images)) {
            foreach ($images as $image) {
                $image_path = '../../' . $image;
                if (file_exists($image_path)) {
                    @unlink($image_path);
                }
            }
        }
    }
    
    // Xóa đánh giá
    $delete_sql = "DELETE FROM reviews WHERE review_id = ?";
    $delete_stmt = $pdo->prepare($delete_sql);
    $delete_stmt->execute([$review_id]);
    
    // Ghi log
    $log_sql = "INSERT INTO admin_logs (admin_id, action, table_name, record_id, created_at)
                VALUES (?, 'DELETE', 'reviews', ?, NOW())";
    $log_stmt = $pdo->prepare($log_sql);
    $log_stmt->execute([$_SESSION['user_id'], $review_id]);
    
    $pdo->commit();
    
    header('Location: index.php?success=Đã xóa đánh giá thành công');
    exit;
    
} catch (Exception $e) {
    $pdo->rollBack();
    header('Location: index.php?error=' . urlencode($e->getMessage()));
    exit;
}
