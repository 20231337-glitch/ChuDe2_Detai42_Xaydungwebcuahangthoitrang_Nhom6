<?php
require_once '../../config/database.php';
require_once '../../config/session.php';
require_once '../includes/auth_check.php';

check_admin();

$page_title = 'Quản lý đánh giá';

// Phân trang
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Lọc theo trạng thái
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'pending';
$rating_filter = isset($_GET['rating']) ? (int)$_GET['rating'] : 0;

// Xây dựng query
$where_conditions = [];
$params = [];

if (!empty($status_filter)) {
    $where_conditions[] = "r.status = ?";
    $params[] = $status_filter;
}

if ($rating_filter > 0) {
    $where_conditions[] = "r.rating = ?";
    $params[] = $rating_filter;
}

$where_sql = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Đếm tổng
$count_sql = "SELECT COUNT(*) as total FROM reviews r $where_sql";
$count_stmt = $pdo->prepare($count_sql);
$count_stmt->execute($params);
$total_reviews = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
$total_pages = ceil($total_reviews / $limit);

// Lấy danh sách đánh giá
$sql = "SELECT 
    r.*,
    u.fullname as customer_name,
    u.email as customer_email,
    p.product_name,
    o.order_id
FROM reviews r
JOIN users u ON r.user_id = u.user_id
JOIN products p ON r.product_id = p.product_id
LEFT JOIN orders o ON r.order_id = o.order_id
$where_sql
ORDER BY r.created_at DESC
LIMIT ? OFFSET ?";

$stmt = $pdo->prepare($sql);
$stmt->execute(array_merge($params, [$limit, $offset]));
$reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Đếm theo trạng thái
$stats_sql = "SELECT 
    status,
    COUNT(*) as count
FROM reviews
GROUP BY status";
$stats_stmt = $pdo->query($stats_sql);
$stats = $stats_stmt->fetchAll(PDO::FETCH_KEY_PAIR);

include '../includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><?php echo $page_title; ?></h2>
            </div>

            <!-- Statistics -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card text-white bg-warning">
                        <div class="card-body">
                            <h5>Chờ duyệt</h5>
                            <h2><?php echo number_format($stats['pending'] ?? 0); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-white bg-success">
                        <div class="card-body">
                            <h5>Đã duyệt</h5>
                            <h2><?php echo number_format($stats['approved'] ?? 0); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-white bg-danger">
                        <div class="card-body">
                            <h5>Đã từ chối</h5>
                            <h2><?php echo number_format($stats['rejected'] ?? 0); ?></h2>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Filters -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-3">
                            <select name="status" class="form-control">
                                <option value="">-- Tất cả trạng thái --</option>
                                <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Chờ duyệt</option>
                                <option value="approved" <?php echo $status_filter === 'approved' ? 'selected' : ''; ?>>Đã duyệt</option>
                                <option value="rejected" <?php echo $status_filter === 'rejected' ? 'selected' : ''; ?>>Đã từ chối</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select name="rating" class="form-control">
                                <option value="0">-- Tất cả đánh giá --</option>
                                <option value="5" <?php echo $rating_filter === 5 ? 'selected' : ''; ?>>⭐⭐⭐⭐⭐ (5 sao)</option>
                                <option value="4" <?php echo $rating_filter === 4 ? 'selected' : ''; ?>>⭐⭐⭐⭐ (4 sao)</option>
                                <option value="3" <?php echo $rating_filter === 3 ? 'selected' : ''; ?>>⭐⭐⭐ (3 sao)</option>
                                <option value="2" <?php echo $rating_filter === 2 ? 'selected' : ''; ?>>⭐⭐ (2 sao)</option>
                                <option value="1" <?php echo $rating_filter === 1 ? 'selected' : ''; ?>>⭐ (1 sao)</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100">Lọc</button>
                        </div>
                        <div class="col-md-2">
                            <a href="index.php" class="btn btn-secondary w-100">Reset</a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Reviews Table -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Khách hàng</th>
                                    <th>Sản phẩm</th>
                                    <th>Đánh giá</th>
                                    <th>Nội dung</th>
                                    <th>Ngày tạo</th>
                                    <th>Trạng thái</th>
                                    <th>Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($reviews)): ?>
                                    <tr>
                                        <td colspan="8" class="text-center">Không có đánh giá nào</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($reviews as $review): ?>
                                        <tr>
                                            <td><?php echo $review['review_id']; ?></td>
                                            <td>
                                                <strong><?php echo htmlspecialchars($review['customer_name']); ?></strong><br>
                                                <small class="text-muted"><?php echo htmlspecialchars($review['customer_email']); ?></small>
                                            </td>
                                            <td>
                                                <a href="../../public/products/detail.php?id=<?php echo $review['product_id']; ?>" target="_blank">
                                                    <?php echo htmlspecialchars($review['product_name']); ?>
                                                </a>
                                            </td>
                                            <td>
                                                <div class="text-warning">
                                                    <?php echo str_repeat('⭐', $review['rating']); ?>
                                                </div>
                                            </td>
                                            <td style="max-width: 300px;">
                                                <div class="text-truncate" title="<?php echo htmlspecialchars($review['comment']); ?>">
                                                    <?php echo htmlspecialchars($review['comment'] ?? ''); ?>
                                                </div>
                                            </td>
                                            <td><?php echo date('d/m/Y H:i', strtotime($review['created_at'])); ?></td>
                                            <td>
                                                <?php
                                                $status_badges = [
                                                    'pending' => 'warning',
                                                    'approved' => 'success',
                                                    'rejected' => 'danger'
                                                ];
                                                $status_labels = [
                                                    'pending' => 'Chờ duyệt',
                                                    'approved' => 'Đã duyệt',
                                                    'rejected' => 'Đã từ chối'
                                                ];
                                                $badge = $status_badges[$review['status']] ?? 'secondary';
                                                $label = $status_labels[$review['status']] ?? $review['status'];
                                                ?>
                                                <span class="badge bg-<?php echo $badge; ?>"><?php echo $label; ?></span>
                                            </td>
                                            <td>
                                                <a href="detail.php?id=<?php echo $review['review_id']; ?>" 
                                                   class="btn btn-sm btn-info" title="Chi tiết">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <?php if ($review['status'] === 'pending'): ?>
                                                    <a href="approve.php?id=<?php echo $review['review_id']; ?>" 
                                                       class="btn btn-sm btn-success" 
                                                       onclick="return confirm('Duyệt đánh giá này?')"
                                                       title="Duyệt">
                                                        <i class="fas fa-check"></i>
                                                    </a>
                                                    <a href="reject.php?id=<?php echo $review['review_id']; ?>" 
                                                       class="btn btn-sm btn-warning" 
                                                       onclick="return confirm('Từ chối đánh giá này?')"
                                                       title="Từ chối">
                                                        <i class="fas fa-times"></i>
                                                    </a>
                                                <?php endif; ?>
                                                <a href="delete.php?id=<?php echo $review['review_id']; ?>" 
                                                   class="btn btn-sm btn-danger" 
                                                   onclick="return confirm('Bạn có chắc muốn xóa đánh giá này?')"
                                                   title="Xóa">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <nav>
                            <ul class="pagination justify-content-center">
                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?page=<?php echo $i; ?>&status=<?php echo urlencode($status_filter); ?>&rating=<?php echo $rating_filter; ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    </li>
                                <?php endfor; ?>
                            </ul>
                        </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
