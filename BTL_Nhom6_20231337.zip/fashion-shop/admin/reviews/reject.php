<?php
require_once '../../config/database.php';
require_once '../../config/session.php';
require_once '../includes/auth_check.php';

check_admin();

$review_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($review_id <= 0) {
    header('Location: index.php?error=ID không hợp lệ');
    exit;
}

try {
    $pdo->beginTransaction();
    
    // Kiểm tra đánh giá tồn tại
    $check_sql = "SELECT * FROM reviews WHERE review_id = ?";
    $check_stmt = $pdo->prepare($check_sql);
    $check_stmt->execute([$review_id]);
    $review = $check_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$review) {
        throw new Exception('Đánh giá không tồn tại');
    }
    
    // Cập nhật trạng thái
    $update_sql = "UPDATE reviews SET status = 'rejected' WHERE review_id = ?";
    $update_stmt = $pdo->prepare($update_sql);
    $update_stmt->execute([$review_id]);
    
    // Ghi log
    $log_sql = "INSERT INTO admin_logs (admin_id, action, table_name, record_id, old_value, new_value, created_at)
                VALUES (?, 'UPDATE', 'reviews', ?, ?, ?, NOW())";
    $log_stmt = $pdo->prepare($log_sql);
    $log_stmt->execute([
        $_SESSION['user_id'],
        $review_id,
        json_encode(['status' => $review['status']]),
        json_encode(['status' => 'rejected'])
    ]);
    
    // Thông báo cho khách hàng
    $notif_sql = "INSERT INTO notifications (user_id, type, title, message, created_at)
                   VALUES (?, 'review_rejected', 'Đánh giá bị từ chối', 'Đánh giá của bạn không được duyệt do vi phạm quy định.', NOW())";
    $notif_stmt = $pdo->prepare($notif_sql);
    $notif_stmt->execute([$review['user_id']]);
    
    $pdo->commit();
    
    header('Location: index.php?success=Đã từ chối đánh giá');
    exit;
    
} catch (Exception $e) {
    $pdo->rollBack();
    header('Location: detail.php?id=' . $review_id . '&error=' . urlencode($e->getMessage()));
    exit;
}
