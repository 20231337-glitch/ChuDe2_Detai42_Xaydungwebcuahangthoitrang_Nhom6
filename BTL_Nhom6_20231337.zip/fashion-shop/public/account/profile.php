<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {
    header('Location: ../auth/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$success_msg = '';
$error_msg = '';

// Xử lý cập nhật thông tin
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fullname = trim($_POST['fullname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $new_password = trim($_POST['new_password'] ?? '');
    
    // Validate
    if (empty($fullname) || empty($email) || empty($phone)) {
        $error_msg = 'Vui lòng điền đầy đủ thông tin bắt buộc!';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_msg = 'Email không hợp lệ!';
    } else {
        // Kiểm tra email trùng (trừ email của chính mình)
        $check_sql = "SELECT user_id FROM users WHERE email = ? AND user_id != ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("si", $email, $user_id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            $error_msg = 'Email này đã được sử dụng bởi tài khoản khác!';
        } else {
            // Cập nhật thông tin
            if (!empty($new_password)) {
                // Cập nhật cả mật khẩu
                $update_sql = "UPDATE users SET fullname = ?, email = ?, phone = ?, address = ?, password = ?, updated_at = NOW() WHERE user_id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("sssssi", $fullname, $email, $phone, $address, $new_password, $user_id);
            } else {
                // Chỉ cập nhật thông tin cơ bản
                $update_sql = "UPDATE users SET fullname = ?, email = ?, phone = ?, address = ?, updated_at = NOW() WHERE user_id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("ssssi", $fullname, $email, $phone, $address, $user_id);
            }
            
            if ($update_stmt->execute()) {
                $success_msg = 'Cập nhật thông tin thành công!';
                $_SESSION['fullname'] = $fullname;
            } else {
                $error_msg = 'Có lỗi xảy ra, vui lòng thử lại!';
            }
            $update_stmt->close();
        }
        $check_stmt->close();
    }
}

// Lấy thông tin người dùng
$sql = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thông tin cá nhân - Fashion Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        
        .profile-container {
            max-width: 900px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        
        .profile-header {
            background: white;
            border-radius: 15px 15px 0 0;
            padding: 2rem;
            text-align: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .profile-avatar {
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            color: white;
            font-size: 3rem;
            font-weight: 700;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }
        
        .profile-header h1 {
            font-size: 1.75rem;
            font-weight: 700;
            color: #212529;
            margin-bottom: 0.5rem;
        }
        
        .profile-header p {
            color: #6c757d;
            margin-bottom: 1.5rem;
        }
        
        .header-actions {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .btn-action {
            padding: 0.5rem 1.5rem;
            border-radius: 8px;
            border: none;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s;
        }
        
        .btn-orders {
            background: #0d6efd;
            color: white;
        }
        
        .btn-orders:hover {
            background: #0a58ca;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(13,110,253,0.3);
        }
        
        .btn-logout {
            background: #dc3545;
            color: white;
        }
        
        .btn-logout:hover {
            background: #bb2d3b;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(220,53,69,0.3);
        }
        
        .btn-home {
            background: #6c757d;
            color: white;
        }
        
        .btn-home:hover {
            background: #5a6268;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(108,117,125,0.3);
        }
        
        .profile-card {
            background: white;
            border-radius: 0 0 15px 15px;
            padding: 2rem;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .form-label {
            font-weight: 600;
            color: #495057;
            margin-bottom: 0.5rem;
        }
        
        .form-control, .form-select {
            border-radius: 10px;
            border: 2px solid #e9ecef;
            padding: 0.75rem 1rem;
            transition: all 0.3s;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.25rem rgba(102,126,234,0.15);
        }
        
        .form-control:disabled {
            background: #f8f9fa;
            cursor: not-allowed;
        }
        
        textarea.form-control {
            resize: vertical;
            min-height: 100px;
        }
        
        .password-hint {
            font-size: 0.875rem;
            color: #6c757d;
            margin-top: 0.5rem;
        }
        
        .password-hint i {
            color: #ffc107;
        }
        
        .form-actions {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
        }
        
        .btn-save {
            flex: 1;
            padding: 1rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1.125rem;
            font-weight: 700;
            transition: all 0.3s;
            box-shadow: 0 4px 12px rgba(102,126,234,0.3);
        }
        
        .btn-save:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(102,126,234,0.4);
        }
        
        .btn-cancel {
            padding: 1rem 2rem;
            background: white;
            color: #495057;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            font-size: 1.125rem;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-cancel:hover {
            background: #f8f9fa;
            border-color: #dee2e6;
            transform: translateY(-2px);
        }
        
        .alert {
            border-radius: 10px;
            padding: 1rem 1.25rem;
            margin-bottom: 1.5rem;
            border: none;
        }
        
        .alert-success {
            background: #d1e7dd;
            color: #0f5132;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #842029;
        }
        
        .info-badge {
            display: inline-block;
            background: #e7f3ff;
            color: #0066cc;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.875rem;
            font-weight: 600;
            margin-left: 0.5rem;
        }
        
        @media (max-width: 768px) {
            .header-actions {
                flex-direction: column;
                width: 100%;
            }
            
            .btn-action {
                width: 100%;
                justify-content: center;
            }
            
            .form-actions {
                flex-direction: column;
            }
            
            .btn-cancel {
                order: 2;
            }
        }
    </style>
</head>
<body>

<div class="profile-container">
    <!-- Profile Header -->
    <div class="profile-header">
        <div class="profile-avatar">
            <?= strtoupper(substr($user['fullname'], 0, 1)) ?>
        </div>
        <h1><?= htmlspecialchars($user['fullname']) ?></h1>
        <p>@<?= htmlspecialchars($user['username']) ?> <span class="info-badge">Khách hàng</span></p>
        
        <div class="header-actions">
            <a href="/fashion-shop/public/home/" class="btn-action btn-home">
                <i class="fas fa-home"></i> Trang chủ
            </a>
            <a href="orders.php" class="btn-action btn-orders">
                <i class="fas fa-shopping-bag"></i> Đơn hàng của tôi
            </a>
            <a href="../auth/logout.php" class="btn-action btn-logout" onclick="return confirm('Bạn có chắc muốn đăng xuất?')">
                <i class="fas fa-sign-out-alt"></i> Đăng xuất
            </a>
        </div>
    </div>
    
    <!-- Profile Form -->
    <div class="profile-card">
        <?php if ($success_msg): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?= $success_msg ?>
            </div>
        <?php endif; ?>
        
        <?php if ($error_msg): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <?= $error_msg ?>
            </div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="username" class="form-label">
                        <i class="fas fa-user text-primary"></i> Tên đăng nhập *
                    </label>
                    <input type="text" id="username" class="form-control" 
                           value="<?= htmlspecialchars($user['username']) ?>" disabled>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="fullname" class="form-label">
                        <i class="fas fa-id-card text-success"></i> Họ và tên *
                    </label>
                    <input type="text" id="fullname" name="fullname" class="form-control" 
                           value="<?= htmlspecialchars($user['fullname']) ?>" required>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="email" class="form-label">
                        <i class="fas fa-envelope text-info"></i> Email *
                    </label>
                    <input type="email" id="email" name="email" class="form-control" 
                           value="<?= htmlspecialchars($user['email']) ?>" required>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label for="phone" class="form-label">
                        <i class="fas fa-phone text-warning"></i> Số điện thoại *
                    </label>
                    <input type="tel" id="phone" name="phone" class="form-control" 
                           value="<?= htmlspecialchars($user['phone'] ?? '') ?>" required>
                </div>
            </div>
            
            <div class="mb-3">
                <label for="address" class="form-label">
                    <i class="fas fa-map-marker-alt text-danger"></i> Địa chỉ
                </label>
                <textarea id="address" name="address" class="form-control"><?= htmlspecialchars($user['address'] ?? '') ?></textarea>
            </div>
            
            <div class="mb-3">
                <label for="new_password" class="form-label">
                    <i class="fas fa-lock text-secondary"></i> Mật khẩu mới
                </label>
                <input type="password" id="new_password" name="new_password" class="form-control" 
                       placeholder="Nhập mật khẩu mới nếu muốn thay đổi">
                <div class="password-hint">
                    <i class="fas fa-info-circle"></i> Để trống nếu không muốn thay đổi mật khẩu
                </div>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn-save">
                    <i class="fas fa-save"></i> Lưu thay đổi
                </button>
                <a href="orders.php" class="btn btn-cancel">
                    <i class="fas fa-times"></i> Hủy
                </a>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>