<?php
$pageTitle = 'Giỏ hàng';
require_once __DIR__ . '/../includes/header.php';

// Kiểm tra đăng nhập
if (!isLoggedIn()) {
    redirect(BASE_URL . '/public/auth/login.php');
}

$userId = $_SESSION['user_id'];

// Lấy giỏ hàng
$sqlCart = "
    SELECT 
        c.cart_id,
        c.quantity,
        pv.variant_id,
        pv.stock_quantity,
        p.product_id,
        p.product_name,
        p.base_price,
        p.sale_price,
        s.size_name,
        col.color_name,
        col.color_code,
        pi.image_url,
        (IF(p.sale_price > 0, p.sale_price, p.base_price) * c.quantity) as subtotal
    FROM cart c
    JOIN product_variants pv ON c.variant_id = pv.variant_id
    JOIN products p ON pv.product_id = p.product_id AND p.status = 'active' AND p.deleted_at IS NULL
    JOIN sizes s ON pv.size_id = s.size_id
    JOIN colors col ON pv.color_id = col.color_id
    LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
    WHERE c.user_id = ?
    ORDER BY c.added_at DESC
";
$cartItems = fetchData($sqlCart, [$userId], 'i');

// Tính tổng tiền
$totalAmount = 0;
foreach ($cartItems as $item) {
    $totalAmount += $item['subtotal'];
}
?>

<style>
.cart-page-diamond {
    background-color: #f8f9fa;
    min-height: 80vh;
    padding: 2rem 0;
}
.cart-header-diamond h1 {
    font-size: 2rem;
    font-weight: 700;
    color: #333;
    margin-bottom: 0.5rem;
}
.cart-header-diamond .breadcrumb {
    background: none;
    padding: 0;
    margin: 0;
}
.cart-product-card {
    background: white;
    border-radius: 12px;
    padding: 1.25rem;
    margin-bottom: 1rem;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    transition: all 0.3s ease;
}
.cart-product-card:hover {
    box-shadow: 0 4px 16px rgba(0,0,0,0.12);
}
.product-img-diamond {
    width: 100px;
    height: 100px;
    border-radius: 10px;
    overflow: hidden;
    flex-shrink: 0;
}
.product-img-diamond img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}
.product-info-diamond {
    display: flex;
    gap: 1.25rem;
    align-items: center;
}
.product-details-diamond h5 {
    font-size: 1.1rem;
    font-weight: 600;
    color: #333;
    margin-bottom: 0.5rem;
}
.product-variant-info {
    font-size: 0.9rem;
    color: #666;
    margin-bottom: 0.25rem;
}
.color-circle {
    width: 18px;
    height: 18px;
    border-radius: 50%;
    display: inline-block;
    border: 2px solid #ddd;
    vertical-align: middle;
    margin: 0 5px;
}
.stock-badge {
    display: inline-block;
    background: #e7f5ff;
    color: #1971c2;
    padding: 0.25rem 0.75rem;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 500;
}
.quantity-control-diamond {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    background: #f1f3f5;
    border-radius: 8px;
    padding: 0.25rem;
    width: fit-content;
}
.quantity-control-diamond button {
    background: white;
    border: none;
    width: 32px;
    height: 32px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 1.1rem;
    font-weight: 600;
    color: #495057;
    transition: all 0.2s;
}
.quantity-control-diamond button:hover {
    background: #e9ecef;
    color: #212529;
}
.quantity-control-diamond input {
    width: 60px;
    height: 32px;
    text-align: center;
    border: none;
    background: white;
    border-radius: 6px;
    font-weight: 600;
    color: #212529;
}
.price-diamond {
    font-size: 1.1rem;
    font-weight: 700;
    color: #dc3545;
}
.subtotal-diamond {
    font-size: 1.2rem;
    font-weight: 700;
    color: #28a745;
}
.btn-remove-diamond {
    background: none;
    border: none;
    color: #dc3545;
    font-size: 1.5rem;
    cursor: pointer;
    padding: 0.5rem;
    transition: all 0.2s;
}
.btn-remove-diamond:hover {
    transform: scale(1.2);
}
.cart-summary-diamond {
    background: white;
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: 0 2px 12px rgba(0,0,0,0.1);
    position: sticky;
    top: 20px;
}
.cart-summary-diamond h4 {
    font-size: 1.3rem;
    font-weight: 700;
    margin-bottom: 1.5rem;
    color: #333;
}
.summary-row {
    display: flex;
    justify-content: space-between;
    padding: 0.75rem 0;
    border-bottom: 1px solid #e9ecef;
}
.summary-row:last-of-type {
    border-bottom: 2px solid #dee2e6;
    margin-bottom: 1rem;
}
.summary-total {
    display: flex;
    justify-content: space-between;
    padding: 1rem 0;
    font-size: 1.3rem;
    font-weight: 700;
}
.summary-total .total-amount {
    color: #dc3545;
}
.btn-checkout-diamond {
    width: 100%;
    padding: 1rem;
    background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
    border: none;
    border-radius: 8px;
    color: white;
    font-size: 1.1rem;
    font-weight: 700;
    text-align: center;
    text-decoration: none;
    display: block;
    margin-bottom: 0.75rem;
    transition: all 0.3s;
    box-shadow: 0 4px 12px rgba(220, 53, 69, 0.3);
}
.btn-checkout-diamond:hover {
    background: linear-gradient(135deg, #c82333 0%, #bd2130 100%);
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(220, 53, 69, 0.4);
    color: white;
    text-decoration: none;
}
.btn-continue-diamond {
    width: 100%;
    padding: 0.9rem;
    background: white;
    border: 2px solid #dee2e6;
    border-radius: 8px;
    color: #495057;
    font-size: 1rem;
    font-weight: 600;
    text-align: center;
    text-decoration: none;
    display: block;
    transition: all 0.3s;
}
.btn-continue-diamond:hover {
    background: #f8f9fa;
    border-color: #adb5bd;
    color: #212529;
    text-decoration: none;
}
.empty-cart-diamond {
    text-align: center;
    padding: 4rem 2rem;
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}
.empty-cart-diamond p {
    font-size: 1.5rem;
    color: #868e96;
    margin-bottom: 1.5rem;
}
</style>

<div class="cart-page-diamond">
    <div class="container">
        <div class="cart-header-diamond mb-4">
            <h1>🛒 Giỏ hàng của bạn</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>">Trang chủ</a></li>
                    <li class="breadcrumb-item active">Giỏ hàng</li>
                </ol>
            </nav>
        </div>
        
        <?php if (empty($cartItems)): ?>
            <div class="empty-cart-diamond">
                <p>😔 Giỏ hàng của bạn đang trống!</p>
                <a href="<?php echo BASE_URL; ?>/public/products/list.php" class="btn btn-primary btn-lg px-5">Tiếp tục mua sắm</a>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <!-- Cột trái: Sản phẩm -->
                <div class="col-lg-8">
                    <div class="mb-3">
                        <h5 class="fw-bold">Sản phẩm</h5>
                        <small class="text-muted">Đơn giá · Số lượng · Thành tiền</small>
                    </div>
                    
                    <?php foreach ($cartItems as $item): ?>
                        <div class="cart-product-card" data-cart-id="<?php echo $item['cart_id']; ?>">
                            <div class="row align-items-center">
                                <!-- Thông tin sản phẩm -->
                                <div class="col-md-6">
                                    <div class="product-info-diamond">
                                        <div class="product-img-diamond">
                                            <?php if ($item['image_url']): ?>
                                                <img src="<?php echo BASE_URL . $item['image_url']; ?>" alt="<?php echo e($item['product_name']); ?>">
                                            <?php else: ?>
                                                <img src="<?php echo BASE_URL; ?>/assets/images/no-image.png" alt="No image">
                                            <?php endif; ?>
                                        </div>
                                        <div class="product-details-diamond">
                                            <h5><?php echo e($item['product_name']); ?></h5>
                                            <div class="product-variant-info">
                                                Size: <strong><?php echo e($item['size_name']); ?></strong> | 
                                                Màu: <span class="color-circle" style="background:<?php echo e($item['color_code']); ?>;"></span>
                                                <strong><?php echo e($item['color_name']); ?></strong>
                                            </div>
                                            <span class="stock-badge">Còn <?php echo $item['stock_quantity']; ?> sản phẩm</span>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Đơn giá -->
                                <div class="col-md-2 text-center">
                                    <div class="price-diamond">
                                        <?php echo formatMoney($item['sale_price'] > 0 ? $item['sale_price'] : $item['base_price']); ?>
                                    </div>
                                </div>
                                
                                <!-- Số lượng -->
                                <div class="col-md-2 text-center">
                                    <div class="quantity-control-diamond">
                                        <button onclick="updateQuantity(<?php echo $item['cart_id']; ?>, <?php echo $item['quantity'] - 1; ?>)">-</button>
                                        <input type="number" 
                                               value="<?php echo $item['quantity']; ?>" 
                                               min="1" 
                                               max="<?php echo $item['stock_quantity']; ?>"
                                               onchange="updateQuantity(<?php echo $item['cart_id']; ?>, this.value)"
                                               readonly>
                                        <button onclick="updateQuantity(<?php echo $item['cart_id']; ?>, <?php echo $item['quantity'] + 1; ?>)">+</button>
                                    </div>
                                </div>
                                
                                <!-- Thành tiền & Xóa -->
                                <div class="col-md-2 text-center d-flex align-items-center justify-content-between">
                                    <div class="subtotal-diamond flex-grow-1">
                                        <?php echo formatMoney($item['subtotal']); ?>
                                    </div>
                                    <button class="btn-remove-diamond" onclick="removeFromCart(<?php echo $item['cart_id']; ?>)" title="Xóa sản phẩm">
                                        🗑️
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Cột phải: Tổng tiền -->
                <div class="col-lg-4">
                    <div class="cart-summary-diamond">
                        <h4>Tổng đơn hàng</h4>
                        
                        <div class="summary-row">
                            <span>Tạm tính:</span>
                            <strong><?php echo formatMoney($totalAmount); ?></strong>
                        </div>
                        
                        <div class="summary-row">
                            <span>Phí vận chuyển:</span>
                            <strong class="text-success">Miễn phí</strong>
                        </div>
                        
                        <div class="summary-total">
                            <span>Tổng cộng:</span>
                            <strong class="total-amount"><?php echo formatMoney($totalAmount); ?></strong>
                        </div>
                        
                        <a href="<?php echo BASE_URL; ?>/public/checkout/" class="btn-checkout-diamond">
                            TIẾN HÀNH THANH TOÁN
                        </a>
                        
                        <a href="<?php echo BASE_URL; ?>/public/products/list.php" class="btn-continue-diamond">
                            Tiếp tục mua sắm
                        </a>
                        
                        <div class="mt-3 pt-3 border-top">
                            <small class="text-muted d-block mb-2">✓ Miễn phí vận chuyển toàn quốc</small>
                            <small class="text-muted d-block mb-2">✓ Đổi trả trong 7 ngày</small>
                            <small class="text-muted d-block">✓ Thanh toán khi nhận hàng</small>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
// Cập nhật số lượng
function updateQuantity(cartId, newQuantity) {
    if (newQuantity < 1) {
        if (confirm('Bạn có muốn xóa sản phẩm này khỏi giỏ hàng?')) {
            removeFromCart(cartId);
        }
        return;
    }
    
    fetch('<?php echo BASE_URL; ?>/public/cart/update.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'cart_id=' + cartId + '&quantity=' + newQuantity
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert(data.message);
        }
    })
    .catch(err => alert('Có lỗi xảy ra!'));
}

// Xóa khỏi giỏ
function removeFromCart(cartId) {
    if (!confirm('Bạn có chắc muốn xóa sản phẩm này?')) return;
    
    fetch('<?php echo BASE_URL; ?>/public/cart/remove.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'cart_id=' + cartId
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert(data.message);
        }
    })
    .catch(err => alert('Có lỗi xảy ra!'));
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>