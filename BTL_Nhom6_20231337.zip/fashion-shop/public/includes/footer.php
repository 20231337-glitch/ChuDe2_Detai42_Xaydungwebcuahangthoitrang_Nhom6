<!-- Footer Slim Design -->
<footer class="bg-dark text-white-50 py-4 mt-5">
    <div class="container">
        <div class="row g-3">
            <!-- Col 1: Brand & Copyright -->
            <div class="col-lg-3 col-md-6">
                <h5 class="text-white fw-bold mb-3">
                    <i class="fas fa-tshirt me-2"></i>TshopNhom6
                </h5>
                <p class="small mb-2">Thời trang trẻ trung, năng động dành cho giới trẻ.</p>
                <p class="small mb-2">Chất lượng - Giá tốt - Giao nhanh</p>
                <p class="small text-white-50 mt-3 mb-0">
                    <i class="fas fa-copyright"></i> 2026 TshopNhom6<br>
                    <span style="font-size: 0.75rem;">Made with ❤️ by Nhóm 6</span>
                </p>
            </div>
            
            <!-- Col 2: Contact Info -->
            <div class="col-lg-3 col-md-6">
                <h6 class="text-white fw-bold mb-3">Liên hệ với chúng tôi</h6>
                <p class="small mb-1">
                    <i class="fas fa-map-marker-alt me-2 text-danger"></i>Hà Nội, Việt Nam
                </p>
                <p class="small mb-1">
                    <i class="fas fa-phone-alt me-2 text-success"></i>
                    <a href="tel:0355636882" class="text-white-50 text-decoration-none">0355.636.882</a>
                </p>
                <p class="small mb-1">
                    <i class="fas fa-envelope me-2 text-info"></i>
                    <a href="mailto:20231337@gmail.com" class="text-white-50 text-decoration-none">20231337@gmail.com</a>
                </p>
                <p class="small mb-0">
                    <i class="fas fa-clock me-2 text-warning"></i>8:00 - 22:00 (Hàng ngày)
                </p>
            </div>
            
            <!-- Col 3: Quick Links -->
            <div class="col-lg-3 col-md-6">
                <h6 class="text-white fw-bold mb-3">Liên kết nhanh</h6>
                <ul class="list-unstyled mb-0">
                    <li class="mb-1">
                        <a href="/fashion-shop/public/index.php" class="text-white-50 text-decoration-none small">
                            <i class="fas fa-chevron-right me-2" style="font-size: 0.7rem;"></i>Trang chủ
                        </a>
                    </li>
                    <li class="mb-1">
                        <a href="/fashion-shop/public/products/list.php" class="text-white-50 text-decoration-none small">
                            <i class="fas fa-chevron-right me-2" style="font-size: 0.7rem;"></i>Sản phẩm
                        </a>
                    </li>
                    <li class="mb-1">
                        <a href="/fashion-shop/public/cart/index.php" class="text-white-50 text-decoration-none small">
                            <i class="fas fa-chevron-right me-2" style="font-size: 0.7rem;"></i>Giỏ hàng
                        </a>
                    </li>
                    <li class="mb-0">
                        <a href="/fashion-shop/public/account/profile.php" class="text-white-50 text-decoration-none small">
                            <i class="fas fa-chevron-right me-2" style="font-size: 0.7rem;"></i>Tài khoản
                        </a>
                    </li>
                </ul>
            </div>
            
            <!-- Col 4: Social Media -->
            <div class="col-lg-3 col-md-6">
                <h6 class="text-white fw-bold mb-3">Kết nối với chúng tôi</h6>
                <p class="small mb-3">Theo dõi để nhận ưu đãi mới nhất!</p>
                <div class="d-flex gap-2">
                    <a href="https://facebook.com" class="btn btn-primary btn-sm" title="Facebook" style="width: 40px; height: 40px; padding: 0; display: flex; align-items: center; justify-content: center;">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="https://m.me/username" class="btn btn-info btn-sm text-white" title="Messenger" style="width: 40px; height: 40px; padding: 0; display: flex; align-items: center; justify-content: center;">
                        <i class="fab fa-facebook-messenger"></i>
                    </a>
                </div>
                <p class="small mt-3 mb-0 fst-italic">
                    <i class="fas fa-heart text-danger"></i> Style của bạn, niềm tự hào của chúng tôi!
                </p>
            </div>
        </div>
    </div>
</footer>

<style>
/* Footer Slim Custom Styles */
footer a:hover {
    color: #fff !important;
    transform: translateX(3px);
    transition: all 0.2s ease;
}

footer .btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.3);
    transition: all 0.3s ease;
}

footer h5, footer h6 {
    font-size: 1rem;
    letter-spacing: 0.5px;
}

footer .small {
    font-size: 0.875rem;
    line-height: 1.6;
}
</style>

<!-- Bootstrap 5 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Cart System CSS & JS -->
<link rel="stylesheet" href="/fashion-shop/assets/css/cart.css">
<script src="/fashion-shop/assets/js/cart.js"></script>

</body>
</html>