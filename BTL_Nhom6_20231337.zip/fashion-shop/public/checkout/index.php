<?php
session_start();
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    header('Location: /fashion-shop/public/auth/login.php?redirect=/fashion-shop/public/checkout/');
    exit;
}

$user_id = $_SESSION['user_id'];
$errors = [];
$success = '';

// Lấy thông tin user
$stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ? AND deleted_at IS NULL");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Lấy giỏ hàng
$query = "
    SELECT 
        c.cart_id, c.variant_id, c.quantity,
        p.product_id, p.product_name, p.sale_price, p.base_price, p.slug,
        s.size_name, col.color_name,
        pv.stock_quantity,
        pi.image_url,
        (IF(p.sale_price > 0, p.sale_price, p.base_price) * c.quantity) as subtotal
    FROM cart c
    JOIN product_variants pv ON c.variant_id = pv.variant_id
    JOIN products p ON pv.product_id = p.product_id AND p.status = 'active' AND p.deleted_at IS NULL
    JOIN sizes s ON pv.size_id = s.size_id
    JOIN colors col ON pv.color_id = col.color_id
    LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
    WHERE c.user_id = ?
    ORDER BY c.added_at DESC
";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$cart_items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Nếu giỏ hàng trống
if (empty($cart_items)) {
    header('Location: /fashion-shop/public/cart/');
    exit;
}

// Tính tổng tiền
$total_amount = 0;
foreach ($cart_items as $item) {
    $total_amount += $item['subtotal'];
}

// Xử lý áp dụng mã giảm giá
$coupon = null;
$discount_amount = 0;
$final_amount = $total_amount;

if (isset($_POST['apply_coupon'])) {
    $coupon_code = trim($_POST['coupon_code']);
    
    // Kiểm tra mã giảm giá
    $stmt = $conn->prepare("
        SELECT * FROM coupons
        WHERE coupon_code = ?
        AND status = 'active'
        AND expiry_date >= CURDATE()
        AND (max_uses IS NULL OR used_count < max_uses)
    ");
    $stmt->bind_param("s", $coupon_code);
    $stmt->execute();
    $coupon = $stmt->get_result()->fetch_assoc();
    
    if ($coupon) {
        // Kiểm tra user đã dùng mã này chưa
        $stmt = $conn->prepare("
            SELECT COUNT(*) as times_used
            FROM coupon_usage
            WHERE coupon_id = ? AND user_id = ?
        ");
        $stmt->bind_param("ii", $coupon['coupon_id'], $user_id);
        $stmt->execute();
        $usage = $stmt->get_result()->fetch_assoc();
        
        if ($usage['times_used'] >= $coupon['max_uses_per_user']) {
            $errors[] = "Bạn đã sử dụng mã giảm giá này rồi!";
            $coupon = null;
        } elseif ($total_amount < $coupon['min_order_value']) {
            $errors[] = "Đơn hàng phải từ " . number_format($coupon['min_order_value'], 0, ',', '.') . "đ mới được dùng mã này!";
            $coupon = null;
        } else {
            // Tính giảm giá
            if ($coupon['discount_type'] == 'percent') {
                $discount_amount = ($total_amount * $coupon['discount_value']) / 100;
            } else {
                $discount_amount = $coupon['discount_value'];
            }
            $final_amount = $total_amount - $discount_amount;
            $success = "Áp dụng mã giảm giá thành công!";
        }
    } else {
        $errors[] = "Mã giảm giá không hợp lệ hoặc đã hết hạn!";
    }
}

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thanh toán - Fashion Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        
        .checkout-container {
            max-width: 1400px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        
        .page-header {
            background: white;
            padding: 1.5rem 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        
        .page-header h1 {
            font-size: 2rem;
            font-weight: 700;
            color: #212529;
            margin: 0;
        }
        
        .btn-back {
            color: #0d6efd;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.2s;
        }
        
        .btn-back:hover {
            color: #0a58ca;
            text-decoration: underline;
        }
        
        /* Products List */
        .products-section {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        
        .section-title {
            font-size: 1.25rem;
            font-weight: 700;
            color: #212529;
            margin-bottom: 1.5rem;
            padding-bottom: 0.75rem;
            border-bottom: 2px solid #e9ecef;
        }
        
        .checkout-product-item {
            display: flex;
            gap: 1rem;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 8px;
            margin-bottom: 1rem;
            transition: all 0.3s;
        }
        
        .checkout-product-item:hover {
            background: #e9ecef;
        }
        
        .product-thumb {
            width: 80px;
            height: 80px;
            border-radius: 8px;
            overflow: hidden;
            flex-shrink: 0;
        }
        
        .product-thumb img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .product-details {
            flex: 1;
        }
        
        .product-name {
            font-size: 1rem;
            font-weight: 600;
            color: #212529;
            margin-bottom: 0.5rem;
        }
        
        .product-meta {
            font-size: 0.875rem;
            color: #6c757d;
            margin-bottom: 0.25rem;
        }
        
        .product-price-section {
            text-align: right;
        }
        
        .product-unit-price {
            font-size: 0.875rem;
            color: #6c757d;
            margin-bottom: 0.25rem;
        }
        
        .product-total-price {
            font-size: 1.125rem;
            font-weight: 700;
            color: #dc3545;
        }
        
        /* Form Section */
        .form-section {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            position: sticky;
            top: 20px;
        }
        
        .form-label {
            font-weight: 600;
            color: #212529;
            margin-bottom: 0.5rem;
        }
        
        .form-control, .form-select {
            border-radius: 8px;
            border: 1px solid #dee2e6;
            padding: 0.75rem 1rem;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #0d6efd;
            box-shadow: 0 0 0 0.25rem rgba(13,110,253,0.15);
        }
        
        /* Coupon Section */
        .coupon-box {
            background: linear-gradient(135deg, #fff3cd 0%, #fff9e6 100%);
            border: 2px dashed #ffc107;
            border-radius: 10px;
            padding: 1.25rem;
            margin-bottom: 1.5rem;
        }
        
        .coupon-box h5 {
            color: #856404;
            font-weight: 700;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .coupon-input-group {
            display: flex;
            gap: 0.5rem;
        }
        
        .coupon-input-group input {
            flex: 1;
            border-radius: 8px;
            border: 1px solid #ffc107;
        }
        
        .btn-apply-coupon {
            background: #ffc107;
            color: #212529;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-apply-coupon:hover {
            background: #ffb300;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255,193,7,0.4);
        }
        
        /* Order Summary */
        .summary-box {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 1.25rem;
            margin-bottom: 1.5rem;
        }
        
        .summary-title {
            font-size: 1.125rem;
            font-weight: 700;
            color: #212529;
            margin-bottom: 1rem;
        }
        
        .summary-line {
            display: flex;
            justify-content: space-between;
            padding: 0.75rem 0;
            border-bottom: 1px solid #dee2e6;
        }
        
        .summary-line:last-child {
            border-bottom: none;
        }
        
        .summary-discount {
            color: #198754;
            font-weight: 600;
        }
        
        .summary-total {
            display: flex;
            justify-content: space-between;
            padding: 1rem 0;
            border-top: 2px solid #dee2e6;
            margin-top: 0.5rem;
        }
        
        .summary-total-label {
            font-size: 1.25rem;
            font-weight: 700;
            color: #212529;
        }
        
        .summary-total-amount {
            font-size: 1.5rem;
            font-weight: 700;
            color: #dc3545;
        }
        
        /* Submit Button */
        .btn-checkout-submit {
            width: 100%;
            padding: 1rem;
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1.125rem;
            font-weight: 700;
            transition: all 0.3s;
            box-shadow: 0 4px 12px rgba(13,110,253,0.3);
        }
        
        .btn-checkout-submit:hover {
            background: linear-gradient(135deg, #0a58ca 0%, #084298 100%);
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(13,110,253,0.4);
        }
        
        /* Alerts */
        .alert-diamond {
            border-radius: 10px;
            padding: 1rem 1.25rem;
            margin-bottom: 1.5rem;
        }
        
        @media (max-width: 991px) {
            .form-section {
                position: static;
                margin-top: 2rem;
            }
        }
    </style>
</head>
<body>

<div class="checkout-container">
    <!-- Page Header -->
    <div class="page-header">
        <a href="/fashion-shop/public/cart/" class="btn-back mb-2 d-inline-block">← Quay lại giỏ hàng</a>
        <h1>🛒 Thanh toán</h1>
    </div>

    <!-- Alerts -->
    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger alert-diamond">
            <?php foreach ($errors as $error): ?>
                <p class="mb-0">❌ <?= htmlspecialchars($error) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success alert-diamond">
            <p class="mb-0">✅ <?= htmlspecialchars($success) ?></p>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- Left Column: Products -->
        <div class="col-lg-7">
            <div class="products-section">
                <h2 class="section-title">Sản phẩm trong giỏ</h2>
                
                <?php foreach ($cart_items as $item): ?>
                    <div class="checkout-product-item">
                        <div class="product-thumb">
                            <img src="<?= htmlspecialchars($item['image_url'] ?: '/fashion-shop/assets/images/no-image.jpg') ?>" 
                                 alt="<?= htmlspecialchars($item['product_name']) ?>">
                        </div>
                        <div class="product-details">
                            <div class="product-name"><?= htmlspecialchars($item['product_name']) ?></div>
                            <div class="product-meta">
                                Size: <strong><?= htmlspecialchars($item['size_name']) ?></strong> | 
                                Màu: <strong><?= htmlspecialchars($item['color_name']) ?></strong>
                            </div>
                            <div class="product-meta">Số lượng: <strong><?= $item['quantity'] ?></strong></div>
                            <div class="product-meta">
                                Đơn giá: <?= number_format($item['sale_price'] > 0 ? $item['sale_price'] : $item['base_price'], 0, ',', '.') ?>đ
                            </div>
                        </div>
                        <div class="product-price-section">
                            <div class="product-total-price"><?= number_format($item['subtotal'], 0, ',', '.') ?>đ</div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Right Column: Checkout Form -->
        <div class="col-lg-5">
            <div class="form-section">
                <h2 class="section-title">Thông tin giao hàng</h2>
                
                <form method="POST" action="process.php">
                    <div class="mb-3">
                        <label class="form-label">Họ tên người nhận *</label>
                        <input type="text" name="fullname" class="form-control" 
                               value="<?= htmlspecialchars($user['fullname']) ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Số điện thoại *</label>
                        <input type="tel" name="phone" class="form-control" 
                               value="<?= htmlspecialchars($user['phone']) ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Địa chỉ giao hàng *</label>
                        <textarea name="address" class="form-control" rows="3" required><?= htmlspecialchars($user['address']) ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Ghi chú (tùy chọn)</label>
                        <textarea name="note" class="form-control" rows="2" placeholder="Ví dụ: Giao giờ hành chính"></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Phương thức thanh toán *</label>
                        <select name="payment_method" class="form-select" required>
                            <option value="COD">Thanh toán khi nhận hàng (COD)</option>
                            <option value="Banking">Chuyển khoản ngân hàng</option>
                        </select>
                    </div>

                    <!-- Coupon Section -->
                    <div class="coupon-box">
                        <h5>🎁 Mã giảm giá</h5>
                        <form method="POST">
                            <div class="coupon-input-group">
                                <input type="text" name="coupon_code" class="form-control" 
                                       placeholder="Nhập mã giảm giá" 
                                       value="<?= $coupon ? htmlspecialchars($coupon['coupon_code']) : '' ?>">
                                <button type="submit" name="apply_coupon" class="btn-apply-coupon">Áp dụng</button>
                            </div>
                        </form>
                    </div>

                    <!-- Order Summary -->
                    <div class="summary-box">
                        <div class="summary-title">Tóm tắt đơn hàng</div>
                        
                        <div class="summary-line">
                            <span>Tạm tính:</span>
                            <strong><?= number_format($total_amount, 0, ',', '.') ?>đ</strong>
                        </div>
                        
                        <?php if ($coupon): ?>
                            <div class="summary-line summary-discount">
                                <span>Giảm giá (<?= htmlspecialchars($coupon['coupon_code']) ?>):</span>
                                <strong>-<?= number_format($discount_amount, 0, ',', '.') ?>đ</strong>
                            </div>
                        <?php endif; ?>
                        
                        <div class="summary-total">
                            <span class="summary-total-label">Tổng cộng:</span>
                            <span class="summary-total-amount"><?= number_format($final_amount, 0, ',', '.') ?>đ</span>
                        </div>
                    </div>

                    <!-- Hidden Fields -->
                    <input type="hidden" name="total_amount" value="<?= $total_amount ?>">
                    <input type="hidden" name="discount_amount" value="<?= $discount_amount ?>">
                    <input type="hidden" name="final_amount" value="<?= $final_amount ?>">
                    <?php if ($coupon): ?>
                        <input type="hidden" name="coupon_id" value="<?= $coupon['coupon_id'] ?>">
                    <?php endif; ?>

                    <button type="submit" name="checkout" class="btn-checkout-submit">
                        Đặt hàng
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>