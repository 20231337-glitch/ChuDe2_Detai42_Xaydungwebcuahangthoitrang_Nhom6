﻿/**
 * Modern Cart System - AJAX Implementation (FIXED)
 * Sử dụng Fetch API để xử lý giỏ hàng không reload trang
 */

console.log('🛒 Cart.js loaded successfully!');

// ============================================================================
// TOAST NOTIFICATION SYSTEM
// ============================================================================
const Toast = {
    show: function(message, type = 'success') {
        console.log('Toast:', type, message);
        
        // Xóa toast cũ nếu có
        const existingToast = document.querySelector('.toast-notification');
        if (existingToast) existingToast.remove();
        
        // Tạo toast mới
        const toast = document.createElement('div');
        toast.className = `toast-notification toast-${type}`;
        
        // Icon dựa trên type
        const icons = {
            success: '<i class="fas fa-check-circle"></i>',
            error: '<i class="fas fa-exclamation-circle"></i>',
            warning: '<i class="fas fa-exclamation-triangle"></i>',
            info: '<i class="fas fa-info-circle"></i>'
        };
        
        toast.innerHTML = `
            <div class="toast-content">
                ${icons[type] || icons.info}
                <span>${message}</span>
            </div>
        `;
        
        document.body.appendChild(toast);
        
        // Animation: Slide in
        setTimeout(() => toast.classList.add('show'), 100);
        
        // Auto hide after 3.5s
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3500);
    }
};

// ============================================================================
// CART FUNCTIONS
// ============================================================================

/**
 * Thêm sản phẩm vào giỏ hàng (AJAX)
 */
window.addToCart = function() {
    console.log('🛒 addToCart() called');
    
    // Lấy thông tin từ URL và form
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id');
    const sizeElement = document.querySelector('input[name="size"]:checked');
    const colorElement = document.querySelector('input[name="color"]:checked');
    const quantityElement = document.getElementById('quantity');
    
    console.log('Product ID:', productId);
    console.log('Size element:', sizeElement);
    console.log('Color element:', colorElement);
    console.log('Quantity element:', quantityElement);
    
    // Validate
    if (!productId) {
        Toast.show('Không tìm thấy sản phẩm!', 'error');
        return;
    }
    
    if (!sizeElement) {
        Toast.show('Vui lòng chọn size!', 'warning');
        return;
    }
    
    if (!colorElement) {
        Toast.show('Vui lòng chọn màu!', 'warning');
        return;
    }
    
    const sizeId = sizeElement.value;
    const colorId = colorElement.value;
    const quantity = quantityElement ? parseInt(quantityElement.value) : 1;
    
    console.log('Data to send:', { productId, sizeId, colorId, quantity });
    
    // Lấy button đang click (từ event nếu có)
    const btn = event ? event.target.closest('button') : document.querySelector('.btn-primary.btn-lg');
    const originalHTML = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang thêm...';
    
    // Tạo FormData
    const formData = new FormData();
    formData.append('product_id', productId);
    formData.append('size_id', sizeId);
    formData.append('color_id', colorId);
    formData.append('quantity', quantity);
    
    // Gửi AJAX request
    fetch('/fashion-shop/public/cart/add.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        console.log('Response status:', response.status);
        return response.json();
    })
    .then(data => {
        console.log('Response data:', data);
        
        // Reset button
        btn.disabled = false;
        btn.innerHTML = originalHTML;
        
        if (data.success) {
            // Hiển thị thông báo thành công
            Toast.show(data.message || 'Đã thêm vào giỏ hàng! 🎉', 'success');
            
            // Cập nhật số lượng giỏ hàng
            if (data.cart_count !== undefined) {
                updateCartCount(data.cart_count);
            }
            
            // Animation: Fly to cart
            flyToCart(btn);
        } else {
            // Hiển thị lỗi
            Toast.show(data.message || 'Có lỗi xảy ra!', 'error');
            
            // Nếu cần redirect (chưa login)
            if (data.redirect) {
                setTimeout(() => {
                    window.location.href = data.redirect;
                }, 1500);
            }
        }
    })
    .catch(error => {
        console.error('Fetch error:', error);
        btn.disabled = false;
        btn.innerHTML = originalHTML;
        Toast.show('Có lỗi xảy ra, vui lòng thử lại!', 'error');
    });
};

/**
 * Mua ngay (thêm vào giỏ + chuyển đến trang thanh toán)
 */
window.buyNow = function() {
    console.log('⚡ buyNow() called');
    
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id');
    const sizeElement = document.querySelector('input[name="size"]:checked');
    const colorElement = document.querySelector('input[name="color"]:checked');
    const quantityElement = document.getElementById('quantity');
    
    // Validate
    if (!productId) {
        Toast.show('Không tìm thấy sản phẩm!', 'error');
        return;
    }
    
    if (!sizeElement) {
        Toast.show('Vui lòng chọn size!', 'warning');
        return;
    }
    
    if (!colorElement) {
        Toast.show('Vui lòng chọn màu!', 'warning');
        return;
    }
    
    const sizeId = sizeElement.value;
    const colorId = colorElement.value;
    const quantity = quantityElement ? parseInt(quantityElement.value) : 1;
    
    // Lấy button
    const btn = event ? event.target.closest('button') : document.querySelector('.btn-secondary.btn-lg');
    const originalHTML = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang xử lý...';
    
    // Tạo FormData
    const formData = new FormData();
    formData.append('product_id', productId);
    formData.append('size_id', sizeId);
    formData.append('color_id', colorId);
    formData.append('quantity', quantity);
    
    // Gửi AJAX request
    fetch('/fashion-shop/public/cart/add.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Toast.show('Đang chuyển đến trang thanh toán...', 'success');
            setTimeout(() => {
                window.location.href = '/fashion-shop/public/checkout/';
            }, 1000);
        } else {
            btn.disabled = false;
            btn.innerHTML = originalHTML;
            Toast.show(data.message || 'Có lỗi xảy ra!', 'error');
            
            if (data.redirect) {
                setTimeout(() => {
                    window.location.href = data.redirect;
                }, 1500);
            }
        }
    })
    .catch(error => {
        console.error('Error:', error);
        btn.disabled = false;
        btn.innerHTML = originalHTML;
        Toast.show('Có lỗi xảy ra, vui lòng thử lại!', 'error');
    });
};

/**
 * Cập nhật số lượng giỏ hàng trên header
 */
function updateCartCount(count) {
    console.log('Updating cart count to:', count);
    const cartBadge = document.querySelector('.cart-badge');
    if (cartBadge) {
        cartBadge.textContent = count;
        cartBadge.classList.add('pulse');
        setTimeout(() => cartBadge.classList.remove('pulse'), 600);
    } else {
        console.warn('Cart badge not found in header');
    }
}

/**
 * Animation: Bay vào giỏ hàng
 */
function flyToCart(button) {
    const cart = document.querySelector('.navbar-icons a[href*="cart"]');
    if (!cart || !button) return;
    
    const btnRect = button.getBoundingClientRect();
    const cartRect = cart.getBoundingClientRect();
    
    const clone = document.createElement('div');
    clone.className = 'fly-to-cart';
    clone.innerHTML = '<i class="fas fa-shopping-cart"></i>';
    clone.style.left = btnRect.left + 'px';
    clone.style.top = btnRect.top + 'px';
    
    document.body.appendChild(clone);
    
    setTimeout(() => {
        clone.style.left = cartRect.left + 'px';
        clone.style.top = cartRect.top + 'px';
        clone.style.opacity = '0';
        clone.style.transform = 'scale(0.3)';
    }, 100);
    
    setTimeout(() => clone.remove(), 800);
}

/**
 * Giảm số lượng
 */
window.decreaseQty = function() {
    const input = document.getElementById('quantity');
    if (input && input.value > 1) {
        input.value = parseInt(input.value) - 1;
    }
};

/**
 * Tăng số lượng
 */
window.increaseQty = function() {
    const input = document.getElementById('quantity');
    if (input) {
        input.value = parseInt(input.value) + 1;
    }
};

/**
 * Thay đổi hình ảnh chính
 */
window.changeMainImage = function(url, element) {
    const mainImage = document.getElementById('mainImage');
    if (mainImage) {
        mainImage.src = url;
        document.querySelectorAll('.thumbnail').forEach(t => t.classList.remove('active'));
        if (element) element.classList.add('active');
    }
};

// ============================================================================
// INIT
// ============================================================================
document.addEventListener('DOMContentLoaded', function() {
    console.log('✅ Cart system initialized');
});