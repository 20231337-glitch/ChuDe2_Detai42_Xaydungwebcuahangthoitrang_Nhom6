<?php
/**
 * File chứa các hàm phân trang
 */

/**
 * Tính tổng số trang
 * @param int $totalRecords Tổng số bản ghi
 * @param int $perPage Số bản ghi trên 1 trang
 * @return int Tổng số trang
 */
function getTotalPages($totalRecords, $perPage) {
    return ceil($totalRecords / $perPage);
}

/**
 * Render HTML phân trang
 * @param int $currentPage Trang hiện tại
 * @param int $totalPages Tổng số trang
 * @param string $baseUrl URL cơ sở (có thể chứa query string)
 * @return string HTML phân trang
 */
function renderPagination($currentPage, $totalPages, $baseUrl = '?') {
    if ($totalPages <= 1) {
        return '';
    }
    
    $html = '<div class="pagination">';
    
    // Nút Previous
    if ($currentPage > 1) {
        $prevPage = $currentPage - 1;
        $separator = (strpos($baseUrl, '?') !== false) ? '&' : '?';
        $html .= '<a href="' . $baseUrl . $separator . 'page=' . $prevPage . '" class="page-link">&laquo; Trước</a>';
    }
    
    // Hiển thị các số trang
    $start = max(1, $currentPage - 2);
    $end = min($totalPages, $currentPage + 2);
    
    // Nút trang đầu
    if ($start > 1) {
        $separator = (strpos($baseUrl, '?') !== false) ? '&' : '?';
        $html .= '<a href="' . $baseUrl . $separator . 'page=1" class="page-link">1</a>';
        if ($start > 2) {
            $html .= '<span class="page-dots">...</span>';
        }
    }
    
    // Các trang ở giữa
    for ($i = $start; $i <= $end; $i++) {
        $separator = (strpos($baseUrl, '?') !== false) ? '&' : '?';
        if ($i == $currentPage) {
            $html .= '<span class="page-link active">' . $i . '</span>';
        } else {
            $html .= '<a href="' . $baseUrl . $separator . 'page=' . $i . '" class="page-link">' . $i . '</a>';
        }
    }
    
    // Nút trang cuối
    if ($end < $totalPages) {
        if ($end < $totalPages - 1) {
            $html .= '<span class="page-dots">...</span>';
        }
        $separator = (strpos($baseUrl, '?') !== false) ? '&' : '?';
        $html .= '<a href="' . $baseUrl . $separator . 'page=' . $totalPages . '" class="page-link">' . $totalPages . '</a>';
    }
    
    // Nút Next
    if ($currentPage < $totalPages) {
        $nextPage = $currentPage + 1;
        $separator = (strpos($baseUrl, '?') !== false) ? '&' : '?';
        $html .= '<a href="' . $baseUrl . $separator . 'page=' . $nextPage . '" class="page-link">Sau &raquo;</a>';
    }
    
    $html .= '</div>';
    
    return $html;
}
?>
