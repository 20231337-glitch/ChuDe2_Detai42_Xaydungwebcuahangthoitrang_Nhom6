<?php
/**
 * File chứa các hàm tiện ích dùng chung
 */

/**
 * Lấy giá trị từ $_GET với giá trị mặc định
 * @param string $key Tên tham số
 * @param mixed $default Giá trị mặc định
 * @return mixed
 */
function get($key, $default = null) {
    return isset($_GET[$key]) ? $_GET[$key] : $default;
}

/**
 * Lấy giá trị từ $_POST với giá trị mặc định
 * @param string $key Tên tham số
 * @param mixed $default Giá trị mặc định
 * @return mixed
 */
function post($key, $default = null) {
    return isset($_POST[$key]) ? $_POST[$key] : $default;
}

/**
 * Redirect đến URL khác
 * @param string $url URL đích
 */
function redirect($url) {
    header('Location: ' . $url);
    exit;
}

/**
 * Kiểm tra user đã đăng nhập chưa (snake_case)
 */
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

/**
 * Kiểm tra user đã đăng nhập chưa (camelCase - alias)
 */
function isLoggedIn() {
    return is_logged_in();
}

/**
 * Kiểm tra user có phải admin không
 */
function is_admin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

/**
 * Kiểm tra user có phải admin không (camelCase - alias)
 */
function isAdmin() {
    return is_admin();
}

/**
 * Kiểm tra user có phải customer không
 */
function is_customer() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'customer';
}

/**
 * Kiểm tra user có phải customer không (camelCase - alias)
 */
function isCustomer() {
    return is_customer();
}

/**
 * Redirect nếu chưa đăng nhập
 */
function require_login($redirect_url = '/admin/auth/login.php') {
    if (!is_logged_in()) {
        header('Location: ' . $redirect_url);
        exit;
    }
}

/**
 * Redirect nếu không phải admin
 */
function require_admin() {
    if (!is_admin()) {
        header('Location: /admin/auth/login.php');
        exit;
    }
}

/**
 * Redirect nếu không phải customer
 */
function require_customer() {
    if (!is_customer()) {
        header('Location: /public/auth/login.php');
        exit;
    }
}

/**
 * Escape output để tránh XSS
 */
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

/**
 * Format tiền tệ VND (snake_case)
 */
function format_money($amount) {
    return number_format($amount, 0, ',', '.') . 'đ';
}

/**
 * Format tiền tệ VND (camelCase - alias)
 */
function formatMoney($amount) {
    return format_money($amount);
}

/**
 * Tạo slug từ chuỗi tiếng Việt
 */
function create_slug($str) {
    $str = trim(mb_strtolower($str));
    $str = preg_replace('/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/', 'a', $str);
    $str = preg_replace('/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/', 'e', $str);
    $str = preg_replace('/(ì|í|ị|ỉ|ĩ)/', 'i', $str);
    $str = preg_replace('/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/', 'o', $str);
    $str = preg_replace('/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/', 'u', $str);
    $str = preg_replace('/(ỳ|ý|ỵ|ỷ|ỹ)/', 'y', $str);
    $str = preg_replace('/(đ)/', 'd', $str);
    $str = preg_replace('/[^a-z0-9-\s]/', '', $str);
    $str = preg_replace('/([\s]+)/', '-', $str);
    return $str;
}

/**
 * Hiển thị thông báo flash message
 */
function set_flash($key, $message) {
    $_SESSION['flash'][$key] = $message;
}

function get_flash($key) {
    if (isset($_SESSION['flash'][$key])) {
        $message = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $message;
    }
    return null;
}

/**
 * Redirect với thông báo
 */
function redirect_with_message($url, $message, $type = 'success') {
    set_flash($type, $message);
    header('Location: ' . $url);
    exit;
}

/**
 * Lấy URL gốc của website
 */
function base_url($path = '') {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
    $host = $_SERVER['HTTP_HOST'];
    $base = $protocol . $host;
    return $path ? $base . '/' . ltrim($path, '/') : $base;
}

/**
 * Lấy URL hiện tại
 */
function current_url() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
    return $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
}

/**
 * Debug - In ra biến và dừng chương trình
 */
function dd($var) {
    echo '<pre style="background: #000; color: #0f0; padding: 20px; border-radius: 5px;">';
    var_dump($var);
    echo '</pre>';
    die();
}

/**
 * Kiểm tra request là AJAX không
 */
function is_ajax() {
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
}

/**
 * Trả về JSON response
 */
function json_response($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Validate email
 */
function is_valid_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Validate số điện thoại Việt Nam
 */
function is_valid_phone($phone) {
    // Format: 0xxxxxxxxx (10-11 số)
    return preg_match('/^0[0-9]{9,10}$/', $phone);
}

/**
 * Sanitize string - loại bỏ ký tự đặc biệt
 */
function sanitize($string) {
    return htmlspecialchars(strip_tags(trim($string)), ENT_QUOTES, 'UTF-8');
}

/**
 * Truncate string với suffix
 */
function str_limit($string, $limit = 100, $suffix = '...') {
    if (mb_strlen($string) <= $limit) {
        return $string;
    }
    return mb_substr($string, 0, $limit) . $suffix;
}
?>
