<?php
/**
 * UPLOAD HELPER
 * Hàm hỗ trợ upload và xử lý ảnh
 */

/**
 * Upload ảnh sản phẩm
 * 
 * @param array $file File từ $_FILES
 * @param string $target_dir Thư mục đích (vd: 'products', 'reviews')
 * @param int $max_size Kích thước tối đa (bytes)
 * @return array ['success' => bool, 'path' => string, 'error' => string]
 */
function upload_image($file, $target_dir = 'products', $max_size = 5242880) {
    // Kiểm tra file có được upload không
    if (!isset($file) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return ['success' => false, 'error' => 'Không có file được chọn'];
    }
    
    // Kiểm tra lỗi upload
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'error' => 'Lỗi upload file: ' . $file['error']];
    }
    
    // Kiểm tra kích thước
    if ($file['size'] > $max_size) {
        return ['success' => false, 'error' => 'File quá lớn. Tối đa ' . ($max_size / 1024 / 1024) . 'MB'];
    }
    
    // Kiểm tra định dạng
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mime_type, $allowed_types)) {
        return ['success' => false, 'error' => 'Chỉ chấp nhận file ảnh (JPG, PNG, GIF, WEBP)'];
    }
    
    // Tạo tên file unique
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $filename = time() . '_' . uniqid() . '.' . $extension;
    
    // Đường dẫn đầy đủ
    $upload_dir = __DIR__ . '/../uploads/' . $target_dir . '/';
    
    // Tạo thư mục nếu chưa tồn tại
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    $target_path = $upload_dir . $filename;
    
    // Resize ảnh nếu quá lớn
    $resized = resize_image($file['tmp_name'], $target_path, 1200, 1200);
    
    if (!$resized) {
        // Nếu không resize được thì move file gốc
        if (!move_uploaded_file($file['tmp_name'], $target_path)) {
            return ['success' => false, 'error' => 'Không thể lưu file'];
        }
    }
    
    // Trả về đường dẫn tương đối
    $relative_path = '/fashion-shop/uploads/' . $target_dir . '/' . $filename;
    
    return ['success' => true, 'path' => $relative_path, 'error' => ''];
}

/**
 * Resize ảnh giữ tỷ lệ
 * 
 * @param string $source Đường dẫn file nguồn
 * @param string $destination Đường dẫn file đích
 * @param int $max_width Chiều rộng tối đa
 * @param int $max_height Chiều cao tối đa
 * @return bool
 */
function resize_image($source, $destination, $max_width = 1200, $max_height = 1200) {
    // Lấy thông tin ảnh
    $image_info = getimagesize($source);
    if (!$image_info) {
        return false;
    }
    
    list($width, $height, $type) = $image_info;
    
    // Nếu ảnh nhỏ hơn max thì không cần resize
    if ($width <= $max_width && $height <= $max_height) {
        return copy($source, $destination);
    }
    
    // Tính tỷ lệ
    $ratio = min($max_width / $width, $max_height / $height);
    $new_width = round($width * $ratio);
    $new_height = round($height * $ratio);
    
    // Tạo image resource từ file nguồn
    switch ($type) {
        case IMAGETYPE_JPEG:
            $source_image = imagecreatefromjpeg($source);
            break;
        case IMAGETYPE_PNG:
            $source_image = imagecreatefrompng($source);
            break;
        case IMAGETYPE_GIF:
            $source_image = imagecreatefromgif($source);
            break;
        case IMAGETYPE_WEBP:
            $source_image = imagecreatefromwebp($source);
            break;
        default:
            return false;
    }
    
    if (!$source_image) {
        return false;
    }
    
    // Tạo canvas mới
    $new_image = imagecreatetruecolor($new_width, $new_height);
    
    // Giữ trong suốt cho PNG và GIF
    if ($type == IMAGETYPE_PNG || $type == IMAGETYPE_GIF) {
        imagealphablending($new_image, false);
        imagesavealpha($new_image, true);
        $transparent = imagecolorallocatealpha($new_image, 255, 255, 255, 127);
        imagefilledrectangle($new_image, 0, 0, $new_width, $new_height, $transparent);
    }
    
    // Resize
    imagecopyresampled($new_image, $source_image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
    
    // Lưu file
    $success = false;
    switch ($type) {
        case IMAGETYPE_JPEG:
            $success = imagejpeg($new_image, $destination, 90);
            break;
        case IMAGETYPE_PNG:
            $success = imagepng($new_image, $destination, 9);
            break;
        case IMAGETYPE_GIF:
            $success = imagegif($new_image, $destination);
            break;
        case IMAGETYPE_WEBP:
            $success = imagewebp($new_image, $destination, 90);
            break;
    }
    
    // Giải phóng bộ nhớ
    imagedestroy($source_image);
    imagedestroy($new_image);
    
    return $success;
}

/**
 * Xóa ảnh
 */
function delete_image($path) {
    if (empty($path)) {
        return true;
    }
    
    $full_path = __DIR__ . '/../' . ltrim($path, '/');
    
    if (file_exists($full_path)) {
        return unlink($full_path);
    }
    
    return true;
}
?>
