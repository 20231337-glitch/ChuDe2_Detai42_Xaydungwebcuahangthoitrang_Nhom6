<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

// Kiểm tra quyền admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

$admin_name = $_SESSION['fullname'];

// ===== 1. THỐNG KÊ TỔNG QUAN =====

// 1.1 Tổng doanh thu
$sql_revenue = "SELECT SUM(final_amount) as total_revenue
               FROM orders
               WHERE order_status IN ('completed', 'shipping')
               AND payment_status = 'paid'";
$result_revenue = mysqli_query($conn, $sql_revenue);
$total_revenue = mysqli_fetch_assoc($result_revenue)['total_revenue'] ?? 0;

// 1.2 Tổng đơn hàng
$sql_total_orders = "SELECT COUNT(*) as total FROM orders";
$result_total_orders = mysqli_query($conn, $sql_total_orders);
$total_orders = mysqli_fetch_assoc($result_total_orders)['total'] ?? 0;

// 1.3 Tổng khách hàng
$sql_total_customers = "SELECT COUNT(*) as total FROM users WHERE role = 'customer' AND deleted_at IS NULL";
$result_total_customers = mysqli_query($conn, $sql_total_customers);
$total_customers = mysqli_fetch_assoc($result_total_customers)['total'] ?? 0;

// 1.4 Tổng sản phẩm
$sql_total_products = "SELECT COUNT(*) as total FROM products WHERE deleted_at IS NULL";
$result_total_products = mysqli_query($conn, $sql_total_products);
$total_products = mysqli_fetch_assoc($result_total_products)['total'] ?? 0;

// 1.5 Khách hàng mới trong tháng
$sql_new_customers = "SELECT COUNT(*) as new_customers
                      FROM users
                      WHERE role = 'customer'
                      AND created_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)";
$result_new_customers = mysqli_query($conn, $sql_new_customers);
$new_customers = mysqli_fetch_assoc($result_new_customers)['new_customers'] ?? 0;

// ===== 2. THỐNG KÊ ĐƠN HÀNG THEO TRẠNG THÁI =====
$sql_orders_status = "SELECT 
                          order_status,
                          COUNT(*) as total_orders,
                          SUM(final_amount) as total_amount
                      FROM orders
                      GROUP BY order_status";
$result_orders_status = mysqli_query($conn, $sql_orders_status);
$orders_by_status = [];
while($row = mysqli_fetch_assoc($result_orders_status)) {
    $orders_by_status[$row['order_status']] = $row;
}

// ===== 3. TOP 10 SẢN PHẨM BÁN CHẠY =====
$sql_top_products = "SELECT p.product_id, p.product_name, p.sold_count, p.base_price, pi.image_url
                     FROM products p
                     LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
                     WHERE p.deleted_at IS NULL
                     ORDER BY p.sold_count DESC
                     LIMIT 10";
$result_top_products = mysqli_query($conn, $sql_top_products);

// ===== 4. DOANH THU THEO THÁNG (12 THÁNG GẦN NHẤT) =====
$sql_revenue_monthly = "SELECT 
                            DATE_FORMAT(order_date, '%Y-%m') as month,
                            COUNT(*) as total_orders,
                            SUM(final_amount) as revenue
                        FROM orders
                        WHERE order_status IN ('completed', 'shipping')
                        AND order_date >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
                        GROUP BY DATE_FORMAT(order_date, '%Y-%m')
                        ORDER BY month";
$result_revenue_monthly = mysqli_query($conn, $sql_revenue_monthly);
$monthly_data = [];
while($row = mysqli_fetch_assoc($result_revenue_monthly)) {
    $monthly_data[] = $row;
}

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Fashion Shop</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; }
        
        /* Header */
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header h1 { font-size: 28px; margin-bottom: 5px; }
        .header p { opacity: 0.9; }
        .header a { color: white; text-decoration: underline; }
        
        /* Container */
        .container { max-width: 1400px; margin: 30px auto; padding: 0 20px; }
        
        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            border-left: 4px solid #667eea;
        }
        .stat-card h3 { font-size: 14px; color: #666; margin-bottom: 10px; text-transform: uppercase; }
        .stat-card .value { font-size: 32px; font-weight: bold; color: #333; }
        .stat-card .sub { font-size: 13px; color: #999; margin-top: 8px; }
        
        /* Cards */
        .card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 25px;
        }
        .card h2 {
            font-size: 20px;
            margin-bottom: 20px;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }
        
        /* Table */
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f8f9fa; font-weight: 600; color: #555; }
        tr:hover { background: #f8f9fa; }
        img.product-thumb { width: 50px; height: 50px; object-fit: cover; border-radius: 6px; }
        
        /* Order Status */
        .status-list { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; }
        .status-item {
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
            border-left: 4px solid #667eea;
        }
        .status-item .label { font-size: 13px; color: #666; margin-bottom: 5px; }
        .status-item .count { font-size: 24px; font-weight: bold; color: #333; }
        .status-item .amount { font-size: 13px; color: #999; margin-top: 5px; }
        
        /* Chart placeholder */
        .chart-container {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            color: #666;
            min-height: 200px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .btn-primary {
            display: inline-block;
            padding: 10px 20px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            margin-top: 15px;
            margin-right: 10px;
            transition: background 0.3s;
        }
        .btn-primary:hover { background: #5568d3; }
    </style>
</head>
<body>
    <div class="header">
        <h1>📊 Dashboard Admin</h1>
        <p>Xin chào, <?= htmlspecialchars($admin_name) ?> | <a href="../auth/logout.php">Đăng xuất</a></p>
    </div>

    <div class="container">
        <!-- Thống kê tổng quan -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3>💰 Tổng Doanh Thu</h3>
                <div class="value"><?= number_format($total_revenue, 0, ',', '.') ?>đ</div>
                <div class="sub">Từ đơn hàng đã hoàn thành</div>
            </div>
            
            <div class="stat-card">
                <h3>📦 Tổng Đơn Hàng</h3>
                <div class="value"><?= number_format($total_orders) ?></div>
                <div class="sub">Tất cả các trạng thái</div>
            </div>
            
            <div class="stat-card">
                <h3>👥 Khách Hàng</h3>
                <div class="value"><?= number_format($total_customers) ?></div>
                <div class="sub">+<?= $new_customers ?> mới trong tháng</div>
            </div>
            
            <div class="stat-card">
                <h3>🎁 Sản Phẩm</h3>
                <div class="value"><?= number_format($total_products) ?></div>
                <div class="sub">Đang hoạt động</div>
            </div>
        </div>

        <!-- Đơn hàng theo trạng thái -->
        <div class="card">
            <h2>📈 Đơn Hàng Theo Trạng Thái</h2>
            <div class="status-list">
                <?php
                $status_labels = [
                    'processing' => '⏳ Đang xử lý',
                    'confirmed' => '✅ Đã xác nhận',
                    'shipping' => '🚚 Đang giao',
                    'completed' => '✔️ Hoàn thành',
                    'cancelled' => '❌ Đã hủy'
                ];
                
                foreach($status_labels as $status => $label):
                    $data = $orders_by_status[$status] ?? ['total_orders' => 0, 'total_amount' => 0];
                ?>
                <div class="status-item">
                    <div class="label"><?= $label ?></div>
                    <div class="count"><?= number_format($data['total_orders']) ?></div>
                    <div class="amount"><?= number_format($data['total_amount'], 0, ',', '.') ?>đ</div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Top sản phẩm bán chạy -->
        <div class="card">
            <h2>🔥 Top 10 Sản Phẩm Bán Chạy</h2>
            <table>
                <thead>
                    <tr>
                        <th>Hình ảnh</th>
                        <th>Tên sản phẩm</th>
                        <th>Giá gốc</th>
                        <th>Đã bán</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($product = mysqli_fetch_assoc($result_top_products)): ?>
                    <tr>
                        <td>
                            <?php if($product['image_url']): ?>
                                <img src="../../<?= htmlspecialchars($product['image_url']) ?>" 
                                     alt="" class="product-thumb">
                            <?php else: ?>
                                <div style="width:50px;height:50px;background:#ddd;border-radius:6px;"></div>
                            <?php endif; ?>
                        </td>
                        <td><strong><?= htmlspecialchars($product['product_name']) ?></strong></td>
                        <td><?= number_format($product['base_price'], 0, ',', '.') ?>đ</td>
                        <td><strong><?= number_format($product['sold_count']) ?></strong> sản phẩm</td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <!-- Doanh thu theo tháng -->
        <div class="card">
            <h2>📊 Doanh Thu 12 Tháng Gần Nhất</h2>
            <div class="chart-container">
                <div>
                    <p><strong>Biểu đồ sẽ được thêm vào với Chart.js (Giai đoạn 19)</strong></p>
                    <p style="margin-top:10px;">Dữ liệu đã sẵn sàng:</p>
                    <pre style="text-align: left; background: white; padding: 15px; border-radius: 6px; margin-top: 10px;">
<?php
foreach($monthly_data as $month):
    echo sprintf("Tháng %s: %s đơn - %s đ\n", 
                 $month['month'], 
                 number_format($month['total_orders']),
                 number_format($month['revenue'], 0, ',', '.'));
endforeach;
?>
                    </pre>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="card">
            <h2>⚡ Thao Tác Nhanh</h2>
            <a href="../products/" class="btn-primary">+ Thêm Sản Phẩm Mới</a>
            <a href="../orders/" class="btn-primary">📦 Quản Lý Đơn Hàng</a>
            <a href="../coupons/" class="btn-primary">🎟️ Tạo Mã Giảm Giá</a>
            <a href="../customers/" class="btn-primary">👥 Xem Khách Hàng</a>
        </div>
    </div>
</body>
</html>
