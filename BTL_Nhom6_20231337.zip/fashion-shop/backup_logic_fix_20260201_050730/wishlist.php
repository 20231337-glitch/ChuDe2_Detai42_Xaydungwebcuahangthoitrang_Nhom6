<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {
    header('Location: ../auth/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Xử lý xóa sản phẩm khỏi wishlist
if (isset($_GET['action']) && $_GET['action'] == 'remove' && isset($_GET['id'])) {
    $wishlist_id = intval($_GET['id']);
    $delete_sql = "DELETE FROM wishlists WHERE wishlist_id = ? AND user_id = ?";
    $delete_stmt = $conn->prepare($delete_sql);
    $delete_stmt->bind_param("ii", $wishlist_id, $user_id);
    $delete_stmt->execute();
    $delete_stmt->close();
    header('Location: wishlist.php?msg=removed');
    exit;
}

// Lấy danh sách sản phẩm yêu thích
$sql = "SELECT 
            w.wishlist_id,
            w.added_at,
            p.product_id,
            p.product_name,
            p.slug,
            p.base_price,
            p.base_price,
            p.status,
            pi.image_url,
            (SELECT COUNT(*) FROM product_variants pv WHERE pv.product_id = p.product_id AND pv.stock_quantity > 0) as available_variants
        FROM wishlists w
        INNER JOIN products p ON w.product_id = p.product_id
        LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
        WHERE w.user_id = ? AND p.deleted_at IS NULL
        ORDER BY w.added_at DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$wishlist_items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sản phẩm yêu thích - Fashion Shop</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; padding: 30px 20px; }
        h1 { color: #333; margin-bottom: 10px; text-align: center; }
        .subtitle { text-align: center; color: #666; margin-bottom: 30px; }
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 500;
        }
        .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .wishlist-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
        }
        .product-card {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            transition: transform 0.2s;
        }
        .product-card:hover { transform: translateY(-5px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
        .product-image {
            width: 100%;
            height: 250px;
            object-fit: cover;
            background: #f0f0f0;
        }
        .product-info { padding: 15px; }
        .product-name {
            font-size: 16px;
            font-weight: 600;
            color: #333;
            margin-bottom: 10px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        .product-price {
            font-size: 18px;
            font-weight: 700;
            color: #e74c3c;
            margin-bottom: 10px;
        }
        .old-price {
            font-size: 14px;
            color: #999;
            text-decoration: line-through;
            margin-left: 8px;
        }
        .product-status {
            font-size: 13px;
            color: #666;
            margin-bottom: 15px;
        }
        .product-actions {
            display: flex;
            gap: 10px;
        }
        .btn {
            flex: 1;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            text-align: center;
            transition: all 0.3s;
        }
        .btn-primary {
            background: #4CAF50;
            color: white;
        }
        .btn-primary:hover { background: #45a049; }
        .btn-danger {
            background: #dc3545;
            color: white;
        }
        .btn-danger:hover { background: #c82333; }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .empty-state h2 {
            color: #666;
            margin-bottom: 20px;
        }
        .btn-back {
            background: #6c757d;
            color: white;
            padding: 12px 30px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 600;
            display: inline-block;
            margin-top: 20px;
        }
        .btn-back:hover { background: #5a6268; }
        .added-date {
            font-size: 12px;
            color: #999;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Sản phẩm yêu thích</h1>
        <p class="subtitle">Danh sách các sản phẩm bạn đã lưu</p>
        
        <?php if (isset($_GET['msg']) && $_GET['msg'] == 'removed'): ?>
            <div class="alert alert-success">✅ Đã xóa sản phẩm khỏi danh sách yêu thích!</div>
        <?php endif; ?>
        
        <?php if (empty($wishlist_items)): ?>
            <div class="empty-state">
                <h2>💔 Chưa có sản phẩm yêu thích</h2>
                <p>Hãy thêm các sản phẩm bạn thích vào danh sách này để tiện theo dõi!</p>
                <a href="../products/" class="btn-back">🛍️ Khám phá sản phẩm</a>
            </div>
        <?php else: ?>
            <div class="wishlist-grid">
                <?php foreach ($wishlist_items as $item): ?>
                    <?php
                    $display_price = $item['base_price'] > 0 ? $item['base_price'] : $item['base_price'];
                    $has_sale = $item['base_price'] > 0 && $item['base_price'] < $item['base_price'];
                    $in_stock = $item['available_variants'] > 0;
                    ?>
                    <div class="product-card">
                        <img src="<?= htmlspecialchars($item['image_url'] ?? '/assets/images/no-image.jpg') ?>" 
                             alt="<?= htmlspecialchars($item['product_name']) ?>" 
                             class="product-image">
                        
                        <div class="product-info">
                            <div class="product-name"><?= htmlspecialchars($item['product_name']) ?></div>
                            
                            <div class="product-price">
                                <?= number_format($display_price, 0, ',', '.') ?>đ
                                <?php if ($has_sale): ?>
                                    <span class="old-price"><?= number_format($item['base_price'], 0, ',', '.') ?>đ</span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="product-status">
                                <?php if ($in_stock): ?>
                                    ✅ Còn hàng (<?= $item['available_variants'] ?> phiên bản)
                                <?php else: ?>
                                    ⚠️ Hết hàng
                                <?php endif; ?>
                            </div>
                            
                            <div class="added-date">
                                Đã lưu: <?= date('d/m/Y', strtotime($item['added_at'])) ?>
                            </div>
                            
                            <div class="product-actions">
                                <a href="../products/detail.php?slug=<?= htmlspecialchars($item['slug']) ?>" 
                                   class="btn btn-primary">Xem chi tiết</a>
                                <a href="?action=remove&id=<?= $item['wishlist_id'] ?>" 
                                   class="btn btn-danger"
                                   onclick="return confirm('Bạn có chắc muốn xóa sản phẩm này?')">Xóa</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div style="text-align: center; margin-top: 30px;">
                <a href="orders.php" class="btn-back">🔙 Quay lại</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
