<?php
/**
 * Quản lý session
 */

// Khởi tạo session nếu chưa có
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Hàm kiểm tra đã đăng nhập chưa
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

// Hàm kiểm tra quyền admin
function is_admin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Hàm kiểm tra quyền customer
function is_customer() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'customer';
}

// Hàm redirect nếu chưa đăng nhập
function require_login() {
    if (!is_logged_in()) {
        header('Location: /fashion-shop/public/auth/login.php');
        exit;
    }
}

// Hàm redirect nếu không phải admin
function require_admin() {
    if (!is_admin()) {
        header('Location: /fashion-shop/admin/auth/login.php');
        exit;
    }
}
?>
