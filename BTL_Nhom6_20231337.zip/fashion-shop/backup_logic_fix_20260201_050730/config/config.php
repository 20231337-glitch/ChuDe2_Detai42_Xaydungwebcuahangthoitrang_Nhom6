<?php
/**
 * File cấu hình chung - Fashion Shop
 * Chỉ chứa constants, KHÔNG có functions
 */

// Bật hiển thị lỗi (development mode)
error_reporting(E_ALL & ~E_DEPRECATED & ~E_WARNING);
ini_set('display_errors', 0);

// Timezone
date_default_timezone_set('Asia/Ho_Chi_Minh');

// Khởi động session nếu chưa có
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database connection
require_once __DIR__ . '/database.php';

// =====================================================
// CONSTANTS - ĐƯỜNG DẪN
// =====================================================

// Base URL (URL gốc của website)
define('BASE_URL', 'http://localhost/fashion-shop');

// Assets URL (CSS, JS, Images)
define('ASSETS_URL', BASE_URL . '/assets');

// Uploads URL (Uploaded files)
define('UPLOADS_URL', BASE_URL . '/uploads');

// Root path (Đường dẫn thư mục gốc trên server)
define('ROOT_PATH', __DIR__ . '/..');

// Uploads path
define('UPLOADS_PATH', ROOT_PATH . '/uploads');

// =====================================================
// CONSTANTS - CẤU HÌNH CHUNG
// =====================================================

// Tên website
define('SITE_NAME', 'Fashion Shop');

// Email liên hệ
define('SITE_EMAIL', 'contact@fashionshop.vn');

// Số điện thoại
define('SITE_PHONE', '1900-xxxx');

// Số sản phẩm trên 1 trang
define('PRODUCTS_PER_PAGE', 12);

// Số đơn hàng trên 1 trang
define('ORDERS_PER_PAGE', 20);

// Thời gian giỏ hàng hết hạn (giây) - 7 ngày
define('CART_EXPIRE_TIME', 7 * 24 * 60 * 60);

// Thời gian session (giây) - 2 giờ
define('SESSION_LIFETIME', 2 * 60 * 60);

// Kích thước file upload tối đa (bytes) - 5MB
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024);

// Các định dạng ảnh cho phép
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/webp']);

// =====================================================
// CONSTANTS - TRẠNG THÁI ĐỚN HÀNG
// =====================================================

define('ORDER_STATUS_PENDING', 'pending');
define('ORDER_STATUS_PROCESSING', 'processing');
define('ORDER_STATUS_CONFIRMED', 'confirmed');
define('ORDER_STATUS_SHIPPING', 'shipping');
define('ORDER_STATUS_COMPLETED', 'completed');
define('ORDER_STATUS_CANCELLED', 'cancelled');
define('ORDER_STATUS_REFUNDED', 'refunded');

// =====================================================
// CONSTANTS - VAI TRÒ NGƯỜI DÙNG
// =====================================================

define('ROLE_ADMIN', 'admin');
define('ROLE_CUSTOMER', 'customer');

?>

