<?php
/**
 * Hằng số cấu hình hệ thống
 */

// URL gốc của website
define('SITE_URL', 'http://localhost/fashion-shop');
define('BASE_PATH', __DIR__ . '/..');

// Đường dẫn upload
define('UPLOAD_PATH', BASE_PATH . '/uploads');
define('UPLOAD_URL', SITE_URL . '/uploads');

// Timezone
date_default_timezone_set('Asia/Ho_Chi_Minh');

// Hiển thị lỗi (chỉ trong môi trường development)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
