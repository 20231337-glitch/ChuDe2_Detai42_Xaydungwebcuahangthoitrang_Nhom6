<?php
/**
 * Kết nối MySQL Database
 * Database: fashion_shop
 */

// Thông tin kết nối
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'fashion_shop');
define('DB_CHARSET', 'utf8mb4');

// Tạo kết nối
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Kiểm tra kết nối
if (!$conn) {
    die("❌ Kết nối database thất bại: " . mysqli_connect_error());
}

// Set charset
mysqli_set_charset($conn, DB_CHARSET);

// Set timezone
mysqli_query($conn, "SET time_zone = '+07:00'");

// Không hiển thị lỗi ra ngoài (production)
// mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

/**
 * Hàm thực thi query và trả về nhiều dòng
 * @param string $sql Câu SQL query
 * @param array $params Mảng tham số bind
 * @param string $types Chuỗi kiểu dữ liệu (i=int, s=string, d=double)
 * @return array Mảng kết quả
 */
function fetchData($sql, $params = [], $types = '') {
    global $conn;
    
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        error_log("Prepare failed: " . mysqli_error($conn) . " - SQL: " . $sql);
        return [];
    }
    
    if (!empty($params) && !empty($types)) {
        mysqli_stmt_bind_param($stmt, $types, ...$params);
    }
    
    if (!mysqli_stmt_execute($stmt)) {
        error_log("Execute failed: " . mysqli_stmt_error($stmt));
        mysqli_stmt_close($stmt);
        return [];
    }
    
    $result = mysqli_stmt_get_result($stmt);
    if (!$result) {
        mysqli_stmt_close($stmt);
        return [];
    }
    
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
    
    mysqli_stmt_close($stmt);
    return $data;
}

/**
 * Hàm thực thi query và trả về 1 dòng
 * @param string $sql Câu SQL query
 * @param array $params Mảng tham số bind
 * @param string $types Chuỗi kiểu dữ liệu
 * @return array|null Mảng 1 dòng hoặc null
 */
function fetchRow($sql, $params = [], $types = '') {
    global $conn;
    
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        error_log("Prepare failed: " . mysqli_error($conn) . " - SQL: " . $sql);
        return null;
    }
    
    if (!empty($params) && !empty($types)) {
        mysqli_stmt_bind_param($stmt, $types, ...$params);
    }
    
    if (!mysqli_stmt_execute($stmt)) {
        error_log("Execute failed: " . mysqli_stmt_error($stmt));
        mysqli_stmt_close($stmt);
        return null;
    }
    
    $result = mysqli_stmt_get_result($stmt);
    if (!$result) {
        mysqli_stmt_close($stmt);
        return null;
    }
    
    $row = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);
    
    return $row ? $row : null;
}

/**
 * Hàm thực thi INSERT/UPDATE/DELETE
 * @param string $sql Câu SQL
 * @param array $params Mảng tham số
 * @param string $types Chuỗi kiểu dữ liệu
 * @return bool True nếu thành công
 */
function executeQuery($sql, $params = [], $types = '') {
    global $conn;
    
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        error_log("Prepare failed: " . mysqli_error($conn) . " - SQL: " . $sql);
        return false;
    }
    
    if (!empty($params) && !empty($types)) {
        mysqli_stmt_bind_param($stmt, $types, ...$params);
    }
    
    $result = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    
    return $result;
}

/**
 * Lấy ID vừa insert
 * @return int
 */
function getLastInsertId() {
    global $conn;
    return mysqli_insert_id($conn);
}
?>
