<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {
    header('Location: /fashion-shop/public/auth/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Lấy tất cả đánh giá của user
$sql = "
    SELECT r.*, p.product_name, p.slug, pi.image_url
    FROM reviews r
    JOIN products p ON r.product_id = p.product_id
    LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
    WHERE r.user_id = ?
    ORDER BY r.created_at DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$reviews = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đánh giá của tôi</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f5f5f5; padding: 20px; }
        .container { max-width: 1000px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
        h1 { color: #333; margin-bottom: 30px; }
        .review-item { border-bottom: 1px solid #eee; padding: 20px 0; }
        .review-header { display: flex; align-items: center; margin-bottom: 15px; }
        .review-header img { width: 80px; height: 80px; object-fit: cover; border-radius: 5px; margin-right: 15px; }
        .review-info { flex: 1; }
        .product-name { font-weight: bold; color: #333; margin-bottom: 5px; }
        .review-date { font-size: 13px; color: #666; }
        .stars { color: #ffc107; font-size: 18px; }
        .review-comment { margin: 15px 0; color: #555; line-height: 1.6; }
        .review-images { display: flex; gap: 10px; margin-top: 10px; }
        .review-images img { width: 100px; height: 100px; object-fit: cover; border-radius: 5px; }
        .status { padding: 4px 12px; border-radius: 15px; font-size: 12px; display: inline-block; }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-approved { background: #d4edda; color: #155724; }
        .status-rejected { background: #f8d7da; color: #721c24; }
        .back-link { display: inline-block; margin-bottom: 20px; color: #007bff; text-decoration: none; }
    </style>
</head>
<body>
    <div class="container">
        <a href="/fashion-shop/public/account/profile.php" class="back-link">← Quay lại trang cá nhân</a>
        <h1>Đánh giá của tôi</h1>
        
        <?php if (empty($reviews)): ?>
            <p>Bạn chưa có đánh giá nào. <a href="index.php">Đánh giá ngay</a></p>
        <?php else: ?>
            <?php foreach ($reviews as $review): ?>
                <div class="review-item">
                    <div class="review-header">
                        <img src="/fashion-shop/<?php echo htmlspecialchars($review['image_url'] ?? 'assets/images/no-image.jpg'); ?>" alt="">
                        <div class="review-info">
                            <div class="product-name"><?php echo htmlspecialchars($review['product_name']); ?></div>
                            <div class="review-date"><?php echo date('d/m/Y H:i', strtotime($review['created_at'])); ?></div>
                            <div class="stars"><?php echo str_repeat('★', $review['rating']) . str_repeat('☆', 5 - $review['rating']); ?></div>
                            <span class="status status-<?php echo $review['status']; ?>">
                                <?php 
                                    echo $review['status'] == 'pending' ? 'Chờ duyệt' : 
                                        ($review['status'] == 'approved' ? 'Đã duyệt' : 'Bị từ chối'); 
                                ?>
                            </span>
                        </div>
                    </div>
                    
                    <?php if ($review['comment']): ?>
                        <div class="review-comment"><?php echo nl2br(htmlspecialchars($review['comment'])); ?></div>
                    <?php endif; ?>
                    
                    <?php if ($review['images']): 
                        $images = json_decode($review['images'], true);
                        if ($images):
                    ?>
                        <div class="review-images">
                            <?php foreach ($images as $img): ?>
                                <img src="/fashion-shop/<?php echo htmlspecialchars($img); ?>" alt="">
                            <?php endforeach; ?>
                        </div>
                    <?php endif; endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
</html>
