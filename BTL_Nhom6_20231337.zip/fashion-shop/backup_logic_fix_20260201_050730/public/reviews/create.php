<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/constants.php';
require_once '../../includes/functions.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {
    header('Location: /fashion-shop/public/auth/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : 0;
$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;

// Kiểm tra quyền đánh giá
$check_sql = "
    SELECT p.product_name, o.order_id
    FROM order_details od
    JOIN orders o ON od.order_id = o.order_id
    JOIN product_variants pv ON od.variant_id = pv.variant_id
    JOIN products p ON pv.product_id = p.product_id
    WHERE p.product_id = ?
    AND o.order_id = ?
    AND o.user_id = ?
    AND o.order_status = 'completed'
    AND NOT EXISTS (
        SELECT 1 FROM reviews 
        WHERE product_id = ? 
        AND user_id = ? 
        AND order_id = ?
    )
";

$stmt = $conn->prepare($check_sql);
$stmt->bind_param("iiiiii", $product_id, $order_id, $user_id, $product_id, $user_id, $order_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Bạn không có quyền đánh giá sản phẩm này hoặc đã đánh giá rồi.");
}

$product = $result->fetch_assoc();
$error = '';
$success = '';

// Xử lý submit form
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $rating = isset($_POST['rating']) ? (int)$_POST['rating'] : 0;
    $comment = trim($_POST['comment'] ?? '');
    
    // Validate
    if ($rating < 1 || $rating > 5) {
        $error = "Vui lòng chọn số sao từ 1-5";
    } else {
        // Xử lý upload ảnh
        $uploaded_images = [];
        if (!empty($_FILES['images']['name'][0])) {
            $upload_dir = "../../uploads/reviews/";
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            for ($i = 0; $i < count($_FILES['images']['name']); $i++) {
                if ($_FILES['images']['error'][$i] == 0) {
                    $file_ext = pathinfo($_FILES['images']['name'][$i], PATHINFO_EXTENSION);
                    $new_filename = 'review_' . time() . '_' . $i . '.' . $file_ext;
                    $upload_path = $upload_dir . $new_filename;
                    
                    if (move_uploaded_file($_FILES['images']['tmp_name'][$i], $upload_path)) {
                        $uploaded_images[] = 'uploads/reviews/' . $new_filename;
                    }
                }
            }
        }
        
        $images_json = !empty($uploaded_images) ? json_encode($uploaded_images) : null;
        
        // Bắt đầu transaction
        $conn->begin_transaction();
        
        try {
            // Insert review
            $insert_sql = "INSERT INTO reviews (product_id, user_id, order_id, rating, comment, images, status, created_at)
                           VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW())";
            $stmt = $conn->prepare($insert_sql);
            $stmt->bind_param("iiiiss", $product_id, $user_id, $order_id, $rating, $comment, $images_json);
            $stmt->execute();
            
            // Tạo thông báo cho admin
            $admin_id = 1; // ID admin
            $notif_title = "Đánh giá mới cần duyệt";
            $notif_message = "Sản phẩm '{$product['product_name']}' có đánh giá mới từ {$_SESSION['fullname']}";
            
            $notif_sql = "INSERT INTO notifications (user_id, type, title, message, is_read, created_at)
                          VALUES (?, 'new_review', ?, ?, 0, NOW())";
            $stmt_notif = $conn->prepare($notif_sql);
            $stmt_notif->bind_param("iss", $admin_id, $notif_title, $notif_message);
            $stmt_notif->execute();
            
            $conn->commit();
            $success = "Đánh giá của bạn đã được gửi và đang chờ duyệt!";
            
        } catch (Exception $e) {
            $conn->rollback();
            $error = "Lỗi: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đánh giá sản phẩm</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f5f5f5; padding: 20px; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
        h1 { color: #333; margin-bottom: 20px; }
        .product-info { background: #f8f9fa; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: bold; color: #333; }
        .star-rating { font-size: 30px; }
        .star-rating input { display: none; }
        .star-rating label { color: #ddd; cursor: pointer; }
        .star-rating label:hover, .star-rating label:hover ~ label, .star-rating input:checked ~ label { color: #ffc107; }
        textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; min-height: 100px; }
        .file-upload { padding: 10px; border: 2px dashed #ddd; border-radius: 5px; text-align: center; cursor: pointer; }
        .btn { padding: 12px 24px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; }
        .btn-primary { background: #007bff; color: white; }
        .btn-primary:hover { background: #0056b3; }
        .alert { padding: 12px; border-radius: 5px; margin-bottom: 20px; }
        .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-danger { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .back-link { display: inline-block; margin-bottom: 20px; color: #007bff; text-decoration: none; }
    </style>
</head>
<body>
    <div class="container">
        <a href="index.php" class="back-link">← Quay lại</a>
        <h1>Đánh giá sản phẩm</h1>
        
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
            <a href="index.php" class="btn btn-primary">Quay lại danh sách</a>
        <?php else: ?>
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="product-info">
                <strong>Sản phẩm:</strong> <?php echo htmlspecialchars($product['product_name']); ?><br>
                <strong>Đơn hàng:</strong> #<?php echo $order_id; ?>
            </div>
            
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Đánh giá của bạn *</label>
                    <div class="star-rating">
                        <input type="radio" name="rating" value="5" id="star5" required>
                        <label for="star5">★</label>
                        <input type="radio" name="rating" value="4" id="star4">
                        <label for="star4">★</label>
                        <input type="radio" name="rating" value="3" id="star3">
                        <label for="star3">★</label>
                        <input type="radio" name="rating" value="2" id="star2">
                        <label for="star2">★</label>
                        <input type="radio" name="rating" value="1" id="star1">
                        <label for="star1">★</label>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Nhận xét</label>
                    <textarea name="comment" placeholder="Chia sẻ trải nghiệm của bạn về sản phẩm này..."></textarea>
                </div>
                
                <div class="form-group">
                    <label>Hình ảnh (Tối đa 5 ảnh)</label>
                    <input type="file" name="images[]" multiple accept="image/*" max="5">
                    <small style="color: #666;">Định dạng: JPG, PNG. Kích thước tối đa: 5MB/ảnh</small>
                </div>
                
                <button type="submit" class="btn btn-primary">Gửi đánh giá</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
