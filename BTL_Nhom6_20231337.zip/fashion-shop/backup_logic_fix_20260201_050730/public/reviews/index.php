<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/constants.php';
require_once '../../includes/functions.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {
    header('Location: /fashion-shop/public/auth/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Lấy danh sách sản phẩm đã mua và có thể đánh giá
$sql = "
    SELECT DISTINCT
        p.product_id,
        p.product_name,
        p.slug,
        pi.image_url,
        o.order_id,
        o.order_date,
        (SELECT COUNT(*) FROM reviews WHERE product_id = p.product_id AND user_id = ? AND order_id = o.order_id) as reviewed
    FROM order_details od
    JOIN orders o ON od.order_id = o.order_id
    JOIN product_variants pv ON od.variant_id = pv.variant_id
    JOIN products p ON pv.product_id = p.product_id
    LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
    WHERE o.user_id = ?
    AND o.order_status = 'completed'
    ORDER BY o.order_date DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $user_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$products = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sản phẩm có thể đánh giá</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f5f5f5; padding: 20px; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
        h1 { color: #333; margin-bottom: 30px; }
        .product-list { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }
        .product-card { border: 1px solid #ddd; border-radius: 8px; padding: 15px; }
        .product-card img { width: 100%; height: 200px; object-fit: cover; border-radius: 5px; }
        .product-info { margin-top: 10px; }
        .product-name { font-size: 16px; font-weight: bold; color: #333; margin: 10px 0; }
        .order-info { font-size: 13px; color: #666; margin-bottom: 10px; }
        .btn { display: inline-block; padding: 8px 16px; border-radius: 5px; text-decoration: none; text-align: center; }
        .btn-review { background: #28a745; color: white; }
        .btn-reviewed { background: #6c757d; color: white; cursor: not-allowed; }
        .back-link { display: inline-block; margin-bottom: 20px; color: #007bff; text-decoration: none; }
        .back-link:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="container">
        <a href="/fashion-shop/public/account/orders.php" class="back-link">← Quay lại đơn hàng</a>
        <h1>Sản phẩm có thể đánh giá</h1>
        
        <?php if (empty($products)): ?>
            <p>Bạn chưa có đơn hàng hoàn thành nào.</p>
        <?php else: ?>
            <div class="product-list">
                <?php foreach ($products as $product): ?>
                    <div class="product-card">
                        <img src="/fashion-shop/<?php echo htmlspecialchars($product['image_url'] ?? 'assets/images/no-image.jpg'); ?>" alt="<?php echo htmlspecialchars($product['product_name']); ?>">
                        <div class="product-info">
                            <div class="product-name"><?php echo htmlspecialchars($product['product_name']); ?></div>
                            <div class="order-info">
                                Đơn hàng #<?php echo $product['order_id']; ?> - 
                                <?php echo date('d/m/Y', strtotime($product['order_date'])); ?>
                            </div>
                            <?php if ($product['reviewed'] > 0): ?>
                                <a href="view.php?product_id=<?php echo $product['product_id']; ?>" class="btn btn-reviewed">Đã đánh giá</a>
                            <?php else: ?>
                                <a href="create.php?product_id=<?php echo $product['product_id']; ?>&order_id=<?php echo $product['order_id']; ?>" class="btn btn-review">Đánh giá ngay</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
