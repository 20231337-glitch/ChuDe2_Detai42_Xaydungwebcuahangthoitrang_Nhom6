<?php
$pageTitle = 'Chi tiết sản phẩm';
require_once __DIR__ . '/../includes/header.php';

// Lấy product_id
$productId = get('id');
if (!$productId) {
    redirect(BASE_URL . '/public/products/list.php');
}

// Lấy thông tin sản phẩm
$sql = "
    SELECT p.*, c.category_name
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.category_id
    WHERE p.product_id = ? AND p.status = 'active' AND p.deleted_at IS NULL
";
$product = fetchRow($sql, [$productId], 'i');

if (!$product) {
    redirect(BASE_URL . '/public/products/list.php');
}

// Lấy hình ảnh sản phẩm
$images = fetchData(
    "SELECT image_url, is_primary FROM product_images WHERE product_id = ? ORDER BY is_primary DESC, display_order",
    [$productId],
    'i'
);

// Lấy variants (size, màu)
$variants = fetchData(
    "SELECT pv.*, s.size_name, c.color_name, c.color_code
     FROM product_variants pv
     JOIN sizes s ON pv.size_id = s.size_id
     JOIN colors c ON pv.color_id = c.color_id
     WHERE pv.product_id = ?
     ORDER BY s.size_name, c.color_name",
    [$productId],
    'i'
);

// Tính discount nếu có sale_price
$discount = 0;
if (isset($product['sale_price']) && $product['sale_price'] > 0 && $product['sale_price'] < $product['base_price']) {
    $discount = round((($product['base_price'] - $product['sale_price']) / $product['base_price']) * 100);
}

// Lấy sizes và colors unique
$sizes = [];
$colors = [];
foreach ($variants as $v) {
    $sizes[$v['size_id']] = $v['size_name'];
    $colors[$v['color_id']] = ['name' => $v['color_name'], 'code' => $v['color_code']];
}

// Lấy sản phẩm liên quan
$relatedProducts = fetchData(
    "SELECT p.*, pi.image_url
     FROM products p
     LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
     WHERE p.category_id = ? AND p.product_id != ? AND p.status = 'active' AND p.deleted_at IS NULL
     ORDER BY RAND()
     LIMIT 4",
    [$product['category_id'], $productId],
    'ii'
);

?>

<!-- Breadcrumb -->
<div class="container mt-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>/public/index.php">Trang chủ</a></li>
            <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>/public/products/list.php">Sản phẩm</a></li>
            <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>/public/products/list.php?category_id=<?php echo $product['category_id']; ?>"><?php echo e($product['category_name']); ?></a></li>
            <li class="breadcrumb-item active"><?php echo e($product['product_name']); ?></li>
        </ol>
    </nav>
</div>

<!-- Product Detail -->
<div class="container my-5">
    <div class="row g-4">
        <!-- Product Images -->
        <div class="col-lg-6">
            <div class="product-detail-images">
                <?php if ($discount > 0): ?>
                    <div class="product-badge-large">-<?php echo $discount; ?>%</div>
                <?php endif; ?>
                
                <div class="main-image mb-3">
                    <img id="mainImage" src="<?php echo $images[0]['image_url'] ?? 'https://via.placeholder.com/600x600?text=No+Image'; ?>" 
                         alt="<?php echo e($product['product_name']); ?>" class="img-fluid rounded">
                </div>
                
                <?php if (count($images) > 1): ?>
                    <div class="thumbnail-images">
                        <?php foreach ($images as $img): ?>
                            <img src="<?php echo $img['image_url']; ?>" 
                                 alt="Thumbnail" 
                                 class="thumbnail <?php echo $img['is_primary'] ? 'active' : ''; ?>"
                                 onclick="changeMainImage('<?php echo $img['image_url']; ?>', this)">
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Product Info -->
        <div class="col-lg-6">
            <div class="product-detail-info">
                <h1 class="product-detail-title"><?php echo e($product['product_name']); ?></h1>
                
                <div class="product-meta mb-3">
                    <span class="rating">
                        <i class="fas fa-star text-warning"></i>
                        0.0
                        (0 đánh giá)
                    </span>
                    <span class="divider">|</span>
                    <span>👁️ <?php echo $product['view_count']; ?> lượt xem</span>
                    <span class="divider">|</span>
<div class="product-price-section">
                    <?php if ($discount > 0): ?>
                        <div class="current-price"><?php echo formatMoney($product['sale_price']); ?></div>
                        <div class="compare-price"><?php echo formatMoney($product['base_price']); ?></div>
                    <?php else: ?>
                        <div class="current-price"><?php echo formatMoney($product['base_price']); ?></div>
                    <?php endif; ?>
                </div>
                </div>
                
                <div class="product-description">
                    <h5>📝 Mô tả sản phẩm</h5>
                    <p><?php echo nl2br(e($product['description'])); ?></p>
                </div>
                
                <!-- Size Selection -->
                <?php if (!empty($sizes)): ?>
                    <div class="size-selection mb-3">
                        <h6>Chọn Size:</h6>
                        <div class="size-options">
                            <?php foreach ($sizes as $sizeId => $sizeName): ?>
                                <input type="radio" class="btn-check" name="size" id="size<?php echo $sizeId; ?>" value="<?php echo $sizeId; ?>">
                                <label class="btn btn-outline-primary" for="size<?php echo $sizeId; ?>"><?php echo e($sizeName); ?></label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
                
                <!-- Color Selection -->
                <?php if (!empty($colors)): ?>
                    <div class="color-selection mb-3">
                        <h6>Chọn Màu:</h6>
                        <div class="color-options">
                            <?php foreach ($colors as $colorId => $color): ?>
                                <input type="radio" class="btn-check" name="color" id="color<?php echo $colorId; ?>" value="<?php echo $colorId; ?>">
                                <label class="btn btn-outline-secondary color-btn" for="color<?php echo $colorId; ?>">
                                    <span class="color-circle" style="background: <?php echo e($color['code']); ?>"></span>
                                    <?php echo e($color['name']); ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
                
                <!-- Quantity -->
                <div class="quantity-selection mb-4">
                    <h6>Số lượng:</h6>
                    <div class="input-group quantity-input">
                        <button class="btn btn-outline-secondary" type="button" onclick="decreaseQty()">-</button>
                        <input type="number" id="quantity" class="form-control text-center" value="1" min="1">
                        <button class="btn btn-outline-secondary" type="button" onclick="increaseQty()">+</button>
                    </div>
                </div>
                
                <!-- Action Buttons -->
                                <!-- Hidden input for JavaScript -->
                <input type="hidden" name="product_id" value="<?php echo $productId; ?>">
                
<div class="action-buttons">
                    <button class="btn btn-primary btn-lg" onclick="addToCart()">
                        <i class="fas fa-shopping-cart"></i> Thêm vào giỏ
                    </button>
                    <button class="btn btn-secondary btn-lg" onclick="buyNow()">
                        <i class="fas fa-bolt"></i> Mua ngay
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Related Products -->
    <?php if (!empty($relatedProducts)): ?>
        <div class="mt-5">
            <div class="section-header">
                <h2 class="section-title">🔗 Sản phẩm liên quan</h2>
            </div>
            <div class="row g-4">
                <?php foreach ($relatedProducts as $rp): 
                    $rpDiscount = 0;
                    if (isset($rp['sale_price']) && $rp['sale_price'] > 0 && $rp['sale_price'] < $rp['base_price']) {
                        $rpDiscount = round((($rp['base_price'] - $rp['sale_price']) / $rp['base_price']) * 100);
                    }
                ?>
                    <div class="col-md-3">
                        <div class="product-card">
                            <?php if ($rpDiscount > 0): ?>
                                <div class="product-badge">-<?php echo $rpDiscount; ?>%</div>
                            <?php endif; ?>
                            <div class="product-image">
                                <img src="<?php echo $rp['image_url'] ?: 'https://via.placeholder.com/300x300?text=No+Image'; ?>" 
                                     alt="<?php echo e($rp['product_name']); ?>">
                                <div class="product-overlay">
                                    <a href="?id=<?php echo $rp['product_id']; ?>" class="btn btn-primary btn-sm w-100">
                                        <i class="fas fa-eye"></i> Xem chi tiết
                                    </a>
                                </div>
                            </div>
                            <div class="product-info">
                                <h6 class="product-title"><?php echo e($rp['product_name']); ?></h6>
                                <div>
                                    <span class="product-price"><?php echo formatMoney($rp['base_price']); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<style>
.product-detail-images {
    position: relative;
}

.product-badge-large {
    position: absolute;
    top: 20px;
    right: 20px;
    background: var(--color-primary);
    color: white;
    padding: 12px 24px;
    border-radius: 50px;
    font-size: 1.5rem;
    font-weight: 700;
    z-index: 10;
    box-shadow: 0 4px 12px rgba(255, 107, 107, 0.3);
}

.main-image {
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 4px 16px rgba(0,0,0,0.12);
}

.thumbnail-images {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.thumbnail {
    width: 100px;
    height: 100px;
    object-fit: cover;
    border-radius: 8px;
    cursor: pointer;
    border: 3px solid transparent;
    transition: all 0.3s ease;
}

.thumbnail:hover, .thumbnail.active {
    border-color: var(--color-primary);
    transform: scale(1.05);
}

.product-detail-info {
    background: white;
    padding: 2rem;
    border-radius: 15px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.product-detail-title {
    font-size: 2rem;
    font-weight: 800;
    color: var(--color-text);
    margin-bottom: 1rem;
}

.product-meta {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 0.95rem;
    color: var(--color-text-light);
}

.divider {
    color: #ddd;
}

.product-price-section {
    background: linear-gradient(135deg, #fff5f5, #f0f9ff);
    padding: 1.5rem;
    border-radius: 12px;
    margin: 1.5rem 0;
}

.current-price {
    font-size: 2.5rem;
    font-weight: 800;
    color: var(--color-primary);
}

.compare-price {
    font-size: 1.3rem;
    color: var(--color-text-light);
    text-decoration: line-through;
}

.product-description {
    margin: 1.5rem 0;
    padding: 1rem;
    background: #f8f9fa;
    border-radius: 8px;
}

.size-options, .color-options {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.btn-outline-primary, .btn-outline-secondary {
    border-radius: 8px;
    font-weight: 600;
}

.color-circle {
    display: inline-block;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    margin-right: 8px;
    border: 2px solid white;
    box-shadow: 0 0 0 1px #ddd;
}

.quantity-input {
    max-width: 150px;
}

.action-buttons {
    display: flex;
    gap: 15px;
    margin-top: 2rem;
}

.action-buttons .btn {
    flex: 1;
    border-radius: 50px;
    font-size: 1.1rem;
    font-weight: 700;
    padding: 14px;
}
</style>

<script>
// Cart functions đã được chuyển sang assets/js/cart.js
// Giữ lại các functions khác nếu cần
function changeMainImage(url, element) {
    document.getElementById('mainImage').src = url;
    document.querySelectorAll('.thumbnail').forEach(t => t.classList.remove('active'));
    element.classList.add('active');
}

function decreaseQty() {
    const input = document.getElementById('quantity');
    if (input.value > 1) input.value = parseInt(input.value) - 1;
}

function increaseQty() {
    const input = document.getElementById('quantity');
    input.value = parseInt(input.value) + 1;
}

// addToCart() và buyNow() đã có trong cart.js
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

