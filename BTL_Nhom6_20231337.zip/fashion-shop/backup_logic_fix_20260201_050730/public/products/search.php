<?php
$pageTitle = 'Tìm kiếm sản phẩm';
require_once __DIR__ . '/../includes/header.php';

// Lấy từ khóa tìm kiếm
$keyword = get('q', '');
$categoryId = get('category_id');
$sort = get('sort', 'new');

// Phân trang
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 12;
$offset = ($page - 1) * $perPage;

// Build WHERE clause
$where = "p.status = 'active' AND p.deleted_at IS NULL";
$params = [];
$types = '';

if ($keyword) {
    $where .= " AND (p.product_name LIKE ? OR p.description LIKE ?)";
    $searchTerm = '%' . $keyword . '%';
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $types .= 'ss';
}

if ($categoryId) {
    $where .= " AND p.category_id = ?";
    $params[] = $categoryId;
    $types .= 'i';
}

// Order by
$orderBy = "p.created_at DESC";
switch ($sort) {
    case 'sold':
        $orderBy = "p.sold_count DESC";
        break;
    case 'view':
        $orderBy = "p.view_count DESC";
        break;
    case 'price_asc':
        $orderBy = "IF(p.sale_price > 0, p.sale_price, p.base_price) ASC";
        break;
    case 'price_desc':
        $orderBy = "IF(p.sale_price > 0, p.sale_price, p.base_price) DESC";
        break;
    case 'name':
        $orderBy = "p.product_name ASC";
        break;
}

// Đếm tổng số sản phẩm
$sqlCount = "SELECT COUNT(*) as total FROM products p WHERE $where";
$countData = fetchRow($sqlCount, $params, $types);
$totalRecords = $countData ? $countData['total'] : 0;
$totalPages = getTotalPages($totalRecords, $perPage);

// Lấy danh sách sản phẩm
$products = [];
if ($keyword || $categoryId) {
    $sql = "
        SELECT p.*, pi.image_url, c.category_name
        FROM products p
        LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
        LEFT JOIN categories c ON p.category_id = c.category_id
        WHERE $where
        ORDER BY $orderBy
        LIMIT ?, ?
    ";
    $params[] = $offset;
    $params[] = $perPage;
    $types .= 'ii';
    
    $products = fetchData($sql, $params, $types);
}

// Lấy danh sách danh mục cho bộ lọc
$categories = fetchData("SELECT category_id, category_name FROM categories WHERE status = 'active' AND deleted_at IS NULL ORDER BY category_name");

// Build URL cho pagination
$urlParams = [];
if ($keyword) $urlParams[] = "q=" . urlencode($keyword);
if ($categoryId) $urlParams[] = "category_id=$categoryId";
if ($sort != 'new') $urlParams[] = "sort=$sort";
$baseUrl = '?';
if (!empty($urlParams)) {
    $baseUrl .= implode('&', $urlParams);
}

?>

<div class="container search-page">
    <div class="page-header">
        <h1>🔍 Tìm kiếm sản phẩm</h1>
    </div>
    
    <!-- Search Form -->
    <div class="search-form-container">
        <form method="GET" action="" class="search-form">
            <div class="search-input-group">
                <input 
                    type="text" 
                    name="q" 
                    class="search-input" 
                    placeholder="Nhập tên sản phẩm cần tìm..." 
                    value="<?php echo e($keyword); ?>"
                    autofocus
                >
                <button type="submit" class="btn-search">
                    <i class="fas fa-search"></i> Tìm kiếm
                </button>
            </div>
            
            <div class="search-filters">
                <div class="filter-group">
                    <label>Danh mục:</label>
                    <select name="category_id" class="filter-select">
                        <option value="">Tất cả danh mục</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo $cat['category_id']; ?>" 
                                <?php echo $categoryId == $cat['category_id'] ? 'selected' : ''; ?>>
                                <?php echo e($cat['category_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Sắp xếp:</label>
                    <select name="sort" class="filter-select">
                        <option value="new" <?php echo $sort == 'new' ? 'selected' : ''; ?>>Mới nhất</option>
                        <option value="sold" <?php echo $sort == 'sold' ? 'selected' : ''; ?>>Bán chạy</option>
                        <option value="view" <?php echo $sort == 'view' ? 'selected' : ''; ?>>Xem nhiều</option>
                        <option value="price_asc" <?php echo $sort == 'price_asc' ? 'selected' : ''; ?>>Giá tăng dần</option>
                        <option value="price_desc" <?php echo $sort == 'price_desc' ? 'selected' : ''; ?>>Giá giảm dần</option>
                        <option value="name" <?php echo $sort == 'name' ? 'selected' : ''; ?>>Tên A-Z</option>
                    </select>
                </div>
            </div>
        </form>
    </div>
    
    <?php if ($keyword || $categoryId): ?>
        <div class="search-results-header">
            <?php if ($keyword): ?>
                <p>Kết quả tìm kiếm cho: <strong>"<?php echo e($keyword); ?>"</strong></p>
            <?php endif; ?>
            <p>Tìm thấy <strong><?php echo $totalRecords; ?></strong> sản phẩm</p>
        </div>
        
        <!-- Product Grid -->
        <?php if (empty($products)): ?>
            <div class="no-products">
                <i class="fas fa-search" style="font-size: 64px; color: #ccc; margin-bottom: 20px;"></i>
                <p>😔 Không tìm thấy sản phẩm nào phù hợp!</p>
                <p>Hãy thử tìm kiếm với từ khóa khác.</p>
                <a href="<?php echo BASE_URL; ?>/public/products/list.php" class="btn-primary">Xem tất cả sản phẩm</a>
            </div>
        <?php else: ?>
            <div class="product-grid">
                <?php foreach ($products as $product): ?>
                    <div class="product-card">
                        <a href="<?php echo BASE_URL; ?>/public/products/detail.php?id=<?php echo $product['product_id']; ?>">
                            <div class="product-image">
                                <?php if ($product['image_url']): ?>
                                    <img src="<?php echo BASE_URL . $product['image_url']; ?>" alt="<?php echo e($product['product_name']); ?>">
                                <?php else: ?>
                                    <img src="<?php echo BASE_URL; ?>/assets/images/no-image.png" alt="No image">
                                <?php endif; ?>
                                
                                <?php if ($product['discount_percent'] > 0): ?>
                                    <span class="badge-discount">-<?php echo $product['discount_percent']; ?>%</span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="product-info">
                                <h3><?php echo e($product['product_name']); ?></h3>
                                <p class="category"><?php echo e($product['category_name']); ?></p>
                                
                                <div class="price">
                                    <?php if ($product['discount_percent'] > 0): ?>
                                        <span class="old-price"><?php echo formatMoney($product['price']); ?></span>
                                        <span class="new-price"><?php echo formatMoney($product['base_price']); ?></span>
                                    <?php else: ?>
                                        <span class="new-price"><?php echo formatMoney($product['price']); ?></span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="product-meta">
                                    <span>⭐ 0.0</span>
                                    <span>Đã bán: <?php echo $product['sold_count']; ?></span>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Pagination -->
            <?php echo renderPagination($page, $totalPages, $baseUrl); ?>
        <?php endif; ?>
    <?php else: ?>
        <div class="search-suggestions">
            <div class="suggestion-box">
                <i class="fas fa-lightbulb" style="font-size: 48px; color: #f39c12; margin-bottom: 15px;"></i>
                <h3>💡 Gợi ý tìm kiếm</h3>
                <p>Nhập từ khóa vào ô tìm kiếm phía trên để tìm sản phẩm bạn muốn.</p>
                <p><strong>Ví dụ:</strong> áo thun, quần jean, váy dạ hội...</p>
            </div>
            
            <div class="popular-categories">
                <h3>🔥 Danh mục phổ biến</h3>
                <div class="category-links">
                    <?php foreach ($categories as $cat): ?>
                        <a href="?category_id=<?php echo $cat['category_id']; ?>" class="category-tag">
                            <?php echo e($cat['category_name']); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<style>
.search-page {
    padding: 30px 0;
}

.search-form-container {
    background: #f8f9fa;
    padding: 30px;
    border-radius: 10px;
    margin-bottom: 30px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.search-input-group {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
}

.search-input {
    flex: 1;
    padding: 15px 20px;
    border: 2px solid #ddd;
    border-radius: 8px;
    font-size: 16px;
}

.search-input:focus {
    outline: none;
    border-color: #4ECDC4;
}

.btn-search {
    padding: 15px 30px;
    background: #4ECDC4;
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
}

.btn-search:hover {
    background: #3fb8af;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(78, 205, 196, 0.3);
}

.search-filters {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
}

.filter-group {
    display: flex;
    align-items: center;
    gap: 10px;
}

.filter-group label {
    font-weight: 600;
    color: #333;
}

.filter-select {
    padding: 8px 15px;
    border: 2px solid #ddd;
    border-radius: 6px;
    font-size: 14px;
    min-width: 150px;
}

.search-results-header {
    margin-bottom: 20px;
    padding: 15px;
    background: #e8f4f8;
    border-radius: 8px;
}

.search-results-header p {
    margin: 5px 0;
}

.search-suggestions {
    text-align: center;
    padding: 50px 20px;
}

.suggestion-box {
    background: #fff3cd;
    padding: 40px;
    border-radius: 10px;
    margin-bottom: 30px;
}

.popular-categories {
    background: white;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.category-links {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    justify-content: center;
    margin-top: 20px;
}

.category-tag {
    padding: 10px 20px;
    background: #4ECDC4;
    color: white;
    border-radius: 20px;
    text-decoration: none;
    transition: all 0.3s;
}

.category-tag:hover {
    background: #3fb8af;
    transform: translateY(-2px);
}

.product-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.product-card {
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    transition: all 0.3s;
}

.product-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 16px rgba(0,0,0,0.2);
}

.product-card a {
    text-decoration: none;
    color: inherit;
}

.product-image {
    position: relative;
    padding-top: 100%;
    overflow: hidden;
}

.product-image img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.badge-discount {
    position: absolute;
    top: 10px;
    right: 10px;
    background: #e74c3c;
    color: white;
    padding: 5px 10px;
    border-radius: 5px;
    font-weight: bold;
}

.product-info {
    padding: 15px;
}

.product-info h3 {
    font-size: 16px;
    margin-bottom: 5px;
    height: 40px;
    overflow: hidden;
}

.category {
    color: #999;
    font-size: 13px;
    margin-bottom: 10px;
}

.price {
    margin-bottom: 10px;
}

.old-price {
    text-decoration: line-through;
    color: #999;
    margin-right: 10px;
}

.new-price {
    color: #e74c3c;
    font-weight: bold;
    font-size: 18px;
}

.product-meta {
    display: flex;
    justify-content: space-between;
    font-size: 13px;
    color: #666;
}

.no-products {
    text-align: center;
    padding: 80px 20px;
    background: #f8f9fa;
    border-radius: 10px;
}

.no-products p {
    font-size: 18px;
    color: #666;
    margin: 10px 0;
}

.btn-primary {
    display: inline-block;
    margin-top: 20px;
    padding: 12px 30px;
    background: #4ECDC4;
    color: white;
    text-decoration: none;
    border-radius: 8px;
    font-weight: 600;
    transition: all 0.3s;
}

.btn-primary:hover {
    background: #3fb8af;
    transform: translateY(-2px);
}

.pagination {
    display: flex;
    justify-content: center;
    gap: 5px;
    margin-top: 30px;
}

.page-link {
    padding: 10px 15px;
    border: 1px solid #ddd;
    background: white;
    color: #333;
    text-decoration: none;
    border-radius: 5px;
    transition: all 0.3s;
}

.page-link:hover {
    background: #4ECDC4;
    color: white;
    border-color: #4ECDC4;
}

.page-link.active {
    background: #4ECDC4;
    color: white;
    border-color: #4ECDC4;
}

.page-dots {
    padding: 10px 5px;
    color: #999;
}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
