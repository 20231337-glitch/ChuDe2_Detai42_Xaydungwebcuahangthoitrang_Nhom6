<?php
$pageTitle = 'Danh sách sản phẩm';
require_once __DIR__ . '/../includes/header.php';

// Phân trang
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 12;
$offset = ($page - 1) * $perPage;

// Lọc theo danh mục
$categoryId = get('category_id');
$keyword = get('keyword');
$sort = get('sort', 'new');

// Build WHERE clause
$where = "p.status = 'active' AND p.deleted_at IS NULL";
$params = [];
$types = '';

if ($categoryId) {
    $where .= " AND p.category_id = ?";
    $params[] = $categoryId;
    $types .= 'i';
}

if ($keyword) {
    $where .= " AND (p.product_name LIKE ? OR p.description LIKE ?)";
    $searchTerm = '%' . $keyword . '%';
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $types .= 'ss';
}

// Order by
$orderBy = "p.created_at DESC";
switch ($sort) {
    case 'sold':
        $orderBy = "p.sold_count DESC";
        break;
    case 'view':
        $orderBy = "p.view_count DESC";
        break;
    case 'price_asc':
        $orderBy = "IF(p.sale_price > 0, p.sale_price, p.base_price) ASC";
        break;
    case 'price_desc':
        $orderBy = "IF(p.sale_price > 0, p.sale_price, p.base_price) DESC";
        break;
    case 'name':
        $orderBy = "p.product_name ASC";
        break;
}

// Đếm tổng số sản phẩm
$sqlCount = "SELECT COUNT(*) as total FROM products p WHERE $where";
$countData = fetchRow($sqlCount, $params, $types);
$totalRecords = $countData['total'];
$totalPages = getTotalPages($totalRecords, $perPage);

// Lấy danh sách sản phẩm
$sql = "
    SELECT p.*, pi.image_url, c.category_name
    FROM products p
    LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
    LEFT JOIN categories c ON p.category_id = c.category_id
    WHERE $where
    ORDER BY $orderBy
    LIMIT ?, ?
";
$params[] = $offset;
$params[] = $perPage;
$types .= 'ii';

$products = fetchData($sql, $params, $types);

// Lấy thông tin category nếu có
$categoryName = 'Tất cả sản phẩm';
if ($categoryId) {
    $catSql = "SELECT category_name FROM categories WHERE category_id = ?";
    $catData = fetchRow($catSql, [$categoryId], 'i');
    if ($catData) {
        $categoryName = $catData['category_name'];
    }
}

// Lấy danh sách categories cho filter
$categories = fetchData("SELECT category_id, category_name FROM categories WHERE status = 'active' AND deleted_at IS NULL ORDER BY category_name");

?>

<div class="container my-5">
    <!-- Page Header -->
    <div class="section-header">
        <h2 class="section-title"><?php echo e($categoryName); ?></h2>
        <?php if ($keyword): ?>
            <p class="section-subtitle">Kết quả tìm kiếm cho: "<?php echo e($keyword); ?>"</p>
        <?php endif; ?>
        <p class="section-subtitle">Tìm thấy <strong><?php echo $totalRecords; ?></strong> sản phẩm</p>
    </div>
    
    <!-- Filter & Sort Toolbar -->
    <div class="filter-toolbar">
        <div class="row g-3 align-items-center">
            <div class="col-md-3">
                <select class="form-select" onchange="updateFilter('category_id', this.value)">
                    <option value="">📂 Tất cả danh mục</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo $cat['category_id']; ?>" 
                            <?php echo $categoryId == $cat['category_id'] ? 'selected' : ''; ?>>
                            <?php echo e($cat['category_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <select class="form-select" onchange="updateFilter('sort', this.value)">
                    <option value="new" <?php echo $sort == 'new' ? 'selected' : ''; ?>>🆕 Mới nhất</option>
                    <option value="sold" <?php echo $sort == 'sold' ? 'selected' : ''; ?>>🔥 Bán chạy</option>
                    <option value="view" <?php echo $sort == 'view' ? 'selected' : ''; ?>>👁️ Xem nhiều</option>
                    <option value="price_asc" <?php echo $sort == 'price_asc' ? 'selected' : ''; ?>>💰 Giá tăng dần</option>
                    <option value="price_desc" <?php echo $sort == 'price_desc' ? 'selected' : ''; ?>>💎 Giá giảm dần</option>
                    <option value="name" <?php echo $sort == 'name' ? 'selected' : ''; ?>>🔤 Tên A-Z</option>
                </select>
            </div>
            <div class="col-md-6 text-end">
                <span class="text-muted">Hiển thị <?php echo count($products); ?> / <?php echo $totalRecords; ?> sản phẩm</span>
            </div>
        </div>
    </div>
    
    <!-- Product Grid -->
    <?php if (empty($products)): ?>
        <div class="text-center py-5">
            <i class="fas fa-box-open fa-4x text-muted mb-3"></i>
            <h3>Không tìm thấy sản phẩm nào!</h3>
            <p class="text-muted">Hãy thử tìm kiếm với từ khóa khác hoặc xem tất cả sản phẩm.</p>
            <a href="<?php echo BASE_URL; ?>/public/products/list.php" class="btn btn-primary mt-3">
                <i class="fas fa-th"></i> Xem tất cả sản phẩm
            </a>
        </div>
    <?php else: ?>
        <div class="row g-4 mt-2">
            <?php foreach ($products as $product): 
                // Logic tính discount: Nếu có sale_price và sale_price < base_price thì tính % giảm
                $discount = 0;
                if (isset($product['sale_price']) && $product['sale_price'] > 0 && $product['sale_price'] < $product['base_price']) {
                    $discount = round((($product['base_price'] - $product['sale_price']) / $product['base_price']) * 100);
                }
            
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="product-card">
                        <?php if ($discount > 0): ?>
                            <div class="product-badge">-<?php echo $discount; ?>%</div>
                        <?php endif; ?>
                        
                        <div class="product-image">
                            <img src="<?php echo $product['image_url'] ?: 'https://via.placeholder.com/300x300?text=No+Image'; ?>" 
                                 alt="<?php echo e($product['product_name']); ?>">
                            <div class="product-overlay">
                                <a href="<?php echo BASE_URL; ?>/public/products/detail.php?id=<?php echo $product['product_id']; ?>" 
                                   class="btn btn-primary btn-sm w-100">
                                    <i class="fas fa-eye"></i> Xem chi tiết
                                </a>
                            </div>
                        </div>
                        
                        <div class="product-info">
                            <div class="text-muted small mb-1">
                                <i class="fas fa-tag"></i> <?php echo e($product['category_name']); ?>
                            </div>
                            <h6 class="product-title">
                                <a href="<?php echo BASE_URL; ?>/public/products/detail.php?id=<?php echo $product['product_id']; ?>">
                                    <?php echo e($product['product_name']); ?>
                                </a>
                            </h6>
                            <div class="mb-2">
                                <span class="product-price"><?php echo formatMoney($product['base_price']); ?></span>
                                <?php if ((isset($product['sale_price']) && $product['sale_price'] > 0 ? $product['sale_price'] : $product['base_price']) > $product['base_price']): ?>
                                    <span class="product-old-price"><?php echo formatMoney((isset($product['sale_price']) && $product['sale_price'] > 0 ? $product['sale_price'] : $product['base_price'])); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="small text-muted">
                                <i class="fas fa-star text-warning"></i> 0.0
                                <span class="ms-2"><i class="fas fa-shopping-cart"></i> Đã bán <?php echo $product['sold_count']; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Pagination -->
        <div class="mt-5">
            <?php
            $urlParams = [];
            if ($categoryId) $urlParams[] = "category_id=$categoryId";
            if ($keyword) $urlParams[] = "keyword=" . urlencode($keyword);
            if ($sort != 'new') $urlParams[] = "sort=$sort";
            $baseUrl = '?';
            if (!empty($urlParams)) {
                $baseUrl .= implode('&', $urlParams);
            }
            echo renderPagination($page, $totalPages, $baseUrl);
            ?>
        </div>
    <?php endif; ?>
</div>

<style>
.filter-toolbar {
    background: white;
    padding: 1.5rem;
    border-radius: 15px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    margin-bottom: 2rem;
}

.pagination {
    display: flex;
    justify-content: center;
    gap: 8px;
    flex-wrap: wrap;
}

.page-link {
    display: inline-block;
    padding: 10px 16px;
    background: white;
    color: #2D3436;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s ease;
}

.page-link:hover {
    background: #FF6B6B;
    color: white;
    border-color: #FF6B6B;
    transform: translateY(-2px);
}

.page-link.active {
    background: #4ECDC4;
    color: white;
    border-color: #4ECDC4;
}

.page-dots {
    padding: 10px;
    color: #999;
}
</style>

<script>
function updateFilter(param, value) {
    const url = new URL(window.location);
    if (value) {
        url.searchParams.set(param, value);
    } else {
        url.searchParams.delete(param);
    }
    url.searchParams.delete('page'); // Reset về trang 1 khi filter
    window.location.href = url.toString();
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
