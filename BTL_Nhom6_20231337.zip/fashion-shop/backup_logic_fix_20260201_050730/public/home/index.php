<?php
$pageTitle = 'Trang chủ';
require_once __DIR__ . '/../includes/header.php';

// Lấy 8 sản phẩm bán chạy nhất
$sqlBestSeller = "
    SELECT p.*, pi.image_url, c.category_name
    FROM products p
    LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
    LEFT JOIN categories c ON p.category_id = c.category_id
    WHERE p.status = 'active' AND p.deleted_at IS NULL
    ORDER BY p.sold_count DESC
    LIMIT 8
";
$bestSellers = fetchData($sqlBestSeller);

// Lấy 8 sản phẩm mới nhất
$sqlNewProducts = "
    SELECT p.*, pi.image_url, c.category_name
    FROM products p
    LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
    LEFT JOIN categories c ON p.category_id = c.category_id
    WHERE p.status = 'active' AND p.deleted_at IS NULL
    ORDER BY p.created_at DESC
    LIMIT 8
";
$newProducts = fetchData($sqlNewProducts);

// Lấy 8 sản phẩm xem nhiều nhất
$sqlMostViewed = "
    SELECT p.*, pi.image_url, c.category_name
    FROM products p
    LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
    LEFT JOIN categories c ON p.category_id = c.category_id
    WHERE p.status = 'active' AND p.deleted_at IS NULL
    ORDER BY p.view_count DESC
    LIMIT 8
";
$mostViewed = fetchData($sqlMostViewed);


/**
 * Kiểm tra sản phẩm có giảm giá không
 */
function hasDiscount($product) {
    return isset($product['sale_price']) && 
           $product['sale_price'] > 0 && 
           $product['sale_price'] < $product['base_price'];
}

/**
 * Lấy giá hiển thị (giá sau giảm nếu có)
 */
function getDisplayPrice($product) {
    if (hasDiscount($product)) {
        return $product['sale_price'];
    }
    return $product['base_price'];
}

/**
 * Helper function để render product card
 */
function renderProductCard($product) {
    $imageUrl = !empty($product['image_url']) 
        ? BASE_URL . $product['image_url'] 
        : BASE_URL . '/assets/images/no-image.png';
    
    $hasDiscount = hasDiscount($product);
    $displayPrice = getDisplayPrice($product);
    $originalPrice = isset($product['price']) ? $product['price'] : 0;
    $discountPercent = 0;
    if (hasDiscount($product)) {
        $discountPercent = round((($product['base_price'] - $product['sale_price']) / $product['base_price']) * 100);
    }
    $avgRating = isset($product['average_rating']) ? $product['average_rating'] : 0;
    $soldCount = isset($product['sold_count']) ? $product['sold_count'] : 0;
    $viewCount = isset($product['view_count']) ? $product['view_count'] : 0;
    
    echo '<div class="product-card">';
    echo '<a href="' . BASE_URL . '/public/products/detail.php?id=' . $product['product_id'] . '">';
    echo '<div class="product-image">';
    echo '<img src="' . $imageUrl . '" alt="' . e($product['product_name']) . '">';
    
    if ($hasDiscount) {
        echo '<span class="badge-discount">-' . $discountPercent . '%</span>';
    }
    
    echo '</div>';
    echo '<div class="product-info">';
    echo '<h3>' . e($product['product_name']) . '</h3>';
    echo '<p class="category">' . e($product['category_name']) . '</p>';
    echo '<div class="price">';
    
    if ($hasDiscount) {
        echo '<span class="old-price">' . formatMoney($originalPrice) . '</span>';
        echo '<span class="new-price">' . formatMoney($displayPrice) . '</span>';
    } else {
        echo '<span class="new-price">' . formatMoney($displayPrice) . '</span>';
    }
    
    echo '</div>';
    echo '<div class="product-meta">';
    echo '<span>⭐ ' . number_format($avgRating, 1) . '</span>';
    echo '<span>Đã bán: ' . $soldCount . '</span>';
    echo '</div>';
    echo '</div>';
    echo '</a>';
    echo '</div>';
}

?>

<div class="container">
    <!-- Banner -->
    <section class="hero-banner">
        <div class="banner-content">
            <h2>🎉 CHÀO MỪNG ĐẾN VỚI FASHION SHOP</h2>
            <p>Khám phá bộ sưu tập thời trang mới nhất</p>
            <a href="<?php echo BASE_URL; ?>/public/products/list.php" class="btn-primary">Mua sắm ngay</a>
        </div>
    </section>
    
    <!-- Sản phẩm bán chạy -->
    <section class="product-section">
        <div class="section-header">
            <h2>🔥 SẢN PHẨM BÁN CHẠY</h2>
            <a href="<?php echo BASE_URL; ?>/public/products/list.php?sort=sold">Xem tất cả &raquo;</a>
        </div>
        
        <div class="product-grid">
            <?php 
            if (!empty($bestSellers)) {
                foreach ($bestSellers as $product) {
                    renderProductCard($product);
                }
            } else {
                echo '<p>Chưa có sản phẩm nào.</p>';
            }
            ?>
        </div>
    </section>
    
    <!-- Sản phẩm mới -->
    <section class="product-section">
        <div class="section-header">
            <h2>✨ SẢN PHẨM MỚI NHẤT</h2>
            <a href="<?php echo BASE_URL; ?>/public/products/list.php?sort=new">Xem tất cả &raquo;</a>
        </div>
        
        <div class="product-grid">
            <?php 
            if (!empty($newProducts)) {
                foreach ($newProducts as $product) {
                    renderProductCard($product);
                }
            } else {
                echo '<p>Chưa có sản phẩm nào.</p>';
            }
            ?>
        </div>
    </section>
    
    <!-- Sản phẩm xem nhiều -->
    <section class="product-section">
        <div class="section-header">
            <h2>👀 SẢN PHẨM XEM NHIỀU</h2>
            <a href="<?php echo BASE_URL; ?>/public/products/list.php?sort=view">Xem tất cả &raquo;</a>
        </div>
        
        <div class="product-grid">
            <?php 
            if (!empty($mostViewed)) {
                foreach ($mostViewed as $product) {
                    renderProductCard($product);
                }
            } else {
                echo '<p>Chưa có sản phẩm nào.</p>';
            }
            ?>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
