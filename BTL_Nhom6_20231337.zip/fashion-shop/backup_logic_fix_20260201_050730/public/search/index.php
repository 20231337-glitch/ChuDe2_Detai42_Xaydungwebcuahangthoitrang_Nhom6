<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/constants.php';
require_once '../../includes/pagination.php';

$keyword = isset($_GET['q']) ? trim($_GET['q']) : '';
$category_id = isset($_GET['category']) ? intval($_GET['category']) : 0;
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'relevance';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = 20;
$offset = ($page - 1) * $per_page;

// Lấy danh mục để filter
$categories = mysqli_query($conn, 
    "SELECT * FROM categories WHERE status='active' AND deleted_at IS NULL ORDER BY category_name"
);

$products = [];
$total_results = 0;

if ($keyword != '') {
    // Build query tìm kiếm
    $sql = "SELECT p.*, pi.image_url, c.category_name";
    
    // Thêm relevance nếu sort theo relevance
    if ($sort == 'relevance') {
        $sql .= ", MATCH(p.product_name, p.description) AGAINST('" . mysqli_real_escape_string($conn, $keyword) . "' IN NATURAL LANGUAGE MODE) as relevance";
    }
    
    $sql .= " FROM products p
              LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
              LEFT JOIN categories c ON p.category_id = c.category_id
              WHERE p.status = 'active' AND p.deleted_at IS NULL";
    
    // Điều kiện tìm kiếm
    $sql .= " AND (p.product_name LIKE '%" . mysqli_real_escape_string($conn, $keyword) . "%' 
                   OR p.description LIKE '%" . mysqli_real_escape_string($conn, $keyword) . "%')";
    
    // Filter theo category
    if ($category_id > 0) {
        $sql .= " AND p.category_id = $category_id";
    }
    
    // Sắp xếp
    switch ($sort) {
        case 'price_asc':
            $sql .= " ORDER BY p.base_price ASC";
            break;
        case 'price_desc':
            $sql .= " ORDER BY p.base_price DESC";
            break;
        case 'name':
            $sql .= " ORDER BY p.product_name ASC";
            break;
        case 'newest':
            $sql .= " ORDER BY p.created_at DESC";
            break;
        case 'popular':
            $sql .= " ORDER BY p.sold_count DESC";
            break;
        default: // relevance
            $sql .= " ORDER BY relevance DESC, p.sold_count DESC";
    }
    
    $sql .= " LIMIT $offset, $per_page";
    
    $result = mysqli_query($conn, $sql);
    
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $products[] = $row;
        }
    }
    
    // Đếm tổng số kết quả
    $count_sql = "SELECT COUNT(*) as total FROM products p
                  WHERE p.status = 'active' AND p.deleted_at IS NULL
                  AND (p.product_name LIKE '%" . mysqli_real_escape_string($conn, $keyword) . "%' 
                       OR p.description LIKE '%" . mysqli_real_escape_string($conn, $keyword) . "%')";
    
    if ($category_id > 0) {
        $count_sql .= " AND p.category_id = $category_id";
    }
    
    $count_result = mysqli_query($conn, $count_sql);
    $total_results = mysqli_fetch_assoc($count_result)['total'];
}

$total_pages = ceil($total_results / $per_page);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tìm kiếm: <?php echo htmlspecialchars($keyword); ?> - Fashion Shop</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f7fa; }
        
        .container { max-width: 1200px; margin: 20px auto; padding: 0 20px; }
        
        .search-header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .search-header h1 {
            color: #2c3e50;
            margin-bottom: 15px;
        }
        
        .search-form {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .search-form input[type="text"] {
            flex: 1;
            min-width: 250px;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 25px;
            font-size: 15px;
        }
        
        .search-form button {
            padding: 12px 30px;
            background: #3498db;
            color: white;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-weight: 600;
        }
        
        .search-form button:hover { background: #2980b9; }
        
        .filters {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .filters select {
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        
        .result-info {
            color: #7f8c8d;
            font-size: 14px;
        }
        
        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .product-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.2);
        }
        
        .product-image {
            width: 100%;
            height: 250px;
            object-fit: cover;
            background: #f0f0f0;
        }
        
        .product-info {
            padding: 15px;
        }
        
        .product-name {
            font-size: 16px;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 8px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        
        .product-category {
            font-size: 12px;
            color: #95a5a6;
            margin-bottom: 10px;
        }
        
        .product-price {
            font-size: 20px;
            font-weight: bold;
            color: #e74c3c;
            margin-bottom: 10px;
        }
        
        .product-stats {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #7f8c8d;
        }
        
        .btn-view {
            display: block;
            text-align: center;
            padding: 10px;
            background: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 10px;
            font-weight: 600;
        }
        
        .btn-view:hover { background: #2980b9; }
        
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin: 30px 0;
        }
        
        .pagination a, .pagination span {
            padding: 10px 15px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-decoration: none;
            color: #2c3e50;
        }
        
        .pagination a:hover {
            background: #3498db;
            color: white;
            border-color: #3498db;
        }
        
        .pagination .current {
            background: #3498db;
            color: white;
            border-color: #3498db;
        }
        
        .no-results {
            background: white;
            padding: 60px 20px;
            border-radius: 10px;
            text-align: center;
        }
        
        .no-results h2 {
            color: #7f8c8d;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="search-header">
            <h1>🔍 Tìm kiếm sản phẩm</h1>
            <form class="search-form" method="GET">
                <input type="text" name="q" value="<?php echo htmlspecialchars($keyword); ?>" 
                       placeholder="Nhập tên sản phẩm..." required>
                <button type="submit">Tìm kiếm</button>
            </form>
        </div>
        
        <?php if ($keyword != ''): ?>
        <div class="filters">
            <div class="result-info">
                Tìm thấy <strong><?php echo $total_results; ?></strong> kết quả cho 
                <strong>"<?php echo htmlspecialchars($keyword); ?>"</strong>
            </div>
            
            <form method="GET" style="display: flex; gap: 10px;">
                <input type="hidden" name="q" value="<?php echo htmlspecialchars($keyword); ?>">
                
                <select name="category" onchange="this.form.submit()">
                    <option value="0">Tất cả danh mục</option>
                    <?php while ($cat = mysqli_fetch_assoc($categories)): ?>
                        <option value="<?php echo $cat['category_id']; ?>" 
                                <?php echo $category_id == $cat['category_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($cat['category_name']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
                
                <select name="sort" onchange="this.form.submit()">
                    <option value="relevance" <?php echo $sort=='relevance'?'selected':''; ?>>Liên quan nhất</option>
                    <option value="newest" <?php echo $sort=='newest'?'selected':''; ?>>Mới nhất</option>
                    <option value="popular" <?php echo $sort=='popular'?'selected':''; ?>>Bán chạy</option>
                    <option value="price_asc" <?php echo $sort=='price_asc'?'selected':''; ?>>Giá thấp → cao</option>
                    <option value="price_desc" <?php echo $sort=='price_desc'?'selected':''; ?>>Giá cao → thấp</option>
                    <option value="name" <?php echo $sort=='name'?'selected':''; ?>>Tên A-Z</option>
                </select>
            </form>
        </div>
        
        <?php if (count($products) > 0): ?>
            <div class="products-grid">
                <?php foreach ($products as $product): ?>
                <div class="product-card">
                    <?php if ($product['image_url']): ?>
                        <img src="<?php echo $product['image_url']; ?>" class="product-image" 
                             alt="<?php echo htmlspecialchars($product['product_name']); ?>">
                    <?php else: ?>
                        <div class="product-image"></div>
                    <?php endif; ?>
                    
                    <div class="product-info">
                        <div class="product-category"><?php echo htmlspecialchars($product['category_name']); ?></div>
                        <div class="product-name"><?php echo htmlspecialchars($product['product_name']); ?></div>
                        <div class="product-price"><?php echo number_format($product['base_price']); ?>đ</div>
                        
                        <div class="product-stats">
                            <span>👁️ <?php echo $product['view_count']; ?> lượt xem</span>
                            <span>🛒 <?php echo $product['sold_count']; ?> đã bán</span>
                        </div>
                        
                        <a href="/fashion-shop/public/products/detail.php?id=<?php echo $product['product_id']; ?>" 
                           class="btn-view">Xem chi tiết</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="?q=<?php echo urlencode($keyword); ?>&category=<?php echo $category_id; ?>&sort=<?php echo $sort; ?>&page=<?php echo ($page-1); ?>">
                        ← Trước
                    </a>
                <?php endif; ?>
                
                <?php for ($i = max(1, $page-2); $i <= min($total_pages, $page+2); $i++): ?>
                    <?php if ($i == $page): ?>
                        <span class="current"><?php echo $i; ?></span>
                    <?php else: ?>
                        <a href="?q=<?php echo urlencode($keyword); ?>&category=<?php echo $category_id; ?>&sort=<?php echo $sort; ?>&page=<?php echo $i; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endif; ?>
                <?php endfor; ?>
                
                <?php if ($page < $total_pages): ?>
                    <a href="?q=<?php echo urlencode($keyword); ?>&category=<?php echo $category_id; ?>&sort=<?php echo $sort; ?>&page=<?php echo ($page+1); ?>">
                        Sau →
                    </a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            
        <?php else: ?>
            <div class="no-results">
                <h2>😔 Không tìm thấy sản phẩm nào</h2>
                <p>Thử tìm kiếm với từ khóa khác hoặc chọn danh mục khác</p>
            </div>
        <?php endif; ?>
        
        <?php endif; ?>
    </div>
</body>
</html>

<?php
mysqli_close($conn);
?>
