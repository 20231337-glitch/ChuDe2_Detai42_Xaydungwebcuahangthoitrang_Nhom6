<?php
session_start();
require_once __DIR__ . '/../../config/database.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    header('Location: /fashion-shop/public/auth/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;

// Lấy thông tin đơn hàng
$stmt = $conn->prepare("
    SELECT * FROM orders 
    WHERE order_id = ? AND user_id = ?
");
$stmt->bind_param("ii", $order_id, $user_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    header('Location: /fashion-shop/public/home/');
    exit;
}

// Lấy chi tiết đơn hàng
$stmt = $conn->prepare("
    SELECT * FROM order_details 
    WHERE order_id = ?
");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order_details = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đặt hàng thành công - Fashion Shop</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            padding: 40px 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .success-icon {
            font-size: 80px;
            color: #28a745;
            margin-bottom: 20px;
        }
        h1 {
            color: #28a745;
            margin-bottom: 10px;
        }
        .order-info {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 6px;
            margin: 30px 0;
            text-align: left;
        }
        .order-info h2 {
            color: #333;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #ddd;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        .info-row:last-child {
            border-bottom: none;
        }
        .info-row.total {
            font-size: 20px;
            font-weight: bold;
            color: #dc3545;
            border-top: 2px solid #333;
            padding-top: 15px;
        }
        .products-list {
            margin: 20px 0;
        }
        .product-item {
            padding: 10px;
            background: white;
            margin-bottom: 10px;
            border-radius: 4px;
            display: flex;
            justify-content: space-between;
        }
        .btn {
            display: inline-block;
            padding: 12px 30px;
            margin: 10px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: bold;
        }
        .btn-primary {
            background: #007bff;
            color: white;
        }
        .btn-primary:hover {
            background: #0056b3;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        .btn-secondary:hover {
            background: #545b62;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="success-icon">✅</div>
    <h1>Đặt hàng thành công!</h1>
    <p style="color: #666; margin-bottom: 30px;">
        Cảm ơn bạn đã mua hàng tại Fashion Shop. Đơn hàng của bạn đang được xử lý.
    </p>

    <div class="order-info">
        <h2>Thông tin đơn hàng</h2>
        
        <div class="info-row">
            <span><strong>Mã đơn hàng:</strong></span>
            <span style="color: #007bff; font-weight: bold;">#<?= $order['order_id'] ?></span>
        </div>
        
        <div class="info-row">
            <span><strong>Người nhận:</strong></span>
            <span><?= htmlspecialchars($order['fullname']) ?></span>
        </div>
        
        <div class="info-row">
            <span><strong>Số điện thoại:</strong></span>
            <span><?= htmlspecialchars($order['phone']) ?></span>
        </div>
        
        <div class="info-row">
            <span><strong>Địa chỉ:</strong></span>
            <span><?= htmlspecialchars($order['address']) ?></span>
        </div>
        
        <div class="info-row">
            <span><strong>Phương thức thanh toán:</strong></span>
            <span><?= $order['payment_method'] == 'COD' ? 'Thanh toán khi nhận hàng' : 'Chuyển khoản' ?></span>
        </div>
        
        <div class="info-row">
            <span><strong>Trạng thái:</strong></span>
            <span style="color: #ffc107; font-weight: bold;">Đang xử lý</span>
        </div>

        <h3 style="margin-top: 20px; margin-bottom: 10px;">Sản phẩm đã đặt:</h3>
        <div class="products-list">
            <?php foreach ($order_details as $item): ?>
                <div class="product-item">
                    <div>
                        <strong><?= htmlspecialchars($item['product_name']) ?></strong><br>
                        <small>Size: <?= htmlspecialchars($item['size_name']) ?> | 
                               Màu: <?= htmlspecialchars($item['color_name']) ?> | 
                               SL: <?= $item['quantity'] ?></small>
                    </div>
                    <div style="text-align: right;">
                        <strong><?= number_format($item['subtotal'], 0, ',', '.') ?>đ</strong>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="info-row">
            <span><strong>Tạm tính:</strong></span>
            <span><?= number_format($order['total_amount'], 0, ',', '.') ?>đ</span>
        </div>
        
        <?php if ($order['discount_amount'] > 0): ?>
            <div class="info-row" style="color: #28a745;">
                <span><strong>Giảm giá:</strong></span>
                <span>-<?= number_format($order['discount_amount'], 0, ',', '.') ?>đ</span>
            </div>
        <?php endif; ?>
        
        <div class="info-row total">
            <span>Tổng cộng:</span>
            <span><?= number_format($order['final_amount'], 0, ',', '.') ?>đ</span>
        </div>
    </div>

    <p style="color: #666; margin-bottom: 20px;">
        Chúng tôi sẽ liên hệ với bạn để xác nhận đơn hàng trong thời gian sớm nhất.<br>
        Bạn có thể theo dõi đơn hàng trong mục "Đơn hàng của tôi".
    </p>

    <div>
        <a href="/fashion-shop/public/account/orders.php" class="btn btn-primary">
            Xem đơn hàng của tôi
        </a>
        <a href="/fashion-shop/public/home/" class="btn btn-secondary">
            Tiếp tục mua sắm
        </a>
    </div>
</div>

</body>
</html>
