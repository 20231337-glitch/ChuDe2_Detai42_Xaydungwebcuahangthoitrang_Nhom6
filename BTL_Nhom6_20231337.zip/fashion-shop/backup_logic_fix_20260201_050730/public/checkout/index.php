<?php
session_start();
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    header('Location: /fashion-shop/public/auth/login.php?redirect=/fashion-shop/public/checkout/');
    exit;
}

$user_id = $_SESSION['user_id'];
$errors = [];
$success = '';

// Lấy thông tin user
$stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ? AND deleted_at IS NULL");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Lấy giỏ hàng
$query = "
    SELECT 
        c.cart_id, c.variant_id, c.quantity,
        p.product_id, p.product_name, p.sale_price, p.base_price, p.slug,
        s.size_name, col.color_name,
        pv.stock_quantity,
        pi.image_url,
        (IF(p.sale_price > 0, p.sale_price, p.base_price) * c.quantity) as subtotal
    FROM cart c
    JOIN product_variants pv ON c.variant_id = pv.variant_id
    JOIN products p ON pv.product_id = p.product_id AND p.status = 'active' AND p.deleted_at IS NULL
    JOIN sizes s ON pv.size_id = s.size_id
    JOIN colors col ON pv.color_id = col.color_id
    LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
    WHERE c.user_id = ?
    ORDER BY c.added_at DESC
";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$cart_items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Nếu giỏ hàng trống
if (empty($cart_items)) {
    header('Location: /fashion-shop/public/cart/');
    exit;
}

// Tính tổng tiền
$total_amount = 0;
foreach ($cart_items as $item) {
    $total_amount += $item['subtotal'];
}

// Xử lý áp dụng mã giảm giá
$coupon = null;
$discount_amount = 0;
$final_amount = $total_amount;

if (isset($_POST['apply_coupon'])) {
    $coupon_code = trim($_POST['coupon_code']);
    
    // Kiểm tra mã giảm giá
    $stmt = $conn->prepare("
        SELECT * FROM coupons
        WHERE coupon_code = ?
        AND status = 'active'
        AND expiry_date >= CURDATE()
        AND (max_uses IS NULL OR used_count < max_uses)
    ");
    $stmt->bind_param("s", $coupon_code);
    $stmt->execute();
    $coupon = $stmt->get_result()->fetch_assoc();
    
    if ($coupon) {
        // Kiểm tra user đã dùng mã này chưa
        $stmt = $conn->prepare("
            SELECT COUNT(*) as times_used
            FROM coupon_usage
            WHERE coupon_id = ? AND user_id = ?
        ");
        $stmt->bind_param("ii", $coupon['coupon_id'], $user_id);
        $stmt->execute();
        $usage = $stmt->get_result()->fetch_assoc();
        
        if ($usage['times_used'] >= $coupon['max_uses_per_user']) {
            $errors[] = "Bạn đã sử dụng mã giảm giá này rồi!";
            $coupon = null;
        } elseif ($total_amount < $coupon['min_order_value']) {
            $errors[] = "Đơn hàng phải từ " . number_format($coupon['min_order_value'], 0, ',', '.') . "đ mới được dùng mã này!";
            $coupon = null;
        } else {
            // Tính giảm giá
            if ($coupon['discount_type'] == 'percent') {
                $discount_amount = ($total_amount * $coupon['discount_value']) / 100;
            } else {
                $discount_amount = $coupon['discount_value'];
            }
            $final_amount = $total_amount - $discount_amount;
            $success = "Áp dụng mã giảm giá thành công!";
        }
    } else {
        $errors[] = "Mã giảm giá không hợp lệ hoặc đã hết hạn!";
    }
}

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thanh toán - Fashion Shop</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 2px solid #007bff;
        }
        .alert {
            padding: 12px 20px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .checkout-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
        }
        .cart-items {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 6px;
        }
        .cart-item {
            display: flex;
            gap: 15px;
            padding: 15px;
            background: white;
            margin-bottom: 15px;
            border-radius: 4px;
            border: 1px solid #ddd;
        }
        .item-image {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 4px;
        }
        .item-info {
            flex: 1;
        }
        .item-info h3 {
            font-size: 16px;
            color: #333;
            margin-bottom: 5px;
        }
        .item-info p {
            color: #666;
            font-size: 14px;
            margin: 3px 0;
        }
        .item-price {
            text-align: right;
        }
        .item-price .price {
            font-size: 18px;
            font-weight: bold;
            color: #dc3545;
        }
        .checkout-form {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 6px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #333;
        }
        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }
        .coupon-section {
            background: #fff;
            padding: 15px;
            border: 2px dashed #28a745;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        .coupon-section h3 {
            color: #28a745;
            margin-bottom: 10px;
        }
        .coupon-form {
            display: flex;
            gap: 10px;
        }
        .coupon-form input {
            flex: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .coupon-form button {
            padding: 10px 20px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
        }
        .coupon-form button:hover {
            background: #218838;
        }
        .order-summary {
            background: white;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        .summary-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        .summary-row.total {
            border-top: 2px solid #333;
            border-bottom: none;
            font-size: 20px;
            font-weight: bold;
            color: #dc3545;
            padding-top: 15px;
        }
        .btn {
            padding: 15px 30px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            width: 100%;
        }
        .btn-primary {
            background: #007bff;
            color: white;
        }
        .btn-primary:hover {
            background: #0056b3;
        }
        .btn-back {
            display: inline-block;
            margin-bottom: 20px;
            color: #007bff;
            text-decoration: none;
        }
        .btn-back:hover {
            text-decoration: underline;
        }
        @media (max-width: 768px) {
            .checkout-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <a href="/fashion-shop/public/cart/" class="btn-back">← Quay lại giỏ hàng</a>
    
    <h1>🛒 Thanh toán</h1>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <?php foreach ($errors as $error): ?>
                <p>❌ <?= htmlspecialchars($error) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success">
            <p>✅ <?= htmlspecialchars($success) ?></p>
        </div>
    <?php endif; ?>

    <div class="checkout-grid">
        <!-- Danh sách sản phẩm -->
        <div>
            <h2 style="margin-bottom: 15px;">Sản phẩm trong giỏ</h2>
            <div class="cart-items">
                <?php foreach ($cart_items as $item): ?>
                    <div class="cart-item">
                        <img src="<?= htmlspecialchars($item['image_url'] ?: '/fashion-shop/assets/images/no-image.jpg') ?>" 
                             alt="<?= htmlspecialchars($item['product_name']) ?>" 
                             class="item-image">
                        <div class="item-info">
                            <h3><?= htmlspecialchars($item['product_name']) ?></h3>
                            <p>Size: <strong><?= htmlspecialchars($item['size_name']) ?></strong> | 
                               Màu: <strong><?= htmlspecialchars($item['color_name']) ?></strong></p>
                            <p>Số lượng: <strong><?= $item['quantity'] ?></strong></p>
                            <p>Đơn giá: <?= number_format($item['sale_price'] > 0 ? $item['sale_price'] : $item['base_price'], 0, ',', '.') ?>đ</p>
                        </div>
                        <div class="item-price">
                            <span class="price"><?= number_format($item['subtotal'], 0, ',', '.') ?>đ</span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Form thanh toán -->
        <div>
            <div class="checkout-form">
                <h2 style="margin-bottom: 20px;">Thông tin giao hàng</h2>
                
                <form method="POST" action="process.php">
                    <div class="form-group">
                        <label>Họ tên người nhận *</label>
                        <input type="text" name="fullname" value="<?= htmlspecialchars($user['fullname']) ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Số điện thoại *</label>
                        <input type="tel" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Địa chỉ giao hàng *</label>
                        <textarea name="address" required><?= htmlspecialchars($user['address']) ?></textarea>
                    </div>

                    <div class="form-group">
                        <label>Ghi chú (tùy chọn)</label>
                        <textarea name="note" placeholder="Ví dụ: Giao giờ hành chính"></textarea>
                    </div>

                    <div class="form-group">
                        <label>Phương thức thanh toán *</label>
                        <select name="payment_method" required>
                            <option value="COD">Thanh toán khi nhận hàng (COD)</option>
                            <option value="Banking">Chuyển khoản ngân hàng</option>
                        </select>
                    </div>

                    <!-- Mã giảm giá -->
                    <div class="coupon-section">
                        <h3>🎁 Mã giảm giá</h3>
                        <form method="POST" class="coupon-form">
                            <input type="text" name="coupon_code" placeholder="Nhập mã giảm giá" 
                                   value="<?= $coupon ? htmlspecialchars($coupon['coupon_code']) : '' ?>">
                            <button type="submit" name="apply_coupon">Áp dụng</button>
                        </form>
                    </div>

                    <!-- Tổng tiền -->
                    <div class="order-summary">
                        <h3 style="margin-bottom: 15px;">Tóm tắt đơn hàng</h3>
                        <div class="summary-row">
                            <span>Tạm tính:</span>
                            <span><?= number_format($total_amount, 0, ',', '.') ?>đ</span>
                        </div>
                        <?php if ($coupon): ?>
                            <div class="summary-row" style="color: #28a745;">
                                <span>Giảm giá (<?= htmlspecialchars($coupon['coupon_code']) ?>):</span>
                                <span>-<?= number_format($discount_amount, 0, ',', '.') ?>đ</span>
                            </div>
                        <?php endif; ?>
                        <div class="summary-row total">
                            <span>Tổng cộng:</span>
                            <span><?= number_format($final_amount, 0, ',', '.') ?>đ</span>
                        </div>
                    </div>

                    <!-- Hidden fields -->
                    <input type="hidden" name="total_amount" value="<?= $total_amount ?>">
                    <input type="hidden" name="discount_amount" value="<?= $discount_amount ?>">
                    <input type="hidden" name="final_amount" value="<?= $final_amount ?>">
                    <?php if ($coupon): ?>
                        <input type="hidden" name="coupon_id" value="<?= $coupon['coupon_id'] ?>">
                    <?php endif; ?>

                    <button type="submit" name="checkout" class="btn btn-primary">
                        Đặt hàng
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

</body>
</html>
