<?php
session_start();
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || !isset($_POST['checkout'])) {
    header('Location: /fashion-shop/public/checkout/');
    exit;
}

$user_id = $_SESSION['user_id'];
$errors = [];

// Lấy dữ liệu từ form
$fullname = trim($_POST['fullname']);
$phone = trim($_POST['phone']);
$address = trim($_POST['address']);
$note = trim($_POST['note'] ?? '');
$payment_method = $_POST['payment_method'];
$total_amount = floatval($_POST['total_amount']);
$discount_amount = floatval($_POST['discount_amount']);
$final_amount = floatval($_POST['final_amount']);
$coupon_id = isset($_POST['coupon_id']) ? intval($_POST['coupon_id']) : null;

// Validate dữ liệu
if (empty($fullname) || empty($phone) || empty($address)) {
    $_SESSION['error'] = "Vui lòng điền đầy đủ thông tin!";
    header('Location: /fashion-shop/public/checkout/');
    exit;
}

if (!in_array($payment_method, ['COD', 'Banking'])) {
    $_SESSION['error'] = "Phương thức thanh toán không hợp lệ!";
    header('Location: /fashion-shop/public/checkout/');
    exit;
}

// ============================================================
// BẮT ĐẦU TRANSACTION TẠO ĐƠN HÀNG
// ============================================================

try {
    $conn->begin_transaction();
    
    // BƯỚC 1: TẠO ĐƠN HÀNG
    $stmt = $conn->prepare("
        INSERT INTO orders (
            user_id, fullname, phone, address, note,
            total_amount, coupon_id, discount_amount, final_amount,
            payment_method, payment_status, order_status, order_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'unpaid', 'processing', NOW())
    ");
    $stmt->bind_param(
        "issssdddds",
        $user_id, $fullname, $phone, $address, $note,
        $total_amount, $coupon_id, $discount_amount, $final_amount,
        $payment_method
    );
    $stmt->execute();
    $order_id = $conn->insert_id;
    
    // BƯỚC 2: LẤY DANH SÁCH SẢN PHẨM TRONG GIỎ
    $query = "
        SELECT 
            c.variant_id, c.quantity,
            p.product_id, p.product_name, p.sale_price, p.base_price,
            s.size_name, col.color_name,
            pv.stock_quantity
        FROM cart c
        JOIN product_variants pv ON c.variant_id = pv.variant_id AND pv.status = 'in_stock'
        JOIN products p ON pv.product_id = p.product_id AND p.status = 'active' AND p.deleted_at IS NULL
        JOIN sizes s ON pv.size_id = s.size_id
        JOIN colors col ON pv.color_id = col.color_id
        WHERE c.user_id = ?
    ";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $cart_items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    if (empty($cart_items)) {
        throw new Exception("Giỏ hàng trống!");
    }
    
    // BƯỚC 3: KIỂM TRA TỒN KHO & TẠO CHI TIẾT ĐƠN HÀNG
    foreach ($cart_items as $item) {
        // Kiểm tra tồn kho
        if ($item['stock_quantity'] < $item['quantity']) {
            throw new Exception("Sản phẩm '{$item['product_name']}' không đủ hàng!");
        }
        
        // Kiểm tra stock > 0 (double check)
        if ($item['stock_quantity'] <= 0) {
            throw new Exception("Sản phẩm '{$item['product_name']}' đã hết hàng!");
        }
        
        // Tạo chi tiết đơn hàng (SNAPSHOT)
        $subtotal = ($item['sale_price'] > 0 ? $item['sale_price'] : $item['base_price']) * $item['quantity'];
        $stmt = $conn->prepare("
            INSERT INTO order_details (
                order_id, variant_id, 
                product_name, size_name, color_name, 
                price, quantity, subtotal
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param(
            "iisssdid",
            $order_id, $item['variant_id'],
            $item['product_name'], $item['size_name'], $item['color_name'],
            ($item['sale_price'] > 0 ? $item['sale_price'] : $item['base_price']), $item['quantity'], $subtotal
        );
        $stmt->execute();
        
        // BƯỚC 4: TRỪ TỒN KHO
        $stmt = $conn->prepare("
            UPDATE product_variants 
            SET stock_quantity = stock_quantity - ?
            WHERE variant_id = ?
        ");
        $stmt->bind_param("ii", $item['quantity'], $item['variant_id']);
        $stmt->execute();
        
        // Cập nhật trạng thái nếu hết hàng
        $stmt = $conn->prepare("
            UPDATE product_variants 
            SET status = 'out_of_stock'
            WHERE variant_id = ? AND stock_quantity = 0
        ");
        $stmt->bind_param("i", $item['variant_id']);
        $stmt->execute();
        
        // BƯỚC 5: TĂNG SỐ LƯỢNG ĐÃ BÁN
        $stmt = $conn->prepare("
            UPDATE products 
            SET sold_count = sold_count + ?
            WHERE product_id = ?
        ");
        $stmt->bind_param("ii", $item['quantity'], $item['product_id']);
        $stmt->execute();
    }
    
    // BƯỚC 6: CẬP NHẬT MÃ GIẢM GIÁ (NẾU CÓ)
    if ($coupon_id) {
        $stmt = $conn->prepare("
            UPDATE coupons 
            SET used_count = used_count + 1 
            WHERE coupon_id = ?
        ");
        $stmt->bind_param("i", $coupon_id);
        $stmt->execute();
        
        $stmt = $conn->prepare("
            INSERT INTO coupon_usage (coupon_id, user_id, order_id, used_at)
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->bind_param("iii", $coupon_id, $user_id, $order_id);
        $stmt->execute();
    }
    
    // BƯỚC 7: XÓA GIỎ HÀNG
    $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    
    // BƯỚC 8: TẠO THÔNG BÁO
    $message = "Đơn hàng #{$order_id} đã được tạo thành công và đang được xử lý.";
    $link = "/fashion-shop/public/account/order_detail.php?id={$order_id}";
    $stmt = $conn->prepare("
        INSERT INTO notifications (user_id, type, title, message, link, created_at)
        VALUES (?, 'order_update', 'Đơn hàng đã được tạo', ?, ?, NOW())
    ");
    $stmt->bind_param("iss", $user_id, $message, $link);
    $stmt->execute();
    
    // COMMIT TRANSACTION
    $conn->commit();
    
    // Redirect đến trang thành công
    $_SESSION['success'] = "Đặt hàng thành công! Mã đơn hàng: #{$order_id}";
    header("Location: success.php?order_id={$order_id}");
    exit;
    
} catch (Exception $e) {
    // ROLLBACK nếu có lỗi
    $conn->rollback();
    
    $_SESSION['error'] = "Đặt hàng thất bại: " . $e->getMessage();
    header('Location: /fashion-shop/public/checkout/');
    exit;
}
