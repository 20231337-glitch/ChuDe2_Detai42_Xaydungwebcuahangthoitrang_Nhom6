<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {
    header('Location: ../auth/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$order_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Kiểm tra quyền sở hữu đơn hàng
$sql = "SELECT o.*, c.coupon_code 
        FROM orders o
        LEFT JOIN coupons c ON o.coupon_id = c.coupon_id
        WHERE o.order_id = ? AND o.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $order_id, $user_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    die('<h1 style="text-align:center;color:red;margin-top:50px;">Không tìm thấy đơn hàng hoặc bạn không có quyền xem!</h1>');
}

// Lấy chi tiết sản phẩm trong đơn
$sql = "SELECT 
            od.*,
            pv.variant_id,
            p.product_id,
            p.slug,
            pi.image_url
        FROM order_details od
        LEFT JOIN product_variants pv ON od.variant_id = pv.variant_id
        LEFT JOIN products p ON pv.product_id = p.product_id
        LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
        WHERE od.order_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$details = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Trạng thái
$status_labels = [
    'processing' => 'Đang xử lý',
    'confirmed' => 'Đã xác nhận',
    'shipping' => 'Đang giao',
    'completed' => 'Hoàn thành',
    'cancelled' => 'Đã hủy'
];

$payment_method_labels = [
    'cod' => 'Thanh toán khi nhận hàng (COD)',
    'bank' => 'Chuyển khoản ngân hàng',
    'momo' => 'Ví MoMo',
    'vnpay' => 'VNPay'
];
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi tiết đơn hàng #<?= $order_id ?> - Fashion Shop</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; }
        .container { max-width: 1000px; margin: 0 auto; padding: 30px 20px; }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #0066CC;
            text-decoration: none;
            font-weight: 600;
        }
        .back-link:hover { text-decoration: underline; }
        h1 { color: #333; margin-bottom: 10px; }
        .order-status {
            display: inline-block;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 600;
            color: white;
            margin-bottom: 30px;
        }
        .section {
            background: white;
            border-radius: 8px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .section-title {
            font-size: 18px;
            font-weight: bold;
            color: #333;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #0066CC;
        }
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        .info-item {
            display: flex;
            flex-direction: column;
        }
        .info-label {
            font-size: 13px;
            color: #666;
            margin-bottom: 5px;
            text-transform: uppercase;
        }
        .info-value {
            font-size: 16px;
            color: #333;
            font-weight: 600;
        }
        .product-list { display: grid; gap: 15px; }
        .product-item {
            display: grid;
            grid-template-columns: 80px 1fr auto;
            gap: 15px;
            padding: 15px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .product-item:hover {
            border-color: #0066CC;
            box-shadow: 0 2px 8px rgba(0,102,204,0.1);
        }
        .product-image {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 5px;
        }
        .product-info h3 {
            font-size: 16px;
            margin-bottom: 5px;
            color: #333;
        }
        .product-variant {
            font-size: 14px;
            color: #666;
            margin-bottom: 5px;
        }
        .product-price-qty {
            text-align: right;
        }
        .product-price {
            font-size: 16px;
            color: #00AA00;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .product-quantity {
            font-size: 14px;
            color: #666;
        }
        .total-section {
            border-top: 2px solid #e0e0e0;
            padding-top: 20px;
            margin-top: 20px;
        }
        .total-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            font-size: 16px;
        }
        .total-row.final {
            font-size: 20px;
            font-weight: bold;
            color: #00AA00;
            padding-top: 10px;
            border-top: 2px dashed #e0e0e0;
        }
        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 15px;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
            transition: all 0.3s;
        }
        .btn-danger { background: #CC0000; color: white; }
        .btn-danger:hover { background: #990000; }
    </style>
</head>
<body>
    <div class="container">
        <a href="orders.php" class="back-link">← Quay lại danh sách đơn hàng</a>
        
        <h1>📦 Chi tiết đơn hàng #<?= $order_id ?></h1>
        
        <?php
        $status_colors = [
            'processing' => '#FFA500',
            'confirmed' => '#0066CC',
            'shipping' => '#9933FF',
            'completed' => '#00AA00',
            'cancelled' => '#CC0000'
        ];
        ?>
        <span class="order-status" style="background: <?= $status_colors[$order['order_status']] ?>">
            <?= $status_labels[$order['order_status']] ?>
        </span>

        <!-- Thông tin đơn hàng -->
        <div class="section">
            <div class="section-title">📋 Thông tin đơn hàng</div>
            <div class="info-grid">
                <div class="info-item">
                    <span class="info-label">Ngày đặt hàng</span>
                    <span class="info-value"><?= date('d/m/Y H:i', strtotime($order['order_date'])) ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Phương thức thanh toán</span>
                    <span class="info-value"><?= $payment_method_labels[$order['payment_method']] ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Trạng thái thanh toán</span>
                    <span class="info-value" style="color: <?= $order['payment_status'] == 'paid' ? '#00AA00' : '#CC0000' ?>">
                        <?= $order['payment_status'] == 'paid' ? 'Đã thanh toán' : 'Chưa thanh toán' ?>
                    </span>
                </div>
            </div>
        </div>

        <!-- Thông tin giao hàng -->
        <div class="section">
            <div class="section-title">📍 Thông tin giao hàng</div>
            <div class="info-grid">
                <div class="info-item">
                    <span class="info-label">Người nhận</span>
                    <span class="info-value"><?= htmlspecialchars($order['fullname']) ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Số điện thoại</span>
                    <span class="info-value"><?= htmlspecialchars($order['phone']) ?></span>
                </div>
                <div class="info-item" style="grid-column: 1 / -1;">
                    <span class="info-label">Địa chỉ giao hàng</span>
                    <span class="info-value"><?= htmlspecialchars($order['address']) ?></span>
                </div>
                <?php if ($order['note']): ?>
                    <div class="info-item" style="grid-column: 1 / -1;">
                        <span class="info-label">Ghi chú</span>
                        <span class="info-value"><?= htmlspecialchars($order['note']) ?></span>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Danh sách sản phẩm -->
        <div class="section">
            <div class="section-title">🛍️ Sản phẩm đã đặt</div>
            <div class="product-list">
                <?php foreach ($details as $item): ?>
                    <div class="product-item">
                        <img src="<?= $item['image_url'] ? '/fashion-shop/uploads/products/' . htmlspecialchars($item['image_url']) : '/fashion-shop/assets/images/no-image.png' ?>" 
                             alt="<?= htmlspecialchars($item['product_name']) ?>" 
                             class="product-image">
                        
                        <div class="product-info">
                            <h3><?= htmlspecialchars($item['product_name']) ?></h3>
                            <div class="product-variant">
                                Size: <strong><?= htmlspecialchars($item['size_name']) ?></strong> | 
                                Màu: <strong><?= htmlspecialchars($item['color_name']) ?></strong>
                            </div>
                        </div>
                        
                        <div class="product-price-qty">
                            <div class="product-price"><?= number_format($item['price'], 0, ',', '.') ?>đ</div>
                            <div class="product-quantity">x<?= $item['quantity'] ?></div>
                            <div class="product-price" style="margin-top: 10px;">
                                = <?= number_format($item['subtotal'], 0, ',', '.') ?>đ
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Tổng tiền -->
            <div class="total-section">
                <div class="total-row">
                    <span>Tổng tiền hàng:</span>
                    <span><?= number_format($order['total_amount'], 0, ',', '.') ?>đ</span>
                </div>
                
                <?php if ($order['coupon_id']): ?>
                    <div class="total-row">
                        <span>Mã giảm giá (<?= htmlspecialchars($order['coupon_code']) ?>):</span>
                        <span style="color: #CC0000;">-<?= number_format($order['discount_amount'], 0, ',', '.') ?>đ</span>
                    </div>
                <?php endif; ?>
                
                <div class="total-row final">
                    <span>Thành tiền:</span>
                    <span><?= number_format($order['final_amount'], 0, ',', '.') ?>đ</span>
                </div>
            </div>
        </div>

        <!-- Nút hủy đơn (nếu đang xử lý) -->
        <?php if ($order['order_status'] == 'processing'): ?>
            <div style="text-align: center;">
                <a href="cancel_order.php?id=<?= $order_id ?>" 
                   class="btn btn-danger"
                   onclick="return confirm('Bạn có chắc chắn muốn hủy đơn hàng này?')">
                    ❌ Hủy đơn hàng
                </a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

<?php $conn->close(); ?>
