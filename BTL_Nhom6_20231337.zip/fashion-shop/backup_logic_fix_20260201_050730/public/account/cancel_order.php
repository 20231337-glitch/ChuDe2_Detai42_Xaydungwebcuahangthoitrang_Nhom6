<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {
    header('Location: ../auth/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$order_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Kiểm tra quyền sở hữu và trạng thái đơn hàng
$sql = "SELECT * FROM orders WHERE order_id = ? AND user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $order_id, $user_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    die('<h1 style="text-align:center;color:red;margin-top:50px;">❌ Không tìm thấy đơn hàng!</h1>');
}

// Chỉ cho phép hủy đơn đang xử lý
if ($order['order_status'] != 'processing') {
    die('<h1 style="text-align:center;color:red;margin-top:50px;">❌ Chỉ có thể hủy đơn hàng đang xử lý!</h1>');
}

// Bắt đầu TRANSACTION
$conn->begin_transaction();

try {
    // 1. Hoàn lại tồn kho
    $sql = "UPDATE product_variants pv
            JOIN order_details od ON pv.variant_id = od.variant_id
            SET pv.stock_quantity = pv.stock_quantity + od.quantity,
                pv.status = 'in_stock'
            WHERE od.order_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $stmt->close();

    // 2. Trừ sold_count
    $sql = "UPDATE products p
            JOIN product_variants pv ON p.product_id = pv.product_id
            JOIN order_details od ON pv.variant_id = od.variant_id
            SET p.sold_count = p.sold_count - od.quantity
            WHERE od.order_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $stmt->close();

    // 3. Hoàn lại mã giảm giá (nếu có)
    if ($order['coupon_id']) {
        $sql = "UPDATE coupons SET used_count = used_count - 1 WHERE coupon_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $order['coupon_id']);
        $stmt->execute();
        $stmt->close();

        // Xóa lịch sử sử dụng coupon
        $sql = "DELETE FROM coupon_usage WHERE order_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
        $stmt->close();
    }

    // 4. Cập nhật trạng thái đơn hàng
    $cancelled_reason = "Khách hàng yêu cầu hủy";
    $sql = "UPDATE orders 
            SET order_status = 'cancelled',
                cancelled_reason = ?,
                cancelled_by = 'customer',
                cancelled_at = NOW()
            WHERE order_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $cancelled_reason, $order_id);
    $stmt->execute();
    $stmt->close();

    // 5. Tạo thông báo
    $title = "Đơn hàng đã hủy";
    $message = "Đơn hàng #{$order_id} đã được hủy thành công. Tồn kho và mã giảm giá đã được hoàn lại.";
    $link = "/fashion-shop/public/account/order_detail.php?id={$order_id}";
    
    $sql = "INSERT INTO notifications (user_id, type, title, message, link, created_at)
            VALUES (?, 'order_update', ?, ?, ?, NOW())";
    $stmt = $conn->prepare($sql);
    $type = 'order_update';
    $stmt->bind_param("isss", $user_id, $title, $message, $link);
    $stmt->execute();
    $stmt->close();

    // COMMIT TRANSACTION
    $conn->commit();

    // Chuyển về trang chi tiết với thông báo
    header("Location: order_detail.php?id=$order_id&msg=cancelled");
    exit;

} catch (Exception $e) {
    // ROLLBACK nếu có lỗi
    $conn->rollback();
    die('<h1 style="text-align:center;color:red;margin-top:50px;">❌ Lỗi: ' . htmlspecialchars($e->getMessage()) . '</h1>');
}

$conn->close();
?>
