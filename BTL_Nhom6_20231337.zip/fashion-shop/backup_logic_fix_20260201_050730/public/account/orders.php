<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {
    header('Location: ../auth/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Lấy danh sách đơn hàng
$sql = "SELECT 
            o.order_id,
            o.order_date,
            o.total_amount,
            o.discount_amount,
            o.final_amount,
            o.order_status,
            o.payment_status,
            o.payment_method,
            COUNT(od.detail_id) as total_items
        FROM orders o
        LEFT JOIN order_details od ON o.order_id = od.order_id
        WHERE o.user_id = ?
        GROUP BY o.order_id
        ORDER BY o.order_date DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Trạng thái đơn hàng
$status_labels = [
    'processing' => 'Đang xử lý',
    'confirmed' => 'Đã xác nhận',
    'shipping' => 'Đang giao',
    'completed' => 'Hoàn thành',
    'cancelled' => 'Đã hủy'
];

$status_colors = [
    'processing' => '#FFA500',
    'confirmed' => '#0066CC',
    'shipping' => '#9933FF',
    'completed' => '#00AA00',
    'cancelled' => '#CC0000'
];

$payment_labels = [
    'unpaid' => 'Chưa thanh toán',
    'paid' => 'Đã thanh toán'
];
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lịch sử đơn hàng - Fashion Shop</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; padding: 30px 20px; }
        h1 { color: #333; margin-bottom: 30px; text-align: center; }
        .order-list { display: grid; gap: 20px; }
        .order-card {
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            transition: transform 0.2s;
        }
        .order-card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }
        .order-id { font-size: 18px; font-weight: bold; color: #0066CC; }
        .order-date { color: #666; font-size: 14px; }
        .order-info { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 15px; }
        .info-item { display: flex; flex-direction: column; }
        .info-label { font-size: 12px; color: #666; text-transform: uppercase; margin-bottom: 5px; }
        .info-value { font-size: 16px; font-weight: 600; color: #333; }
        .price { color: #00AA00; }
        .status-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            color: white;
        }
        .order-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #f0f0f0;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            display: inline-block;
            text-align: center;
            transition: all 0.3s;
        }
        .btn-primary { background: #0066CC; color: white; }
        .btn-primary:hover { background: #0052A3; }
        .btn-danger { background: #CC0000; color: white; }
        .btn-danger:hover { background: #990000; }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: 8px;
        }
        .empty-state img { width: 200px; opacity: 0.3; }
        .empty-state h2 { margin: 20px 0 10px; color: #666; }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #0066CC;
            text-decoration: none;
            font-weight: 600;
        }
        .back-link:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="container">
        <a href="../home/index.php" class="back-link">← Quay lại trang chủ</a>
        <h1>📦 Lịch sử đơn hàng</h1>

        <?php if (count($orders) > 0): ?>
            <div class="order-list">
                <?php foreach ($orders as $order): ?>
                    <div class="order-card">
                        <div class="order-header">
                            <div>
                                <div class="order-id">Đơn hàng #<?= $order['order_id'] ?></div>
                                <div class="order-date">Ngày đặt: <?= date('d/m/Y H:i', strtotime($order['order_date'])) ?></div>
                            </div>
                            <span class="status-badge" style="background: <?= $status_colors[$order['order_status']] ?>">
                                <?= $status_labels[$order['order_status']] ?>
                            </span>
                        </div>

                        <div class="order-info">
                            <div class="info-item">
                                <span class="info-label">Tổng tiền hàng</span>
                                <span class="info-value"><?= number_format($order['total_amount'], 0, ',', '.') ?>đ</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Giảm giá</span>
                                <span class="info-value" style="color: #CC0000;">-<?= number_format($order['discount_amount'], 0, ',', '.') ?>đ</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Thành tiền</span>
                                <span class="info-value price"><?= number_format($order['final_amount'], 0, ',', '.') ?>đ</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Số sản phẩm</span>
                                <span class="info-value"><?= $order['total_items'] ?> sản phẩm</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Thanh toán</span>
                                <span class="info-value"><?= $payment_labels[$order['payment_status']] ?></span>
                            </div>
                        </div>

                        <div class="order-actions">
                            <a href="order_detail.php?id=<?= $order['order_id'] ?>" class="btn btn-primary">Xem chi tiết</a>
                            
                            <?php if ($order['order_status'] == 'processing'): ?>
                                <a href="cancel_order.php?id=<?= $order['order_id'] ?>" 
                                   class="btn btn-danger"
                                   onclick="return confirm('Bạn có chắc muốn hủy đơn hàng này?')">
                                    Hủy đơn
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <h2>Chưa có đơn hàng nào</h2>
                <p>Bạn chưa đặt hàng lần nào. Hãy khám phá sản phẩm của chúng tôi!</p>
                <a href="../home/index.php" class="btn btn-primary" style="margin-top: 20px;">Mua sắm ngay</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

<?php $conn->close(); ?>
