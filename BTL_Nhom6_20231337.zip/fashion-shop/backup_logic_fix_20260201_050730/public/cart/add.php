<?php
/**
 * Xử lý thêm sản phẩm vào giỏ hàng (AJAX Endpoint)
 * Endpoint: POST /public/cart/add.php
 * Response: JSON { success, message, cart_count }
 */

session_start();
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';

// Header JSON
header('Content-Type: application/json; charset=utf-8');

// Kiểm tra đăng nhập
if (!isLoggedIn()) {
    echo json_encode([
        'success' => false,
        'message' => 'Vui lòng đăng nhập để thêm vào giỏ hàng!',
        'redirect' => BASE_URL . '/public/auth/login.php'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$userId = $_SESSION['user_id'];

// Validate input
$productId = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
$sizeId = isset($_POST['size_id']) ? intval($_POST['size_id']) : 0;
$colorId = isset($_POST['color_id']) ? intval($_POST['color_id']) : 0;
$quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;

if (!$productId || !$sizeId || !$colorId || $quantity <= 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Vui lòng chọn đầy đủ size, màu và số lượng!'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    // 1. Kiểm tra sản phẩm có active và chưa xóa không
    $sqlProductCheck = "SELECT product_id FROM products 
                        WHERE product_id = ? AND status = 'active' AND deleted_at IS NULL";
    $productExists = fetchRow($sqlProductCheck, [$productId], 'i');
    
    if (!$productExists) {
        echo json_encode([
            'success' => false,
            'message' => 'Sản phẩm không còn tồn tại hoặc đã ngừng bán!'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // 2. Tìm variant_id (check stock status)
    $sqlVariant = "SELECT variant_id, stock_quantity FROM product_variants 
                   WHERE product_id = ? AND size_id = ? AND color_id = ? 
                   AND status = 'in_stock' AND stock_quantity > 0";
    $variant = fetchRow($sqlVariant, [$productId, $sizeId, $colorId], 'iii');
    
    if (!$variant) {
        echo json_encode([
            'success' => false,
            'message' => 'Không tìm thấy sản phẩm với size và màu đã chọn!'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    $variantId = $variant['variant_id'];
    $stockQuantity = $variant['stock_quantity'];
    
    // 3. Kiểm tra tồn kho
    if ($quantity > $stockQuantity) {
        echo json_encode([
            'success' => false,
            'message' => "Chỉ còn {$stockQuantity} sản phẩm trong kho!"
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // 4. Kiểm tra sản phẩm đã có trong giỏ chưa
    $sqlCheck = "SELECT cart_id, quantity FROM cart WHERE user_id = ? AND variant_id = ?";
    $existingCart = fetchRow($sqlCheck, [$userId, $variantId], 'ii');
    
    if ($existingCart) {
        // Đã có → UPDATE quantity
        $newQuantity = $existingCart['quantity'] + $quantity;
        
        // Kiểm tra tồn kho lại
        if ($newQuantity > $stockQuantity) {
            echo json_encode([
                'success' => false,
                'message' => "Chỉ còn {$stockQuantity} sản phẩm trong kho!"
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
        
        $sqlUpdate = "UPDATE cart 
                      SET quantity = ?, 
                          expires_at = DATE_ADD(NOW(), INTERVAL 30 DAY)
                      WHERE cart_id = ?";
        $success = executeQuery($sqlUpdate, [$newQuantity, $existingCart['cart_id']], 'ii');
        
        if ($success) {
            // Đếm tổng số items trong giỏ
            $cartCountData = fetchRow("SELECT COUNT(*) as total FROM cart WHERE user_id = ?", [$userId], 'i');
            $cartCount = $cartCountData['total'];
            
            echo json_encode([
                'success' => true,
                'message' => 'Đã cập nhật số lượng trong giỏ hàng! 🎉',
                'cart_count' => $cartCount
            ], JSON_UNESCAPED_UNICODE);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Có lỗi xảy ra, vui lòng thử lại!'
            ], JSON_UNESCAPED_UNICODE);
        }
    } else {
        // Chưa có → INSERT
        $sqlInsert = "INSERT INTO cart (user_id, variant_id, quantity, added_at, expires_at)
                      VALUES (?, ?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 30 DAY))";
        $success = executeQuery($sqlInsert, [$userId, $variantId, $quantity], 'iii');
        
        if ($success) {
            // Đếm tổng số items trong giỏ
            $cartCountData = fetchRow("SELECT COUNT(*) as total FROM cart WHERE user_id = ?", [$userId], 'i');
            $cartCount = $cartCountData['total'];
            
            echo json_encode([
                'success' => true,
                'message' => 'Đã thêm sản phẩm vào giỏ hàng! 🛒',
                'cart_count' => $cartCount
            ], JSON_UNESCAPED_UNICODE);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Có lỗi xảy ra, vui lòng thử lại!'
            ], JSON_UNESCAPED_UNICODE);
        }
    }
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Lỗi hệ thống: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>
