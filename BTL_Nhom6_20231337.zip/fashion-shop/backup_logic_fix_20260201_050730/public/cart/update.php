<?php
/**
 * Cập nhật số lượng trong giỏ hàng
 */

session_start();
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Chưa đăng nhập!']);
    exit;
}

$userId = $_SESSION['user_id'];
$cartId = isset($_POST['cart_id']) ? intval($_POST['cart_id']) : 0;
$quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;

if (!$cartId || $quantity <= 0) {
    echo json_encode(['success' => false, 'message' => 'Thông tin không hợp lệ!']);
    exit;
}

try {
    // $conn = getDBConnection(); // REMOVED: Function not exists, using global $conn
    
    // Kiểm tra quyền sở hữu
    $sqlCheck = "SELECT c.*, pv.stock_quantity 
                 FROM cart c
                 JOIN product_variants pv ON c.variant_id = pv.variant_id
                 WHERE c.cart_id = ? AND c.user_id = ?";
    $stmtCheck = $conn->prepare($sqlCheck);
    $stmtCheck->bind_param('ii', $cartId, $userId);
    $stmtCheck->execute();
    $result = $stmtCheck->get_result();
    $cart = $result->fetch_assoc();
    $stmtCheck->close();
    
    if (!$cart) {
        echo json_encode(['success' => false, 'message' => 'Không tìm thấy sản phẩm trong giỏ!']);
        exit;
    }
    
    // Kiểm tra tồn kho
    if ($quantity > $cart['stock_quantity']) {
        echo json_encode([
            'success' => false, 
            'message' => "Chỉ còn {$cart['stock_quantity']} sản phẩm trong kho!"
        ]);
        exit;
    }
    
    // Cập nhật
    $sqlUpdate = "UPDATE cart 
                  SET quantity = ?, expires_at = DATE_ADD(NOW(), INTERVAL 30 DAY)
                  WHERE cart_id = ? AND user_id = ?";
    $stmtUpdate = $conn->prepare($sqlUpdate);
    $stmtUpdate->bind_param('iii', $quantity, $cartId, $userId);
    $success = $stmtUpdate->execute();
    $stmtUpdate->close();
    
    if ($success) {
        echo json_encode(['success' => true, 'message' => 'Đã cập nhật số lượng!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Có lỗi xảy ra!']);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
}
?>
