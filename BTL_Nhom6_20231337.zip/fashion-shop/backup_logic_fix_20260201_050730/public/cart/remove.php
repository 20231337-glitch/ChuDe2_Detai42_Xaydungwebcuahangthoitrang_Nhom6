<?php
/**
 * Xóa sản phẩm khỏi giỏ hàng
 */

session_start();
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Chưa đăng nhập!']);
    exit;
}

$userId = $_SESSION['user_id'];
$cartId = isset($_POST['cart_id']) ? intval($_POST['cart_id']) : 0;

if (!$cartId) {
    echo json_encode(['success' => false, 'message' => 'Thông tin không hợp lệ!']);
    exit;
}

try {
    // $conn = getDBConnection(); // REMOVED: Function not exists, using global $conn
    
    // Xóa (kiểm tra quyền sở hữu)
    $sqlDelete = "DELETE FROM cart WHERE cart_id = ? AND user_id = ?";
    $stmtDelete = $conn->prepare($sqlDelete);
    $stmtDelete->bind_param('ii', $cartId, $userId);
    $success = $stmtDelete->execute();
    $affectedRows = $stmtDelete->affected_rows;
    $stmtDelete->close();
    
    if ($success && $affectedRows > 0) {
        echo json_encode(['success' => true, 'message' => 'Đã xóa sản phẩm khỏi giỏ hàng!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Không tìm thấy sản phẩm!']);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Lỗi: ' . $e->getMessage()]);
}
?>
