<?php
$pageTitle = 'Giỏ hàng';
require_once __DIR__ . '/../includes/header.php';

// Kiểm tra đăng nhập
if (!isLoggedIn()) {
    redirect(BASE_URL . '/public/auth/login.php');
}

$userId = $_SESSION['user_id'];

// Lấy giỏ hàng
$sqlCart = "
    SELECT 
        c.cart_id,
        c.quantity,
        pv.variant_id,
        pv.stock_quantity,
        p.product_id,
        p.product_name,
        p.base_price,
        p.sale_price,
        s.size_name,
        col.color_name,
        col.color_code,
        pi.image_url,
        (IF(p.sale_price > 0, p.sale_price, p.base_price) * c.quantity) as subtotal
    FROM cart c
    JOIN product_variants pv ON c.variant_id = pv.variant_id
    JOIN products p ON pv.product_id = p.product_id AND p.status = 'active' AND p.deleted_at IS NULL
    JOIN sizes s ON pv.size_id = s.size_id
    JOIN colors col ON pv.color_id = col.color_id
    LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
    WHERE c.user_id = ?
    ORDER BY c.added_at DESC
";
$cartItems = fetchData($sqlCart, [$userId], 'i');

// Tính tổng tiền
$totalAmount = 0;
foreach ($cartItems as $item) {
    $totalAmount += $item['subtotal'];
}

?>

<div class="container cart-page">
    <h1>🛒 Giỏ hàng của bạn</h1>
    
    <?php if (empty($cartItems)): ?>
        <div class="empty-cart">
            <p>😔 Giỏ hàng của bạn đang trống!</p>
            <a href="<?php echo BASE_URL; ?>/public/products/list.php" class="btn-primary">Tiếp tục mua sắm</a>
        </div>
    <?php else: ?>
        <div class="cart-content">
            <div class="cart-items">
                <table class="cart-table">
                    <thead>
                        <tr>
                            <th>Sản phẩm</th>
                            <th>Đơn giá</th>
                            <th>Số lượng</th>
                            <th>Thành tiền</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cartItems as $item): ?>
                            <tr data-cart-id="<?php echo $item['cart_id']; ?>">
                                <td class="product-info">
                                    <div class="product-img">
                                        <?php if ($item['image_url']): ?>
                                            <img src="<?php echo BASE_URL . $item['image_url']; ?>" alt="<?php echo e($item['product_name']); ?>">
                                        <?php else: ?>
                                            <img src="<?php echo BASE_URL; ?>/assets/images/no-image.png" alt="No image">
                                        <?php endif; ?>
                                    </div>
                                    <div class="product-details">
                                        <h3><?php echo e($item['product_name']); ?></h3>
                                        <p class="variant-info">
                                            Size: <strong><?php echo e($item['size_name']); ?></strong> | 
                                            Màu: <span style="background:<?php echo e($item['color_code']); ?>; width:15px; height:15px; display:inline-block; border:1px solid #ccc; border-radius:50%;"></span> 
                                            <strong><?php echo e($item['color_name']); ?></strong>
                                        </p>
                                        <p class="stock-info">Còn <?php echo $item['stock_quantity']; ?> sản phẩm</p>
                                    </div>
                                </td>
                                <td><?php echo formatMoney($item['sale_price'] > 0 ? $item['sale_price'] : $item['base_price']); ?></td>
                                <td class="quantity">
                                    <div class="quantity-control">
                                        <button class="btn-decrease" onclick="updateQuantity(<?php echo $item['cart_id']; ?>, <?php echo $item['quantity'] - 1; ?>)">-</button>
                                        <input type="number" 
                                               value="<?php echo $item['quantity']; ?>" 
                                               min="1" 
                                               max="<?php echo $item['stock_quantity']; ?>"
                                               onchange="updateQuantity(<?php echo $item['cart_id']; ?>, this.value)">
                                        <button class="btn-increase" onclick="updateQuantity(<?php echo $item['cart_id']; ?>, <?php echo $item['quantity'] + 1; ?>)">+</button>
                                    </div>
                                </td>
                                <td class="subtotal"><?php echo formatMoney($item['subtotal']); ?></td>
                                <td class="actions">
                                    <button class="btn-remove" onclick="removeFromCart(<?php echo $item['cart_id']; ?>)">🗑️ Xóa</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="cart-summary">
                <h2>Tổng đơn hàng</h2>
                <div class="summary-line">
                    <span>Tạm tính:</span>
                    <strong><?php echo formatMoney($totalAmount); ?></strong>
                </div>
                <div class="summary-line">
                    <span>Phí vận chuyển:</span>
                    <strong>Miễn phí</strong>
                </div>
                <div class="summary-total">
                    <span>Tổng cộng:</span>
                    <strong class="total-amount"><?php echo formatMoney($totalAmount); ?></strong>
                </div>
                
                <a href="<?php echo BASE_URL; ?>/public/checkout/" class="btn-checkout">Tiến hành thanh toán</a>
                <a href="<?php echo BASE_URL; ?>/public/products/list.php" class="btn-continue">Tiếp tục mua sắm</a>
            </div>
        </div>
    <?php endif; ?>
</div>

<script>
// Cập nhật số lượng
function updateQuantity(cartId, newQuantity) {
    if (newQuantity < 1) {
        if (confirm('Bạn có muốn xóa sản phẩm này khỏi giỏ hàng?')) {
            removeFromCart(cartId);
        }
        return;
    }
    
    fetch('<?php echo BASE_URL; ?>/public/cart/update.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'cart_id=' + cartId + '&quantity=' + newQuantity
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert(data.message);
        }
    })
    .catch(err => alert('Có lỗi xảy ra!'));
}

// Xóa khỏi giỏ
function removeFromCart(cartId) {
    if (!confirm('Bạn có chắc muốn xóa sản phẩm này?')) return;
    
    fetch('<?php echo BASE_URL; ?>/public/cart/remove.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'cart_id=' + cartId
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert(data.message);
        }
    })
    .catch(err => alert('Có lỗi xảy ra!'));
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
