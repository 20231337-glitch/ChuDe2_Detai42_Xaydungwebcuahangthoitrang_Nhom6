<?php
// Include các file cấu hình và thư viện
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/pagination.php';

// Khởi tạo session nếu chưa có
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TshopNhom6 - Fashion Shop Năng Động</title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&family=Quicksand:wght@400;600;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="/fashion-shop/assets/css/style.css">
    
    <!-- Cart System CSS -->
    <link rel="stylesheet" href="/fashion-shop/assets/css/cart.css">
</head>
<body>

<!-- Top Bar -->
<div class="top-bar">
    <div class="container-fluid">
        <marquee behavior="scroll" direction="left">
            🎉 Chào mừng đến với TshopNhom6 - Thời trang trẻ trung năng động! 📞 Hotline: <strong>0355.636.882</strong> | 📧 Email: <strong>20231337@gmail.com</strong> | 🚚 FREESHIP đơn từ 500K 🎁
        </marquee>
    </div>
</div>

<!-- Main Navbar -->
<nav class="navbar navbar-expand-lg navbar-custom sticky-top">
    <div class="container">
        <!-- Logo -->
        <a class="navbar-brand" href="/fashion-shop/public/index.php">
            <i class="fas fa-tshirt"></i> TshopNhom6
        </a>
        
        <!-- Toggle Button -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <!-- Menu -->
        <div class="collapse navbar-collapse" id="navbarMain">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="/fashion-shop/public/index.php">
                        <i class="fas fa-home"></i> Trang chủ
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/fashion-shop/public/products/list.php">
                        <i class="fas fa-th"></i> Sản phẩm
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/fashion-shop/public/products/list.php?category_id=1">
                        <i class="fas fa-tshirt"></i> Áo
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/fashion-shop/public/products/list.php?category_id=3">
                        <i class="fas fa-user"></i> Quần
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/fashion-shop/public/products/list.php?category_id=4">
                        <i class="fas fa-female"></i> Váy
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/fashion-shop/public/products/list.php?category_id=5">
                        <i class="fas fa-shopping-bag"></i> Phụ kiện
                    </a>
                </li>
            </ul>
            
            <!-- Icons -->
            <div class="navbar-icons">
                <a href="/fashion-shop/public/products/search.php" title="Tìm kiếm">
                    <i class="fas fa-search"></i>
                </a>
                <a href="/fashion-shop/public/cart/index.php" title="Giỏ hàng" style="position: relative;">
                    <i class="fas fa-shopping-cart"></i>
                    <?php if(isset($_SESSION['user_id'])): 
                        // Đếm số items trong giỏ
                        $cartCountData = fetchRow("SELECT COUNT(*) as total FROM cart WHERE user_id = ?", [$_SESSION['user_id']], 'i');
                        $cartCount = $cartCountData ? $cartCountData['total'] : 0;
                    ?>
                    <span class="cart-badge"><?php echo $cartCount; ?></span>
                    <?php endif; ?>
                </a>
                <?php if(isset($_SESSION['user_id'])): ?>
                <a href="/fashion-shop/public/account/profile.php" title="Tài khoản">
                    <i class="fas fa-user-circle"></i>
                </a>
                <?php else: ?>
                <a href="/fashion-shop/public/auth/login.php" title="Đăng nhập">
                    <i class="fas fa-sign-in-alt"></i>
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<!-- Cart System JS -->
<script src="/fashion-shop/assets/js/cart.js"></script>