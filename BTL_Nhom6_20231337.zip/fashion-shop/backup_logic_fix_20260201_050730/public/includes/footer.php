<!-- Footer -->
<footer class="footer">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4">
                <div class="footer-logo">
                    <i class="fas fa-tshirt"></i> TshopNhom6
                </div>
                <p>Thời trang trẻ trung, năng động dành cho giới trẻ. Chất lượng đỉnh cao - Giá cả hợp lý - Giao hàng tận nơi.</p>
                <p class="mt-3"><strong>💬 Style của bạn, niềm tự hào của chúng tôi!💬</strong></p>
            </div>
            
            <div class="col-md-4">
                <h5>📞 Liên hệ với chúng tôi</h5>
                <p>📍 <strong>Địa chỉ:</strong> Hà Nội, Việt Nam</p>
                <p>📞 <strong>Hotline:</strong> 0355.636.882</p>
                <p>📧 <strong>Email:</strong> 20231337@gmail.com</p>
                <p>🕐 <strong>Giờ làm việc:</strong> 8:00 - 22:00 (Hàng ngày)</p>
            </div>
            
            <div class="col-md-4">
                <h5>🔗 Kết nối với chúng tôi</h5>
                <p>Theo dõi chúng tôi để nhận ưu đãi mới nhất!</p>
                <div class="social-links">
                    <a href="https://facebook.com" class="facebook" title="Facebook">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="https://zalo.me" class="zalo" title="Zalo">
                        <i class="fas fa-comment-dots"></i>
                    </a>
                </div>
                
                <h5 class="mt-4">🔗 Liên kết nhanh</h5>
                <ul class="list-unstyled">
                    <li><a href="/fashion-shop/public/index.php">➤ Trang chủ</a></li>
                    <li><a href="/fashion-shop/public/products/list.php">➤ Sản phẩm</a></li>
                    <li><a href="/fashion-shop/public/cart/index.php">➤ Giỏ hàng</a></li>
                    <li><a href="/fashion-shop/public/account/profile.php">➤ Tài khoản</a></li>
                </ul>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p class="mb-0">© 2026 <strong>TshopNhom6</strong>. All rights reserved. Made with ❤️ by Nhóm 6</p>
        </div>
    </div>
</footer>

<!-- Bootstrap 5 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Cart System CSS & JS -->
<link rel="stylesheet" href="/fashion-shop/assets/css/cart.css">
<script src="/fashion-shop/assets/js/cart.js"></script>

</body>
</html>
