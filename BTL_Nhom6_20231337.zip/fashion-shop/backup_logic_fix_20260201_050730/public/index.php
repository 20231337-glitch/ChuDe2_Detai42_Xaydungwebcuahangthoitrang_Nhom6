<?php
// Kết nối database
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/includes/header.php';
?>

<!-- Hero Slider -->
<div class="container mt-4">
    <div id="heroCarousel" class="carousel slide hero-slider" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="0" class="active"></button>
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="2"></button>
        </div>
        
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1200&h=500&fit=crop" class="d-block w-100" alt="Banner 1">
                <div class="carousel-caption">
                    <h2 class="display-4 fw-bold">🎉 SALE CUỐI TUẦN</h2>
                    <p class="fs-5">Giảm giá lên đến 50% cho tất cả sản phẩm</p>
                    <a href="/fashion-shop/public/products/list.php" class="btn btn-primary btn-lg">Mua ngay</a>
                </div>
            </div>
            <div class="carousel-item">
                <img src="https://images.unsplash.com/photo-1445205170230-053b83016050?w=1200&h=500&fit=crop" class="d-block w-100" alt="Banner 2">
                <div class="carousel-caption">
                    <h2 class="display-4 fw-bold">👕 BỘ SƯU TẬP MỚI</h2>
                    <p class="fs-5">Thời trang năng động - Phong cách trẻ trung</p>
                    <a href="/fashion-shop/public/products/list.php" class="btn btn-secondary btn-lg">Khám phá</a>
                </div>
            </div>
            <div class="carousel-item">
                <img src="https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1200&h=500&fit=crop" class="d-block w-100" alt="Banner 3">
                <div class="carousel-caption">
                    <h2 class="display-4 fw-bold">🚚 FREESHIP TOÀN QUỐC</h2>
                    <p class="fs-5">Miễn phí vận chuyển cho đơn hàng từ 500K</p>
                    <a href="/fashion-shop/public/products/list.php" class="btn btn-primary btn-lg">Mua sắm ngay</a>
                </div>
            </div>
        </div>
        
        <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
        </button>
    </div>
</div>

<!-- Services Section -->
<div class="container my-5">
    <div class="row g-4">
        <div class="col-md-3 col-sm-6">
            <div class="service-box">
                <div class="service-icon">
                    <i class="fas fa-shipping-fast"></i>
                </div>
                <h5 class="fw-bold">Giao hàng nhanh</h5>
                <p class="text-muted mb-0">Giao hàng trong 24h nội thành</p>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="service-box">
                <div class="service-icon">
                    <i class="fas fa-gift"></i>
                </div>
                <h5 class="fw-bold">Freeship</h5>
                <p class="text-muted mb-0">Miễn phí vận chuyển từ 500K</p>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="service-box">
                <div class="service-icon">
                    <i class="fas fa-headset"></i>
                </div>
                <h5 class="fw-bold">Hỗ trợ 24/7</h5>
                <p class="text-muted mb-0">Tư vấn nhiệt tình, chu đáo</p>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="service-box">
                <div class="service-icon">
                    <i class="fas fa-sync-alt"></i>
                </div>
                <h5 class="fw-bold">Đổi trả dễ dàng</h5>
                <p class="text-muted mb-0">Đổi trả trong vòng 7 ngày</p>
            </div>
        </div>
    </div>
</div>

<!-- Featured Products Section -->
<div class="container my-5">
    <div class="section-header">
        <h2 class="section-title">🔥 Sản phẩm nổi bật</h2>
        <p class="section-subtitle">Những sản phẩm được yêu thích nhất</p>
    </div>
    
    <div class="row g-4">
        <?php
        // Lấy 8 sản phẩm nổi bật từ database
        $sql = "SELECT p.*, pi.image_url, c.category_name
                FROM products p
                LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
                LEFT JOIN categories c ON p.category_id = c.category_id
                WHERE p.status = 'active' AND p.deleted_at IS NULL
                ORDER BY p.sold_count DESC
                LIMIT 8";
        
        $result = mysqli_query($conn, $sql);
        
        if(mysqli_num_rows($result) > 0):
            while($product = mysqli_fetch_assoc($result)):
                $discount = 0;
        ?>
        <div class="col-md-3 col-sm-6">
            <div class="product-card">
                <?php if($discount > 0): ?>
                <div class="product-badge">-<?= $discount ?>%</div>
                <?php endif; ?>
                
                <div class="product-image">
                    <img src="<?= $product['image_url'] ?: 'https://via.placeholder.com/300x300?text=No+Image' ?>" alt="<?= htmlspecialchars($product['product_name']) ?>">
                    <div class="product-overlay">
                        <a href="/fashion-shop/public/products/detail.php?id=<?= $product['product_id'] ?>" class="btn btn-primary btn-sm w-100">
                            <i class="fas fa-eye"></i> Xem chi tiết
                        </a>
                    </div>
                </div>
                
                <div class="product-info">
                    <div class="text-muted small mb-1">
                        <i class="fas fa-tag"></i> <?= htmlspecialchars($product['category_name']) ?>
                    </div>
                    <h6 class="product-title">
                        <?= htmlspecialchars($product['product_name']) ?>
                    </h6>
                    <div>
                        <span class="product-price"><?= number_format($product['base_price']) ?>đ</span>
                        
                    </div>
                    <div class="mt-2 small text-muted">
                        <i class="fas fa-eye"></i> <?= $product['view_count'] ?> lượt xem
                        <span class="ms-2"><i class="fas fa-shopping-cart"></i> Đã bán <?= $product['sold_count'] ?></span>
                    </div>
                </div>
            </div>
        </div>
        <?php 
            endwhile;
        else:
        ?>
        <div class="col-12 text-center py-5">
            <i class="fas fa-box-open fa-4x text-muted mb-3"></i>
            <p class="text-muted">Chưa có sản phẩm nào. Vui lòng quay lại sau!</p>
        </div>
        <?php endif; ?>
    </div>
    
    <div class="text-center mt-4">
        <a href="/fashion-shop/public/products/list.php" class="btn btn-outline btn-lg">
            <i class="fas fa-th"></i> Xem tất cả sản phẩm
        </a>
    </div>
</div>

<!-- New Arrivals Section -->
<div class="container my-5">
    <div class="section-header">
        <h2 class="section-title">✨ Sản phẩm mới nhất</h2>
        <p class="section-subtitle">Những mẫu mã mới nhất vừa cập nhật</p>
    </div>
    
    <div class="row g-4">
        <?php
        // Lấy 4 sản phẩm mới nhất
        $sql_new = "SELECT p.*, pi.image_url, c.category_name
                    FROM products p
                    LEFT JOIN product_images pi ON p.product_id = pi.product_id AND pi.is_primary = 1
                    LEFT JOIN categories c ON p.category_id = c.category_id
                    WHERE p.status = 'active' AND p.deleted_at IS NULL
                    ORDER BY p.created_at DESC
                    LIMIT 4";
        
        $result_new = mysqli_query($conn, $sql_new);
        
        if(mysqli_num_rows($result_new) > 0):
            while($product = mysqli_fetch_assoc($result_new)):
        ?>
        <div class="col-md-3 col-sm-6">
            <div class="product-card">
                <div class="product-badge" style="background: var(--color-secondary)">NEW</div>
                <div class="product-image">
                    <img src="<?= $product['image_url'] ?: 'https://via.placeholder.com/300x300?text=No+Image' ?>" alt="<?= htmlspecialchars($product['product_name']) ?>">
                    <div class="product-overlay">
                        <a href="/fashion-shop/public/products/detail.php?id=<?= $product['product_id'] ?>" class="btn btn-secondary btn-sm w-100">
                            <i class="fas fa-shopping-bag"></i> Mua ngay
                        </a>
                    </div>
                </div>
                <div class="product-info">
                    <div class="text-muted small mb-1">
                        <i class="fas fa-tag"></i> <?= htmlspecialchars($product['category_name']) ?>
                    </div>
                    <h6 class="product-title">
                        <?= htmlspecialchars($product['product_name']) ?>
                    </h6>
                    <div>
                        <span class="product-price"><?= number_format($product['base_price']) ?>đ</span>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; endif; ?>
    </div>
</div>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
