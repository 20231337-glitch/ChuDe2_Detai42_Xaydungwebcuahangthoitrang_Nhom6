<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'customer') {
    header('Location: ../auth/login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Xử lý đánh dấu đã đọc
if (isset($_GET['action']) && $_GET['action'] == 'mark_read' && isset($_GET['id'])) {
    $notification_id = intval($_GET['id']);
    $update_sql = "UPDATE notifications SET is_read = 1 WHERE notification_id = ? AND user_id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("ii", $notification_id, $user_id);
    $update_stmt->execute();
    $update_stmt->close();
    
    // Redirect về link nếu có
    $link_sql = "SELECT link FROM notifications WHERE notification_id = ?";
    $link_stmt = $conn->prepare($link_sql);
    $link_stmt->bind_param("i", $notification_id);
    $link_stmt->execute();
    $link_result = $link_stmt->get_result()->fetch_assoc();
    $link_stmt->close();
    
    if ($link_result && !empty($link_result['link'])) {
        header('Location: ' . $link_result['link']);
    } else {
        header('Location: notifications.php');
    }
    exit;
}

// Xử lý đánh dấu tất cả đã đọc
if (isset($_GET['action']) && $_GET['action'] == 'mark_all_read') {
    $update_all_sql = "UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0";
    $update_all_stmt = $conn->prepare($update_all_sql);
    $update_all_stmt->bind_param("i", $user_id);
    $update_all_stmt->execute();
    $update_all_stmt->close();
    header('Location: notifications.php?msg=marked_all');
    exit;
}

// Xử lý xóa thông báo
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $notification_id = intval($_GET['id']);
    $delete_sql = "DELETE FROM notifications WHERE notification_id = ? AND user_id = ?";
    $delete_stmt = $conn->prepare($delete_sql);
    $delete_stmt->bind_param("ii", $notification_id, $user_id);
    $delete_stmt->execute();
    $delete_stmt->close();
    header('Location: notifications.php?msg=deleted');
    exit;
}

// Lấy danh sách thông báo
$sql = "SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$notifications = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Đếm số thông báo chưa đọc
$unread_count = count(array_filter($notifications, function($n) {
    return $n['is_read'] == 0;
}));

// Icon theo loại thông báo
$type_icons = [
    'order_update' => '📦',
    'promotion' => '🎁',
    'system' => '🔔',
    'payment' => '💳',
    'shipping' => '🚚',
];
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thông báo - Fashion Shop</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f5f5; }
        .container { max-width: 900px; margin: 0 auto; padding: 30px 20px; }
        h1 { color: #333; margin-bottom: 10px; text-align: center; }
        .subtitle { text-align: center; color: #666; margin-bottom: 30px; }
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 500;
        }
        .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .notification-header {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .unread-badge {
            background: #e74c3c;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 14px;
        }
        .btn-mark-all {
            padding: 10px 20px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        .btn-mark-all:hover { background: #45a049; }
        .notification-list { display: grid; gap: 15px; }
        .notification-item {
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            display: flex;
            gap: 15px;
            transition: transform 0.2s;
        }
        .notification-item:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
        .notification-item.unread {
            border-left: 4px solid #4CAF50;
            background: #f0f9ff;
        }
        .notification-icon {
            font-size: 32px;
            flex-shrink: 0;
        }
        .notification-content { flex: 1; }
        .notification-title {
            font-size: 16px;
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
        }
        .notification-message {
            font-size: 14px;
            color: #666;
            line-height: 1.6;
            margin-bottom: 10px;
        }
        .notification-meta {
            font-size: 12px;
            color: #999;
        }
        .notification-actions {
            display: flex;
            flex-direction: column;
            gap: 8px;
            justify-content: center;
        }
        .btn-small {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            text-align: center;
            white-space: nowrap;
        }
        .btn-primary-small { background: #4CAF50; color: white; }
        .btn-primary-small:hover { background: #45a049; }
        .btn-danger-small { background: #dc3545; color: white; }
        .btn-danger-small:hover { background: #c82333; }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .empty-state h2 {
            color: #666;
            margin-bottom: 20px;
        }
        .btn-back {
            background: #6c757d;
            color: white;
            padding: 12px 30px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 600;
            display: inline-block;
            margin-top: 20px;
        }
        .btn-back:hover { background: #5a6268; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Thông báo</h1>
        <p class="subtitle">Theo dõi các cập nhật mới nhất từ Fashion Shop</p>
        
        <?php if (isset($_GET['msg'])): ?>
            <?php if ($_GET['msg'] == 'marked_all'): ?>
                <div class="alert alert-success">✅ Đã đánh dấu tất cả thông báo là đã đọc!</div>
            <?php elseif ($_GET['msg'] == 'deleted'): ?>
                <div class="alert alert-success">✅ Đã xóa thông báo!</div>
            <?php endif; ?>
        <?php endif; ?>
        
        <?php if (!empty($notifications)): ?>
            <div class="notification-header">
                <div>
                    <?php if ($unread_count > 0): ?>
                        <span class="unread-badge"><?= $unread_count ?> thông báo mới</span>
                    <?php else: ?>
                        <span style="color: #666;">Tất cả thông báo đã được đọc</span>
                    <?php endif; ?>
                </div>
                
                <?php if ($unread_count > 0): ?>
                    <a href="?action=mark_all_read" class="btn-mark-all">Đánh dấu tất cả đã đọc</a>
                <?php endif; ?>
            </div>
            
            <div class="notification-list">
                <?php foreach ($notifications as $notification): ?>
                    <?php
                    $icon = $type_icons[$notification['type']] ?? '🔔';
                    $is_unread = $notification['is_read'] == 0;
                    ?>
                    <div class="notification-item <?= $is_unread ? 'unread' : '' ?>">
                        <div class="notification-icon"><?= $icon ?></div>
                        
                        <div class="notification-content">
                            <div class="notification-title"><?= htmlspecialchars($notification['title']) ?></div>
                            <div class="notification-message"><?= htmlspecialchars($notification['message']) ?></div>
                            <div class="notification-meta">
                                <?= date('d/m/Y H:i', strtotime($notification['created_at'])) ?>
                                <?php if ($is_unread): ?>
                                    <span style="color: #4CAF50; font-weight: 600;">• Mới</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="notification-actions">
                            <?php if ($is_unread): ?>
                                <a href="?action=mark_read&id=<?= $notification['notification_id'] ?>" 
                                   class="btn-small btn-primary-small">Đánh dấu đã đọc</a>
                            <?php endif; ?>
                            
                            <a href="?action=delete&id=<?= $notification['notification_id'] ?>" 
                               class="btn-small btn-danger-small"
                               onclick="return confirm('Bạn có chắc muốn xóa thông báo này?')">Xóa</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div style="text-align: center; margin-top: 30px;">
                <a href="orders.php" class="btn-back">🔙 Quay lại</a>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <h2>🔔 Chưa có thông báo</h2>
                <p>Bạn sẽ nhận được thông báo về đơn hàng, khuyến mãi và tin tức mới nhất tại đây.</p>
                <a href="orders.php" class="btn-back">🔙 Quay lại</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
