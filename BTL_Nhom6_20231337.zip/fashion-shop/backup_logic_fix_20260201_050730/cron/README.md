﻿# CRON JOBS - HƯỚNG DẪN SETUP

## 📋 Danh sách Cron Jobs

### 1. cleanup_cart.php
**Chức năng:** Xóa giỏ hàng hết hạn (>30 ngày không hoạt động)  
**Thời gian chạy:** Mỗi ngày 2:00 AM  
**Crontab:**
```
0 2 * * * php C:/xampp/htdocs/fashion-shop/cron/cleanup_cart.php
```

### 2. auto_cancel_orders.php
**Chức năng:** Tự động hủy đơn chưa thanh toán quá 7 ngày  
**Thời gian chạy:** Mỗi ngày 3:00 AM  
**Crontab:**
```
0 3 * * * php C:/xampp/htdocs/fashion-shop/cron/auto_cancel_orders.php
```

### 3. expire_coupons.php
**Chức năng:** Tắt mã giảm giá hết hạn  
**Thời gian chạy:** Mỗi ngày 4:00 AM  
**Crontab:**
```
0 4 * * * php C:/xampp/htdocs/fashion-shop/cron/expire_coupons.php
```

## 🖥️ Setup trên Windows (XAMPP)

### Cách 1: Windows Task Scheduler (Khuyến nghị)

1. Mở **Task Scheduler** (taskschd.msc)
2. Tạo **Basic Task**
3. Thiết lập:
   - **Name:** Fashion Shop - Cleanup Cart
   - **Trigger:** Daily, 2:00 AM
   - **Action:** Start a program
   - **Program:** `C:\xampp\php\php.exe`
   - **Arguments:** `C:\xampp\htdocs\fashion-shop\cron\cleanup_cart.php`
4. Lặp lại cho các cron khác

### Cách 2: Chạy thủ công để test
```bash
cd C:\xampp\htdocs\fashion-shop\cron
php cleanup_cart.php
php auto_cancel_orders.php
php expire_coupons.php
```

## 📊 Xem Log

Log được lưu trong thư mục `cron/logs/`
```
cron/logs/cleanup_cart_2026-01-31.log
cron/logs/auto_cancel_orders_2026-01-31.log
cron/logs/expire_coupons_2026-01-31.log
```

## ⚠️ Lưu ý

- Đảm bảo PHP CLI đã cài đặt
- Kiểm tra đường dẫn PHP: `C:\xampp\php\php.exe`
- Cron chạy với quyền của user setup task
- Nên test thủ công trước khi setup tự động
