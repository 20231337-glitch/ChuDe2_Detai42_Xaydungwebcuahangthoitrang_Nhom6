<?php
/**
 * Cron Job: Tự động hủy đơn hàng quá hạn thanh toán
 * Chạy mỗi 1 giờ để kiểm tra và hủy đơn hàng 'pending' > 24h
 * FIXED: SQL Injection vulnerability - Using Prepared Statements
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

// Log file
$logFile = __DIR__ . '/auto_cancel_log.txt';

// Thời gian timeout: 24 giờ
$timeoutHours = 24;

// Sử dụng Prepared Statement để tránh SQL Injection
$query = "
    SELECT order_id, order_code, user_id, total_amount
    FROM orders
    WHERE status = ?
    AND payment_status = ?
    AND TIMESTAMPDIFF(HOUR, created_at, NOW()) > ?
";

$stmt = $conn->prepare($query);
if (!$stmt) {
    $errorMsg = date('Y-m-d H:i:s') . " - [ERROR] Prepare failed: " . $conn->error . "\n";
    file_put_contents($logFile, $errorMsg, FILE_APPEND);
    exit;
}

$status = 'pending';
$paymentStatus = 'unpaid';
$stmt->bind_param('ssi', $status, $paymentStatus, $timeoutHours);

if (!$stmt->execute()) {
    $errorMsg = date('Y-m-d H:i:s') . " - [ERROR] Execute failed: " . $stmt->error . "\n";
    file_put_contents($logFile, $errorMsg, FILE_APPEND);
    $stmt->close();
    exit;
}

$result = $stmt->get_result();
$expiredOrders = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

if (empty($expiredOrders)) {
    $logMsg = date('Y-m-d H:i:s') . " - No expired orders found.\n";
    file_put_contents($logFile, $logMsg, FILE_APPEND);
    exit;
}

// Hủy từng đơn hàng
$cancelledCount = 0;
foreach ($expiredOrders as $order) {
    // Update order status using prepared statement
    $updateQuery = "UPDATE orders SET status = ?, updated_at = NOW() WHERE order_id = ?";
    $updateStmt = $conn->prepare($updateQuery);
    
    if ($updateStmt) {
        $cancelStatus = 'cancelled';
        $updateStmt->bind_param('si', $cancelStatus, $order['order_id']);
        
        if ($updateStmt->execute()) {
            $cancelledCount++;
            $logMsg = date('Y-m-d H:i:s') . " - Cancelled order: {$order['order_code']} (ID: {$order['order_id']})\n";
            file_put_contents($logFile, $logMsg, FILE_APPEND);
        }
        
        $updateStmt->close();
    }
}

$summaryMsg = date('Y-m-d H:i:s') . " - Auto-cancel completed: $cancelledCount orders cancelled.\n";
file_put_contents($logFile, $summaryMsg, FILE_APPEND);

$conn->close();
?>