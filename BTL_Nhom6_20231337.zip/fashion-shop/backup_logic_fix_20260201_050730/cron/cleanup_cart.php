<?php
/**
 * CRON JOB: XÓA GIỎ HÀNG HẾT HẠN
 * Chạy mỗi ngày lúc 2:00 AM
 * Crontab: 0 2 * * * php /path/to/cron/cleanup_cart.php
 */

require_once __DIR__ . '/../config/database.php';

// Log file
$log_file = __DIR__ . '/logs/cleanup_cart_' . date('Y-m-d') . '.log';
$log_dir = dirname($log_file);
if (!file_exists($log_dir)) {
    mkdir($log_dir, 0777, true);
}

function write_log($message) {
    global $log_file;
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($log_file, "[$timestamp] $message\n", FILE_APPEND);
}

write_log("========== BẮT ĐẦU CLEANUP GIỎ HÀNG ==========");

try {
    // Đếm số giỏ hàng sẽ xóa
    $count_sql = "SELECT COUNT(*) as total FROM cart 
                  WHERE expires_at < NOW() 
                  OR (expires_at IS NULL AND added_at < DATE_SUB(NOW(), INTERVAL 30 DAY))";
    
    $count_result = mysqli_query($conn, $count_sql);
    $count = mysqli_fetch_assoc($count_result)['total'];
    
    write_log("Tìm thấy $count giỏ hàng hết hạn");
    
    if ($count > 0) {
        // Xóa giỏ hàng hết hạn
        $delete_sql = "DELETE FROM cart 
                       WHERE expires_at < NOW() 
                       OR (expires_at IS NULL AND added_at < DATE_SUB(NOW(), INTERVAL 30 DAY))";
        
        if (mysqli_query($conn, $delete_sql)) {
            $deleted = mysqli_affected_rows($conn);
            write_log("Đã xóa $deleted giỏ hàng thành công");
        } else {
            throw new Exception("Lỗi SQL: " . mysqli_error($conn));
        }
    } else {
        write_log("Không có giỏ hàng nào cần xóa");
    }
    
    write_log("========== HOÀN THÀNH CLEANUP GIỎ HÀNG ==========");
    
} catch (Exception $e) {
    write_log("LỖI: " . $e->getMessage());
    write_log("========== KẾT THÚC VỚI LỖI ==========");
}

mysqli_close($conn);
?>
