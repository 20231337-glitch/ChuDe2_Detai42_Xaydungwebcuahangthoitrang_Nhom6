<?php
/**
 * CRON JOB: TẮT MÃ GIẢM GIÁ HẾT HẠN
 * Chạy mỗi ngày lúc 4:00 AM
 * Crontab: 0 4 * * * php /path/to/cron/expire_coupons.php
 */

require_once __DIR__ . '/../config/database.php';

// Log file
$log_file = __DIR__ . '/logs/expire_coupons_' . date('Y-m-d') . '.log';
$log_dir = dirname($log_file);
if (!file_exists($log_dir)) {
    mkdir($log_dir, 0777, true);
}

function write_log($message) {
    global $log_file;
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($log_file, "[$timestamp] $message\n", FILE_APPEND);
}

write_log("========== BẮT ĐẦU TẮT MÃ GIẢM GIÁ HẾT HẠN ==========");

try {
    // Đếm số mã giảm giá hết hạn
    $count_sql = "SELECT COUNT(*) as total FROM coupons 
                  WHERE expiry_date < CURDATE() 
                  AND status = 'active'";
    
    $count_result = mysqli_query($conn, $count_sql);
    $count = mysqli_fetch_assoc($count_result)['total'];
    
    write_log("Tìm thấy $count mã giảm giá hết hạn");
    
    if ($count > 0) {
        // Lấy danh sách mã
        $list_sql = "SELECT coupon_id, coupon_code, expiry_date FROM coupons 
                     WHERE expiry_date < CURDATE() 
                     AND status = 'active'";
        $list_result = mysqli_query($conn, $list_sql);
        
        write_log("Danh sách mã giảm giá:");
        while ($coupon = mysqli_fetch_assoc($list_result)) {
            write_log("  - " . $coupon['coupon_code'] . " (hết hạn: " . $coupon['expiry_date'] . ")");
        }
        
        // Tắt các mã hết hạn
        $update_sql = "UPDATE coupons 
                       SET status = 'inactive' 
                       WHERE expiry_date < CURDATE() 
                       AND status = 'active'";
        
        if (mysqli_query($conn, $update_sql)) {
            $updated = mysqli_affected_rows($conn);
            write_log("Đã tắt $updated mã giảm giá thành công");
        } else {
            throw new Exception("Lỗi SQL: " . mysqli_error($conn));
        }
    } else {
        write_log("Không có mã giảm giá nào cần tắt");
    }
    
    write_log("========== HOÀN THÀNH TẮT MÃ GIẢM GIÁ ==========");
    
} catch (Exception $e) {
    write_log("LỖI: " . $e->getMessage());
    write_log("========== KẾT THÚC VỚI LỖI ==========");
}

mysqli_close($conn);
?>
