<?php
/**
 * Trang chủ chính - Fashion Shop
 * Redirect đến public/home
 */

header('Location: /fashion-shop/public/home/');
exit;
?>
